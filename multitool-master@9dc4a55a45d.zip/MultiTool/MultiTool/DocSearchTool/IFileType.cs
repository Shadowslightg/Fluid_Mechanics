﻿namespace MultiTool.DocSearchTool
{
  interface IFileType
  {
    void FindMatches(string fileName);
  }
}
