﻿using System;
using System.Text.RegularExpressions;
using Xceed.Words.NET;

namespace MultiTool.DocSearchTool
{
  class Document : IFileType
  {
    public void FindMatches(string fileName)
    {
      DocX docx = DocX.Load(fileName);
      if (DocSearchTool.primarySearchText.StartsWith("wc:"))
      {
        DocSearchTool.primarySearchText = DocSearchTool.primarySearchText.Substring(3, DocSearchTool.primarySearchText.Length - 3);
        int numPrimaryResults = docx.FindUniqueByPattern(DocSearchTool.primarySearchText, RegexOptions.IgnoreCase).Count;
        DocSearchTool.primarySearchText = "wc:" + DocSearchTool.primarySearchText;
        if (numPrimaryResults > 0)
        {
          DocSearchTool.primarySearchMatches.Add(fileName);
          DocSearchTool.primarySearchCount.Add(numPrimaryResults);
        }
      }
      else
      {
        DocSearchTool.primaryIndexList = docx.FindAll(DocSearchTool.primarySearchText, RegexOptions.IgnoreCase);

        //if primary search is matched
        if (DocSearchTool.primaryIndexList.Count > 0)
        {
          //add number of matches and the file name
          DocSearchTool.primarySearchCount.Add(DocSearchTool.primaryIndexList.Count);
          DocSearchTool.primarySearchMatches.Add(fileName);
        }
      }
      if (DocSearchTool.secondarySearchText.StartsWith("wc:"))
      {
        DocSearchTool.secondarySearchText = DocSearchTool.secondarySearchText.Substring(3, DocSearchTool.secondarySearchText.Length - 3);
        int numSecondaryResults = docx.FindUniqueByPattern(DocSearchTool.secondarySearchText, RegexOptions.IgnoreCase).Count;
        DocSearchTool.secondarySearchText = "wc:" + DocSearchTool.secondarySearchText;
        if (numSecondaryResults > 0)
        {
          DocSearchTool.secondarySearchMatches.Add(fileName);
          DocSearchTool.secondarySearchCount.Add(numSecondaryResults);
        }
      }
      else
      {
        if (!String.IsNullOrWhiteSpace(DocSearchTool.secondarySearchText))
        {
          DocSearchTool.secondaryIndexList = docx.FindAll(DocSearchTool.secondarySearchText, RegexOptions.IgnoreCase);

          //if secondary search is matched
          if (DocSearchTool.secondaryIndexList.Count > 0 && DocSearchTool.secondarySearchText != "")
          {
            //add number of matches and the file name
            DocSearchTool.secondarySearchCount.Add(DocSearchTool.secondaryIndexList.Count);
            DocSearchTool.secondarySearchMatches.Add(fileName);
          }
        }
      }
    }
  }
}
