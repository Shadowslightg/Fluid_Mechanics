﻿//Copyright © 2018 Schweitzer Engineering Laboratories, Inc.
//SEL Confidential

using System;
using System.Collections.Generic;
using System.IO;
using CsvHelper;
using MultiTool;

namespace DocumentSearchTool
{
  class CSVExporter
  {
  /// <summary>
  /// If output file is open, auto increment the filename to avoid an exception
  /// </summary>
  /// <param name="stub">name of the file (output)</param>
  /// <param name="extension">file type (csv)</param>
  /// <returns>the filename string</returns>
  private static string IndexedFileName(string stub, string extension)
  {
    int i = 0;
    string fileName = null;
    do
    {
      i++;
      fileName = string.Format("{0}{1}.{2}", stub, i, extension);
    } while (File.Exists(fileName));
    return fileName;
  }

  /// <summary>
  /// Exports the data to a csv file
  /// </summary>
  /// <param name="primary">A list of all the files with primary matches</param>
  /// <param name="primaryCount">Number of primary matches for each file (index corresponds to index of secondary)</param>
  /// <param name="secondary">A list of all the files with secondary matches</param>
  /// <param name="secondaryCount">Number of secondary matches for each file (index corresponds to index of secondary)</param>
  /// <param name="failed">A list of all the files that were unable to be opened (in use, etc...)</param>
  /// <param name="outputFolder"></param>
  /// <param name="primaryString">Primary search terms</param>
  /// <param name="secondaryString">Secondary search terms</param>
  public static void WriteToCSV(List<string> primary, List<int> primaryCount, List<string> secondary, List<int> secondaryCount, List<string> failed, string outputFolder, string primaryString, string secondaryString)
  {
    string outFileName = IndexedFileName("\\output", "csv");
    MultiTool.DocSearchTool.DocSearchTool.SetOutFile(outFileName);

      try
      {
        Directory.CreateDirectory(outputFolder);
        TextWriter writer = null;
        try
        {
          using (TextWriter newWriter = new StreamWriter(outputFolder + outFileName))
          {
            int i = 0;
            var csv = new CsvWriter(newWriter);
            csv.WriteField("Primary Search Matches for: " + primaryString);
            csv.WriteField("Number of Matches");
            if (secondaryCount.Count > 0)
            {
              csv.WriteField("Match both primary and secondary");
            }
            if(MainForm.primarySearchParam.Text.StartsWith("wc:"))
            {
              csv.WriteField("WARNING: MATCH COUNT FOR DOCX FILES IS INACCURATE WHEN USING REGEX PATTERNS!");
            }
            csv.NextRecord();
            //Primary matches
            foreach (string s in primary)
            {
              bool found = false;
              csv.WriteField(s);
              csv.WriteField(primaryCount[i].ToString());
              if (!string.IsNullOrWhiteSpace(secondaryString))
              {
                for (int j = 0; j < secondary.Count; j++)
                {
                  if (s == secondary[j])
                  {
                    csv.WriteField("True");
                    found = true;
                  }
                }
                if (!found)
                {
                  csv.WriteField("False");
                }
              }
              csv.NextRecord();
              i++;
            }
            i = 0;
            csv.NextRecord();
            //secondary matches
            if (secondaryCount.Count > 0)
            {
              csv.WriteField("Secondary Search Matches for: " + secondaryString);
              csv.WriteField("Number of Matches");
              csv.NextRecord();
            }
            foreach (string s in secondary)
            {
              csv.WriteField(s);
              csv.WriteField(secondaryCount[i].ToString());
              csv.NextRecord();
              i++;
            }
            if (failed.Count > 0)
            {
              csv.NextRecord();
              csv.WriteField("Failed to open: ");
              csv.NextRecord();
              foreach (string s in failed)
              {
                csv.WriteField(s);
                csv.NextRecord();
              }
            }
          }
        }
        finally
        {
          if (writer != null)
            writer.Dispose();
        }
      }
      catch (IOException e)
      {
        Console.WriteLine("IOException source: {0}", e.Source);
      }
  }
  }
}
