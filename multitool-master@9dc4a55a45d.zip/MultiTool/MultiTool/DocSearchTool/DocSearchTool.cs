﻿using DocumentSearchTool;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MultiTool.DocSearchTool
{
  class DocSearchTool
  {
    public DocSearchTool(MainForm mainForm)
    {
      mf = mainForm;
      bg.DoWork += Bg_DoWork;
      bg.WorkerReportsProgress = false;
    }

    public static BackgroundWorker bg = new BackgroundWorker();
    private static string folderName;
    private static string outFolderName;
    private static string outFile;
    static MainForm mf;
    public static List<int> primaryIndexList = new List<int>();
    public static List<int> secondaryIndexList = new List<int>();
    public static List<int> primarySearchCount = new List<int>();
    public static List<int> secondarySearchCount = new List<int>();
    public static List<string> primarySearchMatches = new List<string>();
    public static List<string> secondarySearchMatches = new List<string>();
    public static List<string> failed = new List<string>();
    public static string primarySearchText;
    public static string secondarySearchText;

    /// <summary>
    /// Enable/disable nested search
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void DeepSearch_Click(object sender, EventArgs e)
    {
      if (MainForm.deepSearch.Checked)
      {
        MessageBox.Show("WARNING! Nested search will search all subfolders in the selected directory. This might take a while!", "!!! WARNING !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
    }

    //Used for calling ToggleControls
    public delegate void Toggle();

    //Used for calling ProgressStep
    public delegate void UpdateProgress(string file);

    //Used for calling SetProgressMax
    public delegate void SetMax(IEnumerable<string> fileEntries);

    /// <summary>
    /// Update the progress bar maximum value
    /// </summary>
    /// <param name="fileEntries"></param>
    public static void SetProgressMax(IEnumerable<string> fileEntries)
    {
      MainForm.progress.Maximum = fileEntries.Count();
    }

    /// <summary>
    /// Update the progress bar
    /// </summary>
    public static void ProgressStep(string file)
    {
      MainForm.progress.PerformStep();
      MainForm.progressLabel.Text = "Scanning " + file;
      MainForm.progressLabel.Refresh();
      if (MainForm.progress.Value == MainForm.progress.Maximum)
      {
        MainForm.progress.Visible = false;
        mf.ClientSize = new Size(600, 345);
        MainForm.progressLabel.Text = "";
        MainForm.progress.Value = 1;
        MainForm.progress.Refresh();
      }
    }

    /// <summary>
    /// Disable controls during search and re-enable them after
    /// </summary>
    public static void ToggleControlsDST()
    {
      if (MainForm.search.Enabled)
      {
        MainForm.search.Enabled = false;
        MainForm.browse.Enabled = false;
        MainForm.browseOutput.Enabled = false;
        MainForm.deepSearch.Enabled = false;
        MainForm.search.Text = "Searching, Please wait...";
        MainForm.search.Refresh();
      }
      else
      {
        MainForm.search.Enabled = true;
        MainForm.browse.Enabled = true;
        MainForm.browseOutput.Enabled = true;
        MainForm.deepSearch.Enabled = true;
        MainForm.search.Text = "Search";
        MainForm.search.Refresh();
      }
    }

    /// <summary>
    /// Used for resizing the window to display progress bar
    /// </summary>
    public static void IncreaseClientSize()
    {
      if (mf.ClientSize == new Size(600, 345))
      {
        mf.ClientSize = new Size(600, 425);
        MainForm.progress.Visible = true;
        MainForm.progress.Refresh();
      }
    }

    /// <summary>
    /// This background thread does all the heavy lifting when the user clicks search
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void Bg_DoWork(object sender, DoWorkEventArgs e)
    {
      IAsyncResult result1 = MainForm.search.BeginInvoke(new Toggle(IncreaseClientSize));
      IAsyncResult result2 = MainForm.search.BeginInvoke(new Toggle(ToggleControlsDST));
      MainForm.search.EndInvoke(result1);
      MainForm.search.EndInvoke(result2);
      primarySearchText = MainForm.primarySearchParam.Text;
      secondarySearchText = MainForm.secondarySearchParam.Text;
      if (Directory.Exists(folderName))
      {
        IEnumerable<string> fileEntries = null;
        string[] fileExt = { ".pdf", ".doc", ".docx", ".xlsx", ".xlsm" };
        try
        {
          fileEntries = MainForm.deepSearch.Checked ? Directory.EnumerateFiles(folderName, "*.*", SearchOption.AllDirectories).Where(s => fileExt.Any(ext => s.EndsWith(ext))) :
              Directory.EnumerateFiles(folderName, "*.*").Where(s => fileExt.Any(ext => s.EndsWith(ext)));

          IAsyncResult result5 = MainForm.search.BeginInvoke(new SetMax(SetProgressMax), fileEntries);
          MainForm.search.EndInvoke(result5);
        }
        catch(UnauthorizedAccessException)
        {
          MessageBox.Show("You do not have full access to the selected directory! Please select a more specific directory.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
          IAsyncResult result6 = MainForm.search.BeginInvoke(new Toggle(IncreaseClientSize));
          IAsyncResult result7 = MainForm.search.BeginInvoke(new Toggle(ToggleControlsDST));
          MainForm.search.EndInvoke(result6);
          MainForm.search.EndInvoke(result7);
          return;
        }
        foreach (string fileName in fileEntries)
        {
          //.doc and .docx files
          if (fileName.EndsWith(".doc") || fileName.EndsWith(".docx"))
          {
            try
            {
              Document doc = new Document();
              doc.FindMatches(fileName);
            }
            //if file was unable to be opened (in use, etc...)
            catch (Exception)
            {
              failed.Add(fileName);
            }
          }
          //.pdf files
          else if(fileName.EndsWith(".pdf"))
          {
            try
            {
              PDF pdf = new PDF();
              pdf.FindMatches(fileName);
            }
            //if file was unable to be opened (in use, etc...)
            catch (Exception)
            {
              failed.Add(fileName);
            }
          }
          //.xlsx files
          else if(fileName.EndsWith(".xlsx") | fileName.EndsWith(".xlsm"))
          {
            try
            {
              Spreadsheet sheet = new Spreadsheet();
              sheet.FindMatches(fileName);
            }
            catch(Exception ex)
            {
              failed.Add(fileName);
              Console.WriteLine(ex.Message);
            }
          }
          IAsyncResult result3 = MainForm.search.BeginInvoke(new UpdateProgress(ProgressStep), fileName);
          MainForm.search.EndInvoke(result3);
        }
      }
      else
      {
        MessageBox.Show("That directory doesn't exist.", "Invalid Directory", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      if (string.IsNullOrEmpty(outFolderName))
      {
        outFolderName = MainForm.searchDirectory.SelectedPath.ToString();
      }
      IAsyncResult result4 = MainForm.search.BeginInvoke(new Toggle(ToggleControlsDST));
      MainForm.search.EndInvoke(result4);
      CSVExporter.WriteToCSV(primarySearchMatches, primarySearchCount, secondarySearchMatches, secondarySearchCount, failed, outFolderName, primarySearchText, secondarySearchText);
      if (MessageBox.Show("Search complete! Open results file?", "Search complete!", MessageBoxButtons.YesNo, MessageBoxIcon.None) == DialogResult.Yes)
      {
        Process.Start(outFolderName + outFile);
      }
      primaryIndexList.Clear();
      secondaryIndexList.Clear();
      primarySearchCount.Clear();
      secondarySearchCount.Clear();
      primarySearchMatches.Clear();
      secondarySearchMatches.Clear();
      failed.Clear();
    }


    /// <summary>
    /// Sets the name of the output file for use in CSVExporter.cs
    /// </summary>
    /// <param name="name"></param>
    public static void SetOutFile(string name)
    {
      outFile = name;
    }

    /// <summary>
    /// Event handler for the help button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void Help_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
      try
      {
        MainForm.help.LinkVisited = true;
        Process.Start("https://confluence.metro.ad.selinc.com/display/ALMW/Document+Search+Tool+Help");
      }
      catch
      {
        MessageBox.Show("Unable to open link.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
    }

    /// <summary>
    /// Event handler for the browse search directory button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void Browse_Click(object sender, EventArgs e)
    {
      MainForm.searchDirectory.SelectedPath = Environment.SpecialFolder.Desktop.ToString();
      if (MainForm.searchDirectory.ShowDialog() == DialogResult.OK)
      {
        MainForm.directory.Text = MainForm.searchDirectory.SelectedPath;
        folderName = MainForm.searchDirectory.SelectedPath;
      }
    }

    /// <summary>
    /// Event handler for the browse output directory button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void BrowseOutputDST_Click(object sender, EventArgs e)
    {
      MainForm.outputDirectory.SelectedPath = Environment.SpecialFolder.Desktop.ToString();
      if (MainForm.outputDirectory.ShowDialog() == DialogResult.OK)
      {
        MainForm.outDir.Text = MainForm.outputDirectory.SelectedPath;
        outFolderName = MainForm.outputDirectory.SelectedPath;
      }
    }

    /// <summary>
    /// Event handler for the search button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void Search_Click(object sender, EventArgs e)
    {
      if (!string.IsNullOrWhiteSpace(MainForm.primarySearchParam.Text) && !string.IsNullOrWhiteSpace(MainForm.searchDirectory.SelectedPath))
      {
        bg.RunWorkerAsync();
      }
      else
      {
        MessageBox.Show("Please fill out the required fields: \n\n   -Primary search parameters \n\n   -Search directory", "Missing parameters", MessageBoxButtons.OK, MessageBoxIcon.Warning);
      }
    }
  }
}
