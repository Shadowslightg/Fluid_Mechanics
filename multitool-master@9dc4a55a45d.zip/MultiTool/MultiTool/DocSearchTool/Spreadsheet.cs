﻿using ClosedXML.Excel;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System;

namespace MultiTool.DocSearchTool
{
  class Spreadsheet : IFileType
  {
    public void FindMatches(string fileName)
    {
      int totalPrimaryMatches = 0;
      int totalSecondaryMatches = 0;
      var workbook = new XLWorkbook(fileName);
      foreach (IXLWorksheet ws in workbook.Worksheets)
      {
        if(!String.IsNullOrWhiteSpace(DocSearchTool.primarySearchText))
        {
          if (DocSearchTool.primarySearchText.StartsWith("wc:"))
          {
            DocSearchTool.primarySearchText = DocSearchTool.primarySearchText.Substring(3, DocSearchTool.primarySearchText.Length - 3);
            IXLCells secondaryMatches = ws.CellsUsed(cell => Regex.IsMatch(cell.RichText.ToString(), DocSearchTool.primarySearchText));
            foreach (IXLCell c in secondaryMatches)
            {
              totalSecondaryMatches++;
            }
            DocSearchTool.primarySearchText = "wc:" + DocSearchTool.primarySearchText;
          }
          else
          {
            IXLCells primaryMatches = ws.CellsUsed(cell => cell.RichText.ToString().ToLower().Contains(DocSearchTool.primarySearchText));
            foreach (IXLCell c in primaryMatches)
            {
              totalPrimaryMatches++;
            }
          }
        }
        if(!String.IsNullOrWhiteSpace(DocSearchTool.secondarySearchText))
        {
          if (DocSearchTool.secondarySearchText.StartsWith("wc:"))
          {
            DocSearchTool.secondarySearchText = DocSearchTool.secondarySearchText.Substring(3, DocSearchTool.secondarySearchText.Length - 3);
            IXLCells secondaryMatches = ws.CellsUsed(cell => Regex.IsMatch(cell.RichText.ToString(), DocSearchTool.secondarySearchText));
            foreach (IXLCell c in secondaryMatches)
            {
              totalSecondaryMatches++;
            }
            DocSearchTool.secondarySearchText = "wc:" + DocSearchTool.secondarySearchText;
          }
          else
          {
            IXLCells secondaryMatches = ws.CellsUsed(cell => cell.RichText.ToString().ToLower().Contains(DocSearchTool.secondarySearchText));
            foreach (IXLCell c in secondaryMatches)
            {
              totalSecondaryMatches++;
            }
          }
        }
      }
      if(totalPrimaryMatches > 0)
      {
        DocSearchTool.primarySearchMatches.Add(fileName);
        DocSearchTool.primarySearchCount.Add(totalPrimaryMatches);
      }
      if(totalSecondaryMatches > 0)
      {
        DocSearchTool.secondarySearchMatches.Add(fileName);
        DocSearchTool.secondarySearchCount.Add(totalSecondaryMatches);
      }
    }
  }
}
