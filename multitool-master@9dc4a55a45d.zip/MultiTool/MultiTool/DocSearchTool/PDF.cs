﻿using System;
using System.Text.RegularExpressions;
using TikaOnDotNet.TextExtraction;

namespace MultiTool.DocSearchTool
{
  class PDF : IFileType
  {
    public void FindMatches(string fileName)
    {
      var textExtractor = new TextExtractor();
      var allText = textExtractor.Extract(fileName).ToString();
      bool primaryTextMatch, secondaryTextMatch;
      if (DocSearchTool.primarySearchText.StartsWith("wc:"))
      {
        DocSearchTool.primarySearchText = DocSearchTool.primarySearchText.Substring(3, DocSearchTool.primarySearchText.Length - 3);
        primaryTextMatch = Regex.IsMatch(allText, DocSearchTool.primarySearchText);
        DocSearchTool.primarySearchText = "wc:" + DocSearchTool.primarySearchText;
      }
      else
      {
        primaryTextMatch = allText.ToLower().Contains(DocSearchTool.primarySearchText.ToLower());
      }
      if (DocSearchTool.secondarySearchText.StartsWith("wc:"))
      {
        DocSearchTool.secondarySearchText = DocSearchTool.secondarySearchText.Substring(3, DocSearchTool.secondarySearchText.Length - 3);
        secondaryTextMatch = Regex.IsMatch(allText, DocSearchTool.secondarySearchText);
        DocSearchTool.secondarySearchText = "wc:" + DocSearchTool.secondarySearchText;
      }
      else
      {
        if (!String.IsNullOrWhiteSpace(DocSearchTool.secondarySearchText))
        {
          secondaryTextMatch = allText.ToLower().Contains(DocSearchTool.secondarySearchText.ToLower());
        }
        else
        {
          secondaryTextMatch = false;
        }
      }
      if (primaryTextMatch)
      {
        DocSearchTool.primarySearchMatches.Add(fileName);
        if (DocSearchTool.primarySearchText.StartsWith("wc:"))
        {
          DocSearchTool.primarySearchCount.Add(Regex.Matches(allText, DocSearchTool.primarySearchText.Substring(3, DocSearchTool.primarySearchText.Length - 3)).Count);
        }
        else
        {
          DocSearchTool.primarySearchCount.Add(Regex.Matches(allText, DocSearchTool.primarySearchText.ToLower()).Count);
        }
      }
      if (secondaryTextMatch && DocSearchTool.secondarySearchText != "")
      {
        DocSearchTool.secondarySearchMatches.Add(fileName);
        if (DocSearchTool.secondarySearchText.StartsWith("wc:"))
        {
          DocSearchTool.secondarySearchCount.Add(Regex.Matches(allText, DocSearchTool.secondarySearchText.Substring(3, DocSearchTool.secondarySearchText.Length - 3)).Count);
        }
        else
        {
          DocSearchTool.secondarySearchCount.Add(Regex.Matches(allText, DocSearchTool.secondarySearchText.ToLower()).Count);
        }
      }
    }
  }
}
