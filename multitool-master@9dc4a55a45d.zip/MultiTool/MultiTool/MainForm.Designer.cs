﻿namespace MultiTool
{
  partial class MainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.tc = new System.Windows.Forms.TabControl();
      this.imgCompressor = new System.Windows.Forms.TabPage();
      tlpMain = new System.Windows.Forms.TableLayoutPanel();
      panelSource = new System.Windows.Forms.Panel();
      panelListImages = new System.Windows.Forms.Panel();
      panelSelectedFiles = new System.Windows.Forms.Panel();
      lblFileSelectedInfo = new System.Windows.Forms.Label();
      selectedFileListView = new System.Windows.Forms.ListView();
      fileName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
      panelSourceBrowse = new System.Windows.Forms.Panel();
      btnBrowseImages = new System.Windows.Forms.Button();
      txtSourceImages = new System.Windows.Forms.TextBox();
      label1 = new System.Windows.Forms.Label();
      tlpOutput = new System.Windows.Forms.TableLayoutPanel();
      btnCompress = new System.Windows.Forms.Button();
      flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
      label3 = new System.Windows.Forms.Label();
      tbOutputFolder = new System.Windows.Forms.TextBox();
      btnBrowseOutputFolder = new System.Windows.Forms.Button();
      tlpInputFileList = new System.Windows.Forms.TableLayoutPanel();
      linkLabel1 = new System.Windows.Forms.LinkLabel();
      pntControl = new System.Windows.Forms.FlowLayoutPanel();
      btnAdd = new System.Windows.Forms.Button();
      btnAddAll = new System.Windows.Forms.Button();
      btnRemove = new System.Windows.Forms.Button();
      btnRemoveAll = new System.Windows.Forms.Button();
      btnClear = new System.Windows.Forms.Button();
      inputFileListView = new System.Windows.Forms.ListView();
      inputFileName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
      tlpControls = new System.Windows.Forms.TableLayoutPanel();
      pbPreview = new System.Windows.Forms.PictureBox();
      tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
      panel1 = new System.Windows.Forms.Panel();
      lblQuality = new System.Windows.Forms.Label();
      tbQuality = new System.Windows.Forms.TrackBar();
      label4 = new System.Windows.Forms.Label();
      drpResize = new System.Windows.Forms.ComboBox();
      label2 = new System.Windows.Forms.Label();
      TDTR = new System.Windows.Forms.TabPage();
      renamer = new System.Windows.Forms.TabPage();
      docSignAndDate = new System.Windows.Forms.TabPage();
      docSearchTool = new System.Windows.Forms.TabPage();
      ofd = new System.Windows.Forms.OpenFileDialog();
      fbd = new System.Windows.Forms.FolderBrowserDialog();
      tc.SuspendLayout();
      imgCompressor.SuspendLayout();
      tlpMain.SuspendLayout();
      panelSource.SuspendLayout();
      panelListImages.SuspendLayout();
      panelSelectedFiles.SuspendLayout();
      panelSourceBrowse.SuspendLayout();
      tlpOutput.SuspendLayout();
      flowLayoutPanel1.SuspendLayout();
      tlpInputFileList.SuspendLayout();
      pntControl.SuspendLayout();
      tlpControls.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(pbPreview)).BeginInit();
      tableLayoutPanel4.SuspendLayout();
      panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(tbQuality)).BeginInit();
      mainLayout.SuspendLayout();
      pnlDataRecordInput.SuspendLayout();
      pnlTestReportInput.SuspendLayout();
      panelControls.SuspendLayout();
      this.SuspendLayout();
      // 
      // mainLayout
      // 
      mainLayout.AutoSize = true;
      mainLayout.ColumnCount = 2;
      mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 1.303318F));
      mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 98.69669F));
      mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
      mainLayout.Controls.Add(pnlDataRecordInput, 1, 1);
      mainLayout.Controls.Add(pnlTestReportInput, 1, 2);
      mainLayout.Controls.Add(panelControls, 1, 3);
      mainLayout.Controls.Add(linkHelp, 1, 0);
      mainLayout.Dock = System.Windows.Forms.DockStyle.Fill;
      mainLayout.Location = new System.Drawing.Point(0, 0);
      mainLayout.Margin = new System.Windows.Forms.Padding(4);
      mainLayout.Name = "mainLayout";
      mainLayout.RowCount = 4;
      mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.174313F));
      mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.6055F));
      mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.89908F));
      mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.3211F));
      mainLayout.Size = new System.Drawing.Size(808, 264);
      mainLayout.TabIndex = 0;
      // 
      // pnlDataRecordInput
      // 
      pnlDataRecordInput.Controls.Add(btnBrowseDataRecord);
      pnlDataRecordInput.Controls.Add(tbDataRecord);
      pnlDataRecordInput.Controls.Add(label5);
      pnlDataRecordInput.Dock = System.Windows.Forms.DockStyle.Fill;
      pnlDataRecordInput.Location = new System.Drawing.Point(14, 28);
      pnlDataRecordInput.Margin = new System.Windows.Forms.Padding(4);
      pnlDataRecordInput.Name = "pnlDataRecordInput";
      pnlDataRecordInput.Size = new System.Drawing.Size(790, 62);
      pnlDataRecordInput.TabIndex = 0;
      // 
      // btnBrowseDataRecord
      // 
      btnBrowseDataRecord.Location = new System.Drawing.Point(673, 26);
      btnBrowseDataRecord.Margin = new System.Windows.Forms.Padding(4);
      btnBrowseDataRecord.Name = "btnBrowseDataRecord";
      btnBrowseDataRecord.Size = new System.Drawing.Size(103, 24);
      btnBrowseDataRecord.TabIndex = 2;
      btnBrowseDataRecord.Text = "Browse";
      btnBrowseDataRecord.UseVisualStyleBackColor = true;
      btnBrowseDataRecord.Click += new System.EventHandler(MultiTool.TDTR.TDTR.BrowseDataRecord);
      // 
      // tbDataRecord
      // 
      tbDataRecord.Location = new System.Drawing.Point(7, 26);
      tbDataRecord.Margin = new System.Windows.Forms.Padding(4);
      tbDataRecord.Name = "tbDataRecord";
      tbDataRecord.Size = new System.Drawing.Size(651, 24);
      tbDataRecord.TabIndex = 1;
      tbDataRecord.DoubleClick += new System.EventHandler(MultiTool.TDTR.TDTR.BrowseDataRecord);
      // 
      // label11
      // 
      label5.AutoSize = true;
      label5.Location = new System.Drawing.Point(4, 4);
      label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      label5.Name = "label1";
      label5.Size = new System.Drawing.Size(137, 18);
      label5.TabIndex = 0;
      label5.Text = "Select Data Record";
      // 
      // pnlTestReportInput
      // 
      pnlTestReportInput.Controls.Add(btnBrowseTestReport);
      pnlTestReportInput.Controls.Add(tbTestReport);
      pnlTestReportInput.Controls.Add(label6);
      pnlTestReportInput.Dock = System.Windows.Forms.DockStyle.Fill;
      pnlTestReportInput.Location = new System.Drawing.Point(14, 98);
      pnlTestReportInput.Margin = new System.Windows.Forms.Padding(4);
      pnlTestReportInput.Name = "pnlTestReportInput";
      pnlTestReportInput.Size = new System.Drawing.Size(790, 68);
      pnlTestReportInput.TabIndex = 1;
      // 
      // btnBrowseTestReport
      // 
      btnBrowseTestReport.Location = new System.Drawing.Point(673, 25);
      btnBrowseTestReport.Margin = new System.Windows.Forms.Padding(4);
      btnBrowseTestReport.Name = "btnBrowseTestReport";
      btnBrowseTestReport.Size = new System.Drawing.Size(103, 24);
      btnBrowseTestReport.TabIndex = 2;
      btnBrowseTestReport.Text = "Browse";
      btnBrowseTestReport.UseVisualStyleBackColor = true;
      btnBrowseTestReport.Click += new System.EventHandler(MultiTool.TDTR.TDTR.BrowseTestReport);
      // 
      // tbTestReport
      // 
      tbTestReport.Location = new System.Drawing.Point(7, 25);
      tbTestReport.Margin = new System.Windows.Forms.Padding(4);
      tbTestReport.Name = "tbTestReport";
      tbTestReport.Size = new System.Drawing.Size(651, 24);
      tbTestReport.TabIndex = 1;
      tbTestReport.DoubleClick += new System.EventHandler(MultiTool.TDTR.TDTR.BrowseTestReport);
      // 
      // label12
      // 
      label6.AutoSize = true;
      label6.Location = new System.Drawing.Point(5, 2);
      label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      label6.Name = "label2";
      label6.Size = new System.Drawing.Size(131, 18);
      label6.TabIndex = 0;
      label6.Text = "Select Test Report";
      // 
      // panelControls
      // 
      panelControls.Controls.Add(cbCopyTableNumber);
      panelControls.Controls.Add(lblProgress);
      panelControls.Controls.Add(progressBar);
      panelControls.Controls.Add(btnTransfer);
      panelControls.Dock = System.Windows.Forms.DockStyle.Fill;
      panelControls.Location = new System.Drawing.Point(14, 174);
      panelControls.Margin = new System.Windows.Forms.Padding(4);
      panelControls.Name = "panelControls";
      panelControls.Size = new System.Drawing.Size(790, 86);
      panelControls.TabIndex = 2;
      // 
      // lblProgress
      // 
      lblProgress.Anchor = System.Windows.Forms.AnchorStyles.None;
      lblProgress.AutoSize = true;
      lblProgress.BackColor = System.Drawing.Color.Transparent;
      lblProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      lblProgress.ForeColor = System.Drawing.SystemColors.MenuHighlight;
      lblProgress.Location = new System.Drawing.Point(378, 9);
      lblProgress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      lblProgress.Name = "lblProgress";
      lblProgress.Size = new System.Drawing.Size(36, 20);
      lblProgress.TabIndex = 2;
      lblProgress.Text = "0 %";
      lblProgress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      lblProgress.Visible = false;
      // 
      // progressBar
      // 
      progressBar.Location = new System.Drawing.Point(8, 4);
      progressBar.Margin = new System.Windows.Forms.Padding(4);
      progressBar.Name = "progressBar";
      progressBar.Size = new System.Drawing.Size(768, 29);
      progressBar.TabIndex = 1;
      progressBar.UseWaitCursor = true;
      progressBar.Visible = false;
      // 
      // btnTransfer
      // 
      btnTransfer.BackColor = System.Drawing.Color.MediumSeaGreen;
      btnTransfer.Location = new System.Drawing.Point(628, 30);
      btnTransfer.Margin = new System.Windows.Forms.Padding(4);
      btnTransfer.Name = "btnTransfer";
      btnTransfer.Size = new System.Drawing.Size(150, 45);
      btnTransfer.TabIndex = 0;
      btnTransfer.Text = "Transfer";
      btnTransfer.UseVisualStyleBackColor = false;
      btnTransfer.Click += new System.EventHandler(MultiTool.TDTR.TDTR.TransferData);
      // 
      // linkHelp
      // 
      linkHelp.Anchor = System.Windows.Forms.AnchorStyles.Right;
      linkHelp.AutoSize = true;
      linkHelp.Location = new System.Drawing.Point(766, 3);
      linkHelp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      linkHelp.Name = "linkHelp";
      linkHelp.Size = new System.Drawing.Size(38, 18);
      linkHelp.TabIndex = 3;
      linkHelp.TabStop = true;
      linkHelp.Text = "Help";
      linkHelp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(MultiTool.TDTR.TDTR.OpenHelp);
      // 
      // ofd2
      // 
      ofd2.AutoUpgradeEnabled = false;
      ofd2.Filter = "Word Documents|*.doc;*.docx;";
      ofd2.Title = "Select Word File";
      // 
      // bgWorker
      // 
      bgWorker.WorkerReportsProgress = true;
      bgWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(MultiTool.TDTR.TDTR.BGWorker_DoWork);
      bgWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(MultiTool.TDTR.TDTR.BGWorker_ProgressChanged);
      bgWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(MultiTool.TDTR.TDTR.BGWorker_RunWorkerComplete);
      // 
      // sfd
      // 
      sfd.AddExtension = false;
      sfd.DefaultExt = "docx";
      sfd.FileOk += new System.ComponentModel.CancelEventHandler(MultiTool.TDTR.TDTR.SaveReport);
      sfd.Filter = "Microsoft Word Document (*.docx)|*.docx|All files (*.*)|*.*";
      // 
      // cbCopyTableNumber
      // 
      cbCopyTableNumber.AutoSize = true;
      cbCopyTableNumber.Location = new System.Drawing.Point(9, 42);
      cbCopyTableNumber.Name = "cbCopyTableNumber";
      cbCopyTableNumber.Size = new System.Drawing.Size(159, 22);
      cbCopyTableNumber.TabIndex = 3;
      cbCopyTableNumber.Text = "Copy Table Number";
      cbCopyTableNumber.UseVisualStyleBackColor = true;
      // 
      // tc
      // 
      this.tc.Controls.Add(this.imgCompressor);
      this.tc.Controls.Add(this.TDTR);
      this.tc.Controls.Add(this.renamer);
      this.tc.Controls.Add(this.docSignAndDate);
      this.tc.Controls.Add(this.docSearchTool);
      this.tc.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tc.HotTrack = true;
      this.tc.Location = new System.Drawing.Point(0, 0);
      this.tc.Name = "tc";
      this.tc.SelectedIndex = 0;
      this.tc.Size = new System.Drawing.Size(1133, 605);
      this.tc.TabIndex = 1;
      this.tc.TabStop = false;
      // 
      // imgCompressor
      // 
      this.imgCompressor.Controls.Add(tlpMain);
      this.imgCompressor.Location = new System.Drawing.Point(4, 22);
      this.imgCompressor.Name = "imgCompressor";
      this.imgCompressor.Size = new System.Drawing.Size(1125, 579);
      this.imgCompressor.TabIndex = 0;
      this.imgCompressor.Text = "Image Compressor";
      // 
      // tlpMain
      // 
      tlpMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
      tlpMain.AutoSize = true;
      tlpMain.ColumnCount = 2;
      tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.07237F));
      tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.92763F));
      tlpMain.Controls.Add(panelSource, 0, 0);
      tlpMain.Controls.Add(tlpOutput, 1, 0);
      tlpMain.Location = new System.Drawing.Point(0, 0);
      tlpMain.Name = "tlpMain";
      tlpMain.RowCount = 1;
      tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
      tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 565F));
      tlpMain.Size = new System.Drawing.Size(1125, 580);
      tlpMain.TabIndex = 0;
      // 
      // panelSource
      // 
      panelSource.Controls.Add(panelListImages);
      panelSource.Controls.Add(panelSourceBrowse);
      panelSource.Dock = System.Windows.Forms.DockStyle.Fill;
      panelSource.Location = new System.Drawing.Point(3, 3);
      panelSource.Name = "panelSource";
      panelSource.Size = new System.Drawing.Size(516, 599);
      panelSource.TabIndex = 2;
      // 
      // panelListImages
      // 
      panelListImages.Controls.Add(panelSelectedFiles);
      panelListImages.Controls.Add(selectedFileListView);
      panelListImages.Dock = System.Windows.Forms.DockStyle.Fill;
      panelListImages.Location = new System.Drawing.Point(0, 51);
      panelListImages.Name = "panelListImages";
      panelListImages.Size = new System.Drawing.Size(516, 548);
      panelListImages.TabIndex = 1;
      // 
      // panelSelectedFiles
      // 
      panelSelectedFiles.Controls.Add(lblFileSelectedInfo);
      panelSelectedFiles.Dock = System.Windows.Forms.DockStyle.Bottom;
      panelSelectedFiles.Location = new System.Drawing.Point(0, 523);
      panelSelectedFiles.Name = "panelSelectedFiles";
      panelSelectedFiles.Size = new System.Drawing.Size(516, 25);
      panelSelectedFiles.TabIndex = 0;
      // 
      // lblFileSelectedInfo
      // 
      lblFileSelectedInfo.AutoSize = true;
      lblFileSelectedInfo.Location = new System.Drawing.Point(3, 7);
      lblFileSelectedInfo.Name = "lblFileSelectedInfo";
      lblFileSelectedInfo.Size = new System.Drawing.Size(89, 13);
      lblFileSelectedInfo.TabIndex = 0;
      lblFileSelectedInfo.Text = "";
      // 
      // selectedFileListView
      // 
      selectedFileListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            fileName});
      selectedFileListView.Dock = System.Windows.Forms.DockStyle.Fill;
      selectedFileListView.FullRowSelect = true;
      selectedFileListView.GridLines = true;
      selectedFileListView.HideSelection = false;
      selectedFileListView.LabelEdit = true;
      selectedFileListView.Location = new System.Drawing.Point(0, 0);
      selectedFileListView.Name = "selectedFileListView";
      selectedFileListView.Size = new System.Drawing.Size(516, 548);
      selectedFileListView.Sorting = System.Windows.Forms.SortOrder.Ascending;
      selectedFileListView.TabIndex = 1;
      selectedFileListView.UseCompatibleStateImageBehavior = false;
      selectedFileListView.View = System.Windows.Forms.View.Details;
      selectedFileListView.SelectedIndexChanged += new System.EventHandler(ImgCompressor.ImgCompressor.PreviewSelectedImage);
      selectedFileListView.SelectedIndexChanged += new System.EventHandler(ImgCompressor.ImgCompressor.SelectedFileListView_SelectedIndexChanged_usingItems);
      // 
      // fileName
      // 
      fileName.Text = "File";
      fileName.Width = 550;
      // 
      // panelSourceBrowse
      // 
      panelSourceBrowse.Controls.Add(btnBrowseImages);
      panelSourceBrowse.Controls.Add(label1);
      panelSourceBrowse.Dock = System.Windows.Forms.DockStyle.Top;
      panelSourceBrowse.Location = new System.Drawing.Point(0, 0);
      panelSourceBrowse.Name = "panelSourceBrowse";
      panelSourceBrowse.Size = new System.Drawing.Size(516, 51);
      panelSourceBrowse.TabIndex = 0;
      // 
      // btnBrowseImages
      // 
      btnBrowseImages.BackColor = System.Drawing.Color.MediumAquamarine;
      btnBrowseImages.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      btnBrowseImages.UseVisualStyleBackColor = false;
      btnBrowseImages.AllowDrop = true;
      btnBrowseImages.Location = new System.Drawing.Point(20, 5);
      btnBrowseImages.Name = "btnBrowseImages";
      btnBrowseImages.Size = new System.Drawing.Size(250, 40);
      btnBrowseImages.TabIndex = 2;
      btnBrowseImages.Text = "Select Files";
      btnBrowseImages.UseVisualStyleBackColor = true;
      btnBrowseImages.Click += new System.EventHandler(ImgCompressor.ImgCompressor.BrowseInputFiles);
      // 
      // txtSourceImages
      // 
      txtSourceImages.AllowDrop = true;
      txtSourceImages.Location = new System.Drawing.Point(9, 25);
      txtSourceImages.Name = "txtSourceImages";
      txtSourceImages.Size = new System.Drawing.Size(457, 15);
      txtSourceImages.TabIndex = 1;
      // 
      // label1
      // 
      label1.AutoSize = true;
      label1.Location = new System.Drawing.Point(300, 17);
      label1.Name = "label1";
      label1.Size = new System.Drawing.Size(61, 20);
      label1.TabIndex = 0;
      label1.Text = "Files selected: 0   File size: 0.0 bytes";
      // 
      // tlpOutput
      // 
      tlpOutput.ColumnCount = 1;
      tlpOutput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
      tlpOutput.Controls.Add(btnCompress, 0, 3);
      tlpOutput.Controls.Add(flowLayoutPanel1, 0, 1);
      tlpOutput.Controls.Add(tlpInputFileList, 0, 0);
      tlpOutput.Controls.Add(tlpControls, 0, 2);
      tlpOutput.Dock = System.Windows.Forms.DockStyle.Fill;
      tlpOutput.Location = new System.Drawing.Point(525, 3);
      tlpOutput.Name = "tlpOutput";
      tlpOutput.RowCount = 4;
      tlpOutput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.24759F));
      tlpOutput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.199357F));
      tlpOutput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.26366F));
      tlpOutput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.967846F));
      tlpOutput.Size = new System.Drawing.Size(607, 599);
      tlpOutput.TabIndex = 3;
      // 
      // btnCompress
      // 
      btnCompress.BackColor = System.Drawing.Color.MediumAquamarine;
      btnCompress.Dock = System.Windows.Forms.DockStyle.Fill;
      btnCompress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      btnCompress.Location = new System.Drawing.Point(3, 540);
      btnCompress.Name = "btnCompress";
      btnCompress.Size = new System.Drawing.Size(601, 56);
      btnCompress.TabIndex = 10;
      btnCompress.Text = "Compress";
      btnCompress.UseVisualStyleBackColor = false;
      btnCompress.Click += new System.EventHandler(ImgCompressor.ImgCompressor.CompressAllImages);
      // 
      // flowLayoutPanel1
      // 
      flowLayoutPanel1.Controls.Add(label3);
      flowLayoutPanel1.Controls.Add(tbOutputFolder);
      flowLayoutPanel1.Controls.Add(btnBrowseOutputFolder);
      flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
      flowLayoutPanel1.Location = new System.Drawing.Point(3, 262);
      flowLayoutPanel1.Name = "flowLayoutPanel1";
      flowLayoutPanel1.Size = new System.Drawing.Size(601, 43);
      flowLayoutPanel1.TabIndex = 11;
      // 
      // label9
      // 
      label3.AutoSize = true;
      label3.Location = new System.Drawing.Point(3, 0);
      label3.Name = "label3";
      label3.Size = new System.Drawing.Size(104, 13);
      label3.TabIndex = 0;
      label3.Text = "Select Output Folder";
      // 
      // tbOutputFolder
      // 
      tbOutputFolder.Location = new System.Drawing.Point(3, 16);
      tbOutputFolder.Name = "tbOutputFolder";
      tbOutputFolder.Size = new System.Drawing.Size(534, 20);
      tbOutputFolder.TabIndex = 1;
      // 
      // btnBrowseOutputFolder
      // 
      btnBrowseOutputFolder.Anchor = System.Windows.Forms.AnchorStyles.None;
      btnBrowseOutputFolder.Location = new System.Drawing.Point(543, 16);
      btnBrowseOutputFolder.Name = "btnBrowseOutputFolder";
      btnBrowseOutputFolder.Size = new System.Drawing.Size(48, 20);
      btnBrowseOutputFolder.TabIndex = 2;
      btnBrowseOutputFolder.Text = "...";
      btnBrowseOutputFolder.UseVisualStyleBackColor = true;
      btnBrowseOutputFolder.Click += new System.EventHandler(ImgCompressor.ImgCompressor.BrowseOutputFolder);
      // 
      // tlpInputFileList
      // 
      tlpInputFileList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
      tlpInputFileList.AutoSize = true;
      tlpInputFileList.ColumnCount = 2;
      tlpInputFileList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.33333F));
      tlpInputFileList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.66667F));
      tlpInputFileList.Controls.Add(linkLabel1, 1, 0);
      tlpInputFileList.Controls.Add(pntControl, 0, 1);
      tlpInputFileList.Controls.Add(inputFileListView, 1, 1);
      tlpInputFileList.Location = new System.Drawing.Point(3, 3);
      tlpInputFileList.Name = "tlpInputFileList";
      tlpInputFileList.RowCount = 2;
      tlpInputFileList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
      tlpInputFileList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
      tlpInputFileList.Size = new System.Drawing.Size(601, 253);
      tlpInputFileList.TabIndex = 12;
      // 
      // linkLabel
      // 
      linkLabel1.AutoSize = true;
      linkLabel1.Dock = System.Windows.Forms.DockStyle.Right;
      linkLabel1.Location = new System.Drawing.Point(569, 0);
      linkLabel1.Name = "linkLabel1";
      linkLabel1.Size = new System.Drawing.Size(29, 20);
      linkLabel1.TabIndex = 1;
      linkLabel1.TabStop = true;
      linkLabel1.Text = "Help";
      linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(ImgCompressor.ImgCompressor.ShowHelp);
      // 
      // pntControl
      // 
      pntControl.Anchor = System.Windows.Forms.AnchorStyles.None;
      pntControl.Controls.Add(btnAdd);
      pntControl.Controls.Add(btnAddAll);
      pntControl.Controls.Add(btnRemove);
      pntControl.Controls.Add(btnRemoveAll);
      pntControl.Controls.Add(btnClear);
      pntControl.Location = new System.Drawing.Point(3, 50);
      pntControl.Name = "pntControl";
      pntControl.Size = new System.Drawing.Size(91, 172);
      pntControl.TabIndex = 0;
      // 
      // btnAdd
      // 
      btnAdd.Location = new System.Drawing.Point(3, 3);
      btnAdd.Name = "btnAdd";
      btnAdd.Size = new System.Drawing.Size(85, 23);
      btnAdd.TabIndex = 0;
      btnAdd.Text = "Add";
      btnAdd.UseVisualStyleBackColor = true;
      btnAdd.Click += new System.EventHandler(ImgCompressor.ImgCompressor.AddFileToInput);
      // 
      // btnAddAll
      // 
      btnAddAll.Location = new System.Drawing.Point(3, 32);
      btnAddAll.Name = "btnAddAll";
      btnAddAll.Size = new System.Drawing.Size(85, 23);
      btnAddAll.TabIndex = 1;
      btnAddAll.Text = "Add All";
      btnAddAll.UseVisualStyleBackColor = true;
      btnAddAll.Click += new System.EventHandler(ImgCompressor.ImgCompressor.AddAllFilesToInput);
      // 
      // btnRemove
      // 
      btnRemove.Location = new System.Drawing.Point(3, 61);
      btnRemove.Name = "btnRemove";
      btnRemove.Size = new System.Drawing.Size(85, 23);
      btnRemove.TabIndex = 2;
      btnRemove.Text = "Remove";
      btnRemove.UseVisualStyleBackColor = true;
      btnRemove.Click += new System.EventHandler(ImgCompressor.ImgCompressor.RemoveFileFromInput);
      // 
      // btnRemoveAll
      // 
      btnRemoveAll.Location = new System.Drawing.Point(3, 90);
      btnRemoveAll.Name = "btnRemoveAll";
      btnRemoveAll.Size = new System.Drawing.Size(85, 23);
      btnRemoveAll.TabIndex = 3;
      btnRemoveAll.Text = "Remove All";
      btnRemoveAll.UseVisualStyleBackColor = true;
      btnRemoveAll.Click += new System.EventHandler(ImgCompressor.ImgCompressor.RemoveAllFilesFromInput);
      // 
      // btnClear1
      // 
      btnClear.Location = new System.Drawing.Point(3, 119);
      btnClear.Name = "btnClear";
      btnClear.Size = new System.Drawing.Size(85, 23);
      btnClear.TabIndex = 5;
      btnClear.Text = "Clear All";
      btnClear.UseVisualStyleBackColor = true;
      btnClear.Click += new System.EventHandler(ImgCompressor.ImgCompressor.ClearFileList);
      // 
      // inputFileListView
      // 
      inputFileListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
      inputFileListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            inputFileName});
      inputFileListView.FullRowSelect = true;
      inputFileListView.GridLines = true;
      inputFileListView.HideSelection = false;
      inputFileListView.LabelEdit = true;
      inputFileListView.LabelWrap = false;
      inputFileListView.Location = new System.Drawing.Point(101, 23);
      inputFileListView.Name = "inputFileListView";
      inputFileListView.Size = new System.Drawing.Size(497, 227);
      inputFileListView.Sorting = System.Windows.Forms.SortOrder.Ascending;
      inputFileListView.TabIndex = 0;
      inputFileListView.UseCompatibleStateImageBehavior = false;
      inputFileListView.View = System.Windows.Forms.View.Details;
      inputFileListView.SelectedIndexChanged += new System.EventHandler(ImgCompressor.ImgCompressor.PreviewSelectedImage);
      // 
      // inputFileName
      // 
      inputFileName.Text = "Input File List";
      inputFileName.Width = 495;
      // 
      // tlpControls
      // 
      tlpControls.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
      tlpControls.AutoSize = true;
      tlpControls.ColumnCount = 2;
      tlpControls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61F));
      tlpControls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39F));
      tlpControls.Controls.Add(pbPreview, 0, 0);
      tlpControls.Controls.Add(tableLayoutPanel4, 1, 0);
      tlpControls.Location = new System.Drawing.Point(3, 311);
      tlpControls.Name = "tlpControls";
      tlpControls.RowCount = 1;
      tlpControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
      tlpControls.Size = new System.Drawing.Size(601, 223);
      tlpControls.TabIndex = 13;
      // 
      // pbPreview
      // 
      pbPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      pbPreview.Dock = System.Windows.Forms.DockStyle.Fill;
      pbPreview.ImageLocation = "";
      pbPreview.Location = new System.Drawing.Point(3, 3);
      pbPreview.Name = "pbPreview";
      pbPreview.Size = new System.Drawing.Size(360, 217);
      pbPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      pbPreview.TabIndex = 4;
      pbPreview.TabStop = false;
      pbPreview.Click += new System.EventHandler(ImgCompressor.ImgCompressor.CropImage);
      // 
      // tableLayoutPanel4
      // 
      tableLayoutPanel4.ColumnCount = 1;
      tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
      tableLayoutPanel4.Controls.Add(panel1, 0, 3);
      tableLayoutPanel4.Controls.Add(label4, 0, 2);
      tableLayoutPanel4.Controls.Add(drpResize, 0, 1);
      tableLayoutPanel4.Controls.Add(label2, 0, 0);
      tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Right;
      tableLayoutPanel4.Location = new System.Drawing.Point(370, 3);
      tableLayoutPanel4.Name = "tableLayoutPanel4";
      tableLayoutPanel4.RowCount = 5;
      tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.70492F));
      tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 62.29508F));
      tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
      tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 131F));
      tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
      tableLayoutPanel4.Size = new System.Drawing.Size(228, 217);
      tableLayoutPanel4.TabIndex = 5;
      // 
      // panel
      // 
      panel1.Controls.Add(lblQuality);
      panel1.Controls.Add(tbQuality);
      panel1.Dock = System.Windows.Forms.DockStyle.Fill;
      panel1.Location = new System.Drawing.Point(3, 68);
      panel1.Name = "panel1";
      panel1.Size = new System.Drawing.Size(222, 125);
      panel1.TabIndex = 8;
      // 
      // lblQuality
      // 
      lblQuality.AutoSize = true;
      lblQuality.Location = new System.Drawing.Point(95, 35);
      lblQuality.Name = "lblQuality";
      lblQuality.Size = new System.Drawing.Size(30, 13);
      lblQuality.TabIndex = 7;
      lblQuality.Text = "50 %";
      // 
      // tbQuality
      // 
      tbQuality.Cursor = System.Windows.Forms.Cursors.Arrow;
      tbQuality.Location = new System.Drawing.Point(0, 3);
      tbQuality.Maximum = 100;
      tbQuality.Name = "tbQuality";
      tbQuality.Size = new System.Drawing.Size(219, 45);
      tbQuality.SmallChange = 20;
      tbQuality.TabIndex = 5;
      tbQuality.TickFrequency = 5;
      tbQuality.Value = 50;
      tbQuality.ValueChanged += new System.EventHandler(ImgCompressor.ImgCompressor.TbQuality_ValueChanged);
      // 
      // label10
      // 
      label4.AutoSize = true;
      label4.Location = new System.Drawing.Point(3, 48);
      label4.Name = "label4";
      label4.Size = new System.Drawing.Size(39, 13);
      label4.TabIndex = 6;
      label4.Text = "Quality";
      // 
      // drpResize
      // 
      drpResize.CausesValidation = false;
      drpResize.Dock = System.Windows.Forms.DockStyle.Right;
      drpResize.FormattingEnabled = true;
      drpResize.Items.AddRange(new object[] {
            "Original",
            "320 X 240",
            "640 X 480 (0.3 MegaPixel)",
            "800 X 600 ",
            "1024 X 768 ",
            "1280 X 960 (1 MegaPixel)",
            "1536 X 1180",
            "1600 X 1200 (2 MegaPixel)",
            "2048 X 1536 (3 MegaPixel)",
            "2240 X 1680 (4 MegaPixel)",
            "2560 X 1920 (5 MegaPixel)",
            "3032 X 2008 (6 MegaPixel)",
            "3072 X 2304 (7 MegaPixel)",
            "3264 X 2448 (8 MegaPixel)"});
      drpResize.Location = new System.Drawing.Point(6, 21);
      drpResize.Name = "drpResize";
      drpResize.Size = new System.Drawing.Size(219, 21);
      drpResize.TabIndex = 0;
      // 
      // TDLoc
      // 
      TDLoc.Location = new System.Drawing.Point(27, 23);
      TDLoc.Name = "TDLoc";
      TDLoc.Size = new System.Drawing.Size(275, 20);
      TDLoc.TabIndex = 0;
      // 
      // TRLoc
      // 
      TRLoc.Location = new System.Drawing.Point(409, 23);
      TRLoc.Name = "TRLoc";
      TRLoc.Size = new System.Drawing.Size(275, 20);
      TRLoc.TabIndex = 1;
      //
      // password
      //
      password.Location = new System.Drawing.Point(409, 215);
      password.Size = new System.Drawing.Size(371, 20);
      password.PasswordChar = '*';
      // 
      // PicLoc
      // 
      PicLoc.Location = new System.Drawing.Point(27, 88);
      PicLoc.Name = "PicLoc";
      PicLoc.Size = new System.Drawing.Size(275, 20);
      PicLoc.TabIndex = 2;
      // 
      // WatermarkLoc
      // 
      WatermarkLoc.Location = new System.Drawing.Point(409, 88);
      WatermarkLoc.Name = "WatermarkLoc";
      WatermarkLoc.Size = new System.Drawing.Size(275, 20);
      WatermarkLoc.TabIndex = 3;
      // 
      // PDFOutLoc
      // 
      PDFOutLoc.Location = new System.Drawing.Point(27, 215);
      PDFOutLoc.Name = "PDFOutLoc";
      PDFOutLoc.Size = new System.Drawing.Size(275, 20);
      PDFOutLoc.TabIndex = 4;
      // 
      // FullName
      // 
      FullName.Location = new System.Drawing.Point(27, 155);
      FullName.Name = "FullName";
      FullName.Size = new System.Drawing.Size(368, 20);
      FullName.TabIndex = 5;
      // 
      // Title
      // 
      Title.Location = new System.Drawing.Point(409, 155);
      Title.Name = "Title";
      Title.Size = new System.Drawing.Size(371, 20);
      Title.TabIndex = 6;
      // 
      // BrowseTD
      // 
      BrowseTD.Location = new System.Drawing.Point(310, 23);
      BrowseTD.Name = "BrowseTD";
      BrowseTD.Size = new System.Drawing.Size(85, 20);
      BrowseTD.TabIndex = 10;
      BrowseTD.Text = "Browse";
      BrowseTD.Click += new System.EventHandler(DocSignAndDate.DocSignAndDate.BrowseTD_Click);
      // 
      // BrowseTR
      // 
      BrowseTR.Location = new System.Drawing.Point(695, 23);
      BrowseTR.Name = "BrowseTR";
      BrowseTR.Size = new System.Drawing.Size(85, 20);
      BrowseTR.TabIndex = 11;
      BrowseTR.Text = "Browse";
      BrowseTR.Click += new System.EventHandler(DocSignAndDate.DocSignAndDate.BrowseTR_Click);
      // 
      // BrowsePic
      // 
      BrowsePic.Location = new System.Drawing.Point(310, 88);
      BrowsePic.Name = "BrowsePic";
      BrowsePic.Size = new System.Drawing.Size(85, 20);
      BrowsePic.TabIndex = 9;
      BrowsePic.Text = "Browse";
      BrowsePic.Click += new System.EventHandler(DocSignAndDate.DocSignAndDate.BrowsePic_Click);
      // 
      // BrowseWatermark
      // 
      BrowseWatermark.Location = new System.Drawing.Point(695, 88);
      BrowseWatermark.Name = "BrowseWatermark";
      BrowseWatermark.Size = new System.Drawing.Size(85, 20);
      BrowseWatermark.TabIndex = 12;
      BrowseWatermark.Text = "Browse";
      BrowseWatermark.Click += new System.EventHandler(DocSignAndDate.DocSignAndDate.BrowseWatermark_Click);
      // 
      // BrowseOutput
      // 
      BrowseOutput.Location = new System.Drawing.Point(310, 215);
      BrowseOutput.Name = "BrowseOutput";
      BrowseOutput.Size = new System.Drawing.Size(85, 20);
      BrowseOutput.TabIndex = 8;
      BrowseOutput.Text = "Browse";
      BrowseOutput.Click += new System.EventHandler(DocSignAndDate.DocSignAndDate.BrowseOutput_Click);
      // 
      // Sign
      // 
      Sign.Location = new System.Drawing.Point(310, 259);
      Sign.Name = "Sign";
      Sign.Size = new System.Drawing.Size(180, 30);
      Sign.TabIndex = 13;
      Sign.Text = "Sign";
      Sign.Click += new System.EventHandler(DocSignAndDate.DocSignAndDate.Sign_Click);
      // 
      // TDLocLabel
      // 
      TDLocLabel.Location = new System.Drawing.Point(24, 5);
      TDLocLabel.Name = "TDLocLabel";
      TDLocLabel.Size = new System.Drawing.Size(278, 23);
      TDLocLabel.TabIndex = 14;
      TDLocLabel.Text = "Select test data record";
      // 
      // TRLocLabel
      // 
      TRLocLabel.Location = new System.Drawing.Point(406, 5);
      TRLocLabel.Name = "TRLocLabel";
      TRLocLabel.Size = new System.Drawing.Size(278, 23);
      TRLocLabel.TabIndex = 15;
      TRLocLabel.Text = "Select test report";
      // 
      // PicLocLabel
      // 
      PicLocLabel.Location = new System.Drawing.Point(24, 70);
      PicLocLabel.Name = "PicLocLabel";
      PicLocLabel.Size = new System.Drawing.Size(278, 23);
      PicLocLabel.TabIndex = 16;
      PicLocLabel.Text = "Select signature file";
      //
      // passLabel
      //
      passLabel.Location = new System.Drawing.Point(406, 197);
      passLabel.Name = "passLabel";
      passLabel.Size = new System.Drawing.Size(60, 23);
      passLabel.Text = "Password (for pdf permissions)";
      // 
      // WatermarkLocLabel
      // 
      WatermarkLocLabel.Location = new System.Drawing.Point(406, 70);
      WatermarkLocLabel.Name = "WatermarkLocLabel";
      WatermarkLocLabel.Size = new System.Drawing.Size(278, 23);
      WatermarkLocLabel.TabIndex = 17;
      WatermarkLocLabel.Text = "Select accreditation mark file";
      // 
      // PDFOutLocLabel
      // 
      PDFOutLocLabel.Location = new System.Drawing.Point(24, 197);
      PDFOutLocLabel.Name = "PDFOutLocLabel";
      PDFOutLocLabel.Size = new System.Drawing.Size(278, 23);
      PDFOutLocLabel.TabIndex = 18;
      PDFOutLocLabel.Text = "Select output location";
      // 
      // FullNameLabel
      // 
      FullNameLabel.Location = new System.Drawing.Point(24, 137);
      FullNameLabel.Name = "FullNameLabel";
      FullNameLabel.Size = new System.Drawing.Size(371, 23);
      FullNameLabel.TabIndex = 19;
      FullNameLabel.Text = "Enter your full name";
      // 
      // TitleLabel
      // 
      TitleLabel.Location = new System.Drawing.Point(406, 137);
      TitleLabel.Name = "TitleLabel";
      TitleLabel.Size = new System.Drawing.Size(374, 23);
      TitleLabel.TabIndex = 20;
      TitleLabel.Text = "Enter your job title";
      // 
      // progressLabel
      // 
      progressLabel.AutoSize = true;
      progressLabel.Location = new System.Drawing.Point(53, 317);
      progressLabel.MaximumSize = new System.Drawing.Size(497, 0);
      progressLabel.Name = "progressLabel";
      progressLabel.Size = new System.Drawing.Size(0, 13);
      progressLabel.TabIndex = 0;
      // 
      // primarySearchParam
      // 
      primarySearchParam.AcceptsTab = true;
      primarySearchParam.Location = new System.Drawing.Point(50, 40);
      primarySearchParam.Name = "primarySearchParam";
      primarySearchParam.Size = new System.Drawing.Size(500, 20);
      primarySearchParam.TabIndex = 0;
      // 
      // secondarySearchParam
      // 
      secondarySearchParam.AcceptsTab = true;
      secondarySearchParam.Location = new System.Drawing.Point(50, 100);
      secondarySearchParam.Name = "secondarySearchParam";
      secondarySearchParam.Size = new System.Drawing.Size(500, 20);
      secondarySearchParam.TabIndex = 2;
      // 
      // outDir
      // 
      outDir.Location = new System.Drawing.Point(50, 220);
      outDir.Name = "outDir";
      outDir.Size = new System.Drawing.Size(390, 20);
      outDir.TabIndex = 3;
      // 
      // directory
      // 
      directory.Location = new System.Drawing.Point(50, 160);
      directory.Name = "directory";
      directory.Size = new System.Drawing.Size(390, 20);
      directory.TabIndex = 9;
      // 
      // progress
      // 
      progress.Location = new System.Drawing.Point(50, 350);
      progress.Minimum = 1;
      progress.Name = "progress";
      progress.Size = new System.Drawing.Size(500, 40);
      progress.Step = 1;
      progress.TabIndex = 1;
      progress.Value = 1;
      progress.Visible = false;
      // 
      // search
      // 
      search.Location = new System.Drawing.Point(200, 280);
      search.Name = "search";
      search.Size = new System.Drawing.Size(200, 25);
      search.TabIndex = 4;
      search.Text = "Search";
      search.Click += new System.EventHandler(MultiTool.DocSearchTool.DocSearchTool.Search_Click);
      // 
      // browseOutput
      // 
      browseOutput.Location = new System.Drawing.Point(450, 220);
      browseOutput.Name = "browseOutput";
      browseOutput.Size = new System.Drawing.Size(100, 20);
      browseOutput.TabIndex = 11;
      browseOutput.Text = "Browse";
      browseOutput.Click += new System.EventHandler(MultiTool.DocSearchTool.DocSearchTool.BrowseOutputDST_Click);
      // 
      // browse
      // 
      browse.Location = new System.Drawing.Point(450, 160);
      browse.Name = "browse";
      browse.Size = new System.Drawing.Size(100, 20);
      browse.TabIndex = 10;
      browse.Text = "Browse";
      browse.Click += new System.EventHandler(MultiTool.DocSearchTool.DocSearchTool.Browse_Click);
      // 
      // primaryLabel
      // 
      primaryLabel.Location = new System.Drawing.Point(50, 25);
      primaryLabel.Name = "primaryLabel";
      primaryLabel.Size = new System.Drawing.Size(500, 40);
      primaryLabel.TabIndex = 5;
      primaryLabel.Text = "Enter primary search parameters";
      // 
      // secondaryLabel
      // 
      secondaryLabel.Location = new System.Drawing.Point(50, 85);
      secondaryLabel.Name = "secondaryLabel";
      secondaryLabel.Size = new System.Drawing.Size(500, 40);
      secondaryLabel.TabIndex = 6;
      secondaryLabel.Text = "Enter secondary search parameters (if applicable)";
      // 
      // dirLabel
      // 
      dirLabel.Location = new System.Drawing.Point(50, 145);
      dirLabel.Name = "dirLabel";
      dirLabel.Size = new System.Drawing.Size(100, 15);
      dirLabel.TabIndex = 7;
      dirLabel.Text = "Search Directory";
      // 
      // outDirLabel
      // 
      outDirLabel.Location = new System.Drawing.Point(50, 205);
      outDirLabel.Name = "outDirLabel";
      outDirLabel.Size = new System.Drawing.Size(400, 15);
      outDirLabel.TabIndex = 8;
      outDirLabel.Text = "Output Directory (Leave blank to save to search directory)";
      // 
      // deepSearchLabel
      // 
      deepSearchLabel.Location = new System.Drawing.Point(50, 285);
      deepSearchLabel.Name = "deepSearchLabel";
      deepSearchLabel.Size = new System.Drawing.Size(150, 50);
      deepSearchLabel.TabIndex = 14;
      deepSearchLabel.Text = "Search nested folders";
      // 
      // help
      // 
      help.Font = new System.Drawing.Font("Arial", 11F);
      help.Location = new System.Drawing.Point(500, 280);
      help.Name = "help";
      help.Size = new System.Drawing.Size(100, 100);
      help.TabIndex = 12;
      help.TabStop = true;
      help.Text = "Help";
      help.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(MultiTool.DocSearchTool.DocSearchTool.Help_LinkClicked);
      // 
      // searchDirectory
      // 
      searchDirectory.Description = "Select the folder you wish to search";
      searchDirectory.ShowNewFolderButton = false;
      // 
      // deepSearch
      // 
      deepSearch.Location = new System.Drawing.Point(160, 280);
      deepSearch.Name = "deepSearch";
      deepSearch.Size = new System.Drawing.Size(104, 24);
      deepSearch.TabIndex = 13;
      deepSearch.Click += new System.EventHandler(MultiTool.DocSearchTool.DocSearchTool.DeepSearch_Click);
      // 
      // label8
      // 
      label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)));
      label2.AutoSize = true;
      label2.Location = new System.Drawing.Point(3, 0);
      label2.Name = "label2";
      label2.Size = new System.Drawing.Size(39, 18);
      label2.TabIndex = 1;
      label2.Text = "Resize";
      // 
      // TDTR
      // 
      this.TDTR.Controls.Add(mainLayout);
      this.TDTR.Location = new System.Drawing.Point(4, 22);
      this.TDTR.Name = "TDTR";
      this.TDTR.Size = new System.Drawing.Size(1125, 539);
      this.TDTR.TabIndex = 1;
      this.TDTR.Text = "Test Data to Test Report";
      // 
      // renamer
      // 
      this.renamer.Controls.Add(panel);
      this.renamer.Controls.Add(lblUndoLastRename);
      this.renamer.Controls.Add(linkLabel);
      this.renamer.Controls.Add(btnReplace);
      this.renamer.Controls.Add(btnClear1);
      this.renamer.Controls.Add(btnRename);
      this.renamer.Controls.Add(cancelBtn);
      this.renamer.Controls.Add(groupBox1);
      this.renamer.Location = new System.Drawing.Point(4, 22);
      this.renamer.Name = "renamer";
      this.renamer.Size = new System.Drawing.Size(1125, 539);
      this.renamer.TabIndex = 2;
      this.renamer.Text = "Renamer";
      // 
      // docSignAndDate
      // 
      this.docSignAndDate.Controls.Add(TDLoc);
      this.docSignAndDate.Controls.Add(password);
      this.docSignAndDate.Controls.Add(passLabel);
      this.docSignAndDate.Controls.Add(TRLoc);
      this.docSignAndDate.Controls.Add(PicLoc);
      this.docSignAndDate.Controls.Add(WatermarkLoc);
      this.docSignAndDate.Controls.Add(PDFOutLoc);
      this.docSignAndDate.Controls.Add(FullName);
      this.docSignAndDate.Controls.Add(Title);
      this.docSignAndDate.Controls.Add(BrowseOutput);
      this.docSignAndDate.Controls.Add(BrowsePic);
      this.docSignAndDate.Controls.Add(BrowseTD);
      this.docSignAndDate.Controls.Add(BrowseTR);
      this.docSignAndDate.Controls.Add(BrowseWatermark);
      this.docSignAndDate.Controls.Add(Sign);
      this.docSignAndDate.Controls.Add(TDLocLabel);
      this.docSignAndDate.Controls.Add(TRLocLabel);
      this.docSignAndDate.Controls.Add(PicLocLabel);
      this.docSignAndDate.Controls.Add(WatermarkLocLabel);
      this.docSignAndDate.Controls.Add(PDFOutLocLabel);
      this.docSignAndDate.Controls.Add(FullNameLabel);
      this.docSignAndDate.Controls.Add(TitleLabel);
      this.docSignAndDate.Location = new System.Drawing.Point(4, 22);
      this.docSignAndDate.Name = "docSignAndDate";
      this.docSignAndDate.Size = new System.Drawing.Size(1125, 539);
      this.docSignAndDate.TabIndex = 3;
      this.docSignAndDate.Text = "Sign and Date";
      // 
      // docSearchTool
      // 
      this.docSearchTool.Controls.Add(progressLabel);
      this.docSearchTool.Controls.Add(primarySearchParam);
      this.docSearchTool.Controls.Add(progress);
      this.docSearchTool.Controls.Add(secondarySearchParam);
      this.docSearchTool.Controls.Add(outDir);
      this.docSearchTool.Controls.Add(search);
      this.docSearchTool.Controls.Add(primaryLabel);
      this.docSearchTool.Controls.Add(secondaryLabel);
      this.docSearchTool.Controls.Add(dirLabel);
      this.docSearchTool.Controls.Add(outDirLabel);
      this.docSearchTool.Controls.Add(directory);
      this.docSearchTool.Controls.Add(browse);
      this.docSearchTool.Controls.Add(browseOutput);
      this.docSearchTool.Controls.Add(help);
      this.docSearchTool.Controls.Add(deepSearch);
      this.docSearchTool.Controls.Add(deepSearchLabel);
      this.docSearchTool.Location = new System.Drawing.Point(4, 22);
      this.docSearchTool.Name = "docSearchTool";
      this.docSearchTool.Size = new System.Drawing.Size(1125, 539);
      this.docSearchTool.TabIndex = 4;
      this.docSearchTool.Text = "Document Search";
      // 
      // ofd
      // 
      ofd.Filter = "\"All Images  |*.jpg;*.jpeg;*.png;*.bmp\"";
      ofd.Multiselect = true;
      ofd.Title = "Select";
      // 
      // btnRename
      // 
      btnRename.BackColor = System.Drawing.Color.MediumSeaGreen;
      btnRename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      btnRename.Location = new System.Drawing.Point(777, 370);
      btnRename.Name = "btnRename";
      btnRename.Size = new System.Drawing.Size(90, 40);
      btnRename.TabIndex = 8;
      btnRename.Text = "Rename";
      btnRename.UseVisualStyleBackColor = false;
      btnRename.Click += new System.EventHandler(Renamer.Renamer.BtnRename_Click);
      // 
      // label7
      // 
      label7.AutoSize = true;
      label7.Location = new System.Drawing.Point(39, 50);
      label7.Name = "label1";
      label7.Size = new System.Drawing.Size(78, 20);
      label7.TabIndex = 0;
      label7.Text = "Unique Id";
      // 
      // uniqueIdInput
      // 
      uniqueIdInput.Location = new System.Drawing.Point(165, 50);
      uniqueIdInput.Name = "uniqueIdInput";
      uniqueIdInput.Size = new System.Drawing.Size(401, 26);
      uniqueIdInput.TabIndex = 1;
      uniqueIdInput.TextChanged += new System.EventHandler(Renamer.Renamer.UpdatePreviewText);
      // 
      // label8
      // 
      label8.AutoSize = true;
      label8.Location = new System.Drawing.Point(39, 93);
      label8.Name = "label2";
      label8.Size = new System.Drawing.Size(48, 20);
      label8.TabIndex = 2;
      label8.Text = "Prefix";
      // 
      // prefixInput
      // 
      prefixInput.Location = new System.Drawing.Point(165, 93);
      prefixInput.Name = "prefixInput";
      prefixInput.Size = new System.Drawing.Size(587, 26);
      prefixInput.TabIndex = 3;
      prefixInput.TextChanged += new System.EventHandler(Renamer.Renamer.UpdatePreviewText);
      // 
      // label9
      // 
      label9.AutoSize = true;
      label9.Location = new System.Drawing.Point(39, 142);
      label9.Name = "label3";
      label9.Size = new System.Drawing.Size(49, 20);
      label9.TabIndex = 4;
      label9.Text = "Suffix";
      // 
      // suffixInput
      // 
      suffixInput.Location = new System.Drawing.Point(165, 142);
      suffixInput.Name = "suffixInput";
      suffixInput.Size = new System.Drawing.Size(587, 26);
      suffixInput.TabIndex = 5;
      suffixInput.TextChanged += new System.EventHandler(Renamer.Renamer.UpdatePreviewText);
      // 
      // tbSourceDir
      // 
      tbSourceDir.Location = new System.Drawing.Point(165, 184);
      tbSourceDir.Name = "tbSourceDir";
      tbSourceDir.ReadOnly = true;
      tbSourceDir.Size = new System.Drawing.Size(587, 26);
      tbSourceDir.TabIndex = 11;
      // 
      // cancelBtn
      // 
      cancelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      cancelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      cancelBtn.Location = new System.Drawing.Point(55, 370);
      cancelBtn.Name = "cancelBtn";
      cancelBtn.Size = new System.Drawing.Size(90, 40);
      cancelBtn.TabIndex = 13;
      cancelBtn.Text = "Cancel";
      cancelBtn.UseVisualStyleBackColor = false;
      cancelBtn.Click += new System.EventHandler(Renamer.Renamer.CloseApplication);
      // 
      // groupBox1
      // 
      groupBox1.Controls.Add(pnlCopy);
      groupBox1.Controls.Add(cbCopyFiles);
      groupBox1.Controls.Add(btnBrowseSourceDir);
      groupBox1.Controls.Add(label11);
      groupBox1.Controls.Add(dpSeperator);
      groupBox1.Controls.Add(label10);
      groupBox1.Controls.Add(tbSourceDir);
      groupBox1.Controls.Add(uniqueIdInput);
      groupBox1.Controls.Add(label8);
      groupBox1.Controls.Add(label7);
      groupBox1.Controls.Add(prefixInput);
      groupBox1.Controls.Add(suffixInput);
      groupBox1.Controls.Add(label9);
      groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      groupBox1.Location = new System.Drawing.Point(12, 23);
      groupBox1.Name = "groupBox1";
      groupBox1.Size = new System.Drawing.Size(887, 286);
      groupBox1.TabIndex = 15;
      groupBox1.TabStop = false;
      groupBox1.Text = "Enter to Rename File";
      // 
      // pnlCopy
      // 
      pnlCopy.Controls.Add(label12);
      pnlCopy.Controls.Add(tbDestinationDir);
      pnlCopy.Controls.Add(btnBrowseDestinationDir);
      pnlCopy.Location = new System.Drawing.Point(165, 225);
      pnlCopy.Name = "pnlCopy";
      pnlCopy.Size = new System.Drawing.Size(719, 57);
      pnlCopy.TabIndex = 20;
      pnlCopy.Visible = false;
      // 
      // label12
      // 
      label12.AutoSize = true;
      label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      label12.Location = new System.Drawing.Point(3, 1);
      label12.Name = "label6";
      label12.Size = new System.Drawing.Size(121, 20);
      label12.TabIndex = 19;
      label12.Text = "Select Directory";
      // 
      // tbDestinationDir
      // 
      tbDestinationDir.Location = new System.Drawing.Point(3, 24);
      tbDestinationDir.Name = "tbDestinationDir";
      tbDestinationDir.ReadOnly = true;
      tbDestinationDir.Size = new System.Drawing.Size(584, 26);
      tbDestinationDir.TabIndex = 17;
      // 
      // btnBrowseDestinationDir
      // 
      btnBrowseDestinationDir.Location = new System.Drawing.Point(613, 24);
      btnBrowseDestinationDir.Name = "btnBrowseDestinationDir";
      btnBrowseDestinationDir.Size = new System.Drawing.Size(96, 26);
      btnBrowseDestinationDir.TabIndex = 18;
      btnBrowseDestinationDir.Text = "Browse";
      btnBrowseDestinationDir.UseVisualStyleBackColor = true;
      btnBrowseDestinationDir.Click += new System.EventHandler(Renamer.Renamer.BtnBrowseDestinationDir_Click);
      // 
      // cbCopyFiles
      // 
      cbCopyFiles.AutoSize = true;
      cbCopyFiles.Location = new System.Drawing.Point(43, 225);
      cbCopyFiles.Name = "cbCopyFiles";
      cbCopyFiles.Size = new System.Drawing.Size(101, 24);
      cbCopyFiles.TabIndex = 16;
      cbCopyFiles.Text = "Copy Files";
      cbCopyFiles.UseVisualStyleBackColor = true;
      cbCopyFiles.CheckedChanged += new System.EventHandler(Renamer.Renamer.CbCopyFiles_CheckedChanged);
      // 
      // btnBrowseSourceDir
      // 
      btnBrowseSourceDir.Location = new System.Drawing.Point(778, 184);
      btnBrowseSourceDir.Name = "btnBrowseSourceDir";
      btnBrowseSourceDir.Size = new System.Drawing.Size(96, 26);
      btnBrowseSourceDir.TabIndex = 15;
      btnBrowseSourceDir.Text = "Browse";
      btnBrowseSourceDir.UseVisualStyleBackColor = true;
      btnBrowseSourceDir.Click += new System.EventHandler(Renamer.Renamer.BtnBrowseSourceDir_Click);
      // 
      // label11
      // 
      label11.AutoSize = true;
      label11.Location = new System.Drawing.Point(38, 187);
      label11.Name = "label5";
      label11.Size = new System.Drawing.Size(121, 20);
      label11.TabIndex = 14;
      label11.Text = "Select Directory";
      // 
      // dpSeperator
      // 
      dpSeperator.DisplayMember = "a";
      dpSeperator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      dpSeperator.FormattingEnabled = true;
      dpSeperator.Items.AddRange(new object[] {
            "\"_\"    (UnderScore)",
            "\"-\"    (Dash )",
            "\" \"     (Space )"});
      dpSeperator.Location = new System.Drawing.Point(698, 50);
      dpSeperator.Name = "dpSeperator";
      dpSeperator.Size = new System.Drawing.Size(176, 28);
      dpSeperator.TabIndex = 13;
      dpSeperator.TextChanged += new System.EventHandler(Renamer.Renamer.UpdatePreviewText);
      // 
      // label10
      // 
      label10.AutoSize = true;
      label10.Location = new System.Drawing.Point(597, 56);
      label10.Name = "label4";
      label10.Size = new System.Drawing.Size(80, 20);
      label10.TabIndex = 12;
      label10.Text = "Seperator";
      // 
      // btnClear1
      // 
      btnClear1.BackColor = System.Drawing.SystemColors.InactiveBorder;
      btnClear1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      btnClear1.Location = new System.Drawing.Point(282, 370);
      btnClear1.Name = "btnClear";
      btnClear1.Size = new System.Drawing.Size(90, 40);
      btnClear1.TabIndex = 16;
      btnClear1.Text = "Clear All";
      btnClear1.UseVisualStyleBackColor = false;
      btnClear1.Click += new System.EventHandler(Renamer.Renamer.ClearAll);
      btnClear1.Click += new System.EventHandler(Renamer.Renamer.UpdatePreviewText);
      // 
      // linkLabel
      // 
      linkLabel.AutoSize = true;
      linkLabel.Location = new System.Drawing.Point(857, 9);
      linkLabel.Name = "linkLabel1";
      linkLabel.Size = new System.Drawing.Size(29, 13);
      linkLabel.TabIndex = 17;
      linkLabel.TabStop = true;
      linkLabel.Text = "Help";
      linkLabel.Click += new System.EventHandler(Renamer.Renamer.OpenHelp);
      // 
      // lblUndoLastRename
      // 
      lblUndoLastRename.AutoSize = true;
      lblUndoLastRename.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      lblUndoLastRename.Location = new System.Drawing.Point(727, 9);
      lblUndoLastRename.Name = "lblUndoLastRename";
      lblUndoLastRename.Size = new System.Drawing.Size(99, 13);
      lblUndoLastRename.TabIndex = 12;
      lblUndoLastRename.TabStop = true;
      lblUndoLastRename.Text = "Undo Last Rename";
      lblUndoLastRename.Visible = false;
      lblUndoLastRename.Click += new System.EventHandler(Renamer.Renamer.UndoLastRename);
      // 
      // lblPreview
      // 
      lblPreview.Dock = System.Windows.Forms.DockStyle.Fill;
      lblPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      lblPreview.ForeColor = System.Drawing.Color.DodgerBlue;
      lblPreview.Location = new System.Drawing.Point(0, 0);
      lblPreview.Name = "lblPreview";
      lblPreview.Size = new System.Drawing.Size(884, 57);
      lblPreview.TabIndex = 18;
      lblPreview.Text = "Example.doc";
      lblPreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // panel
      // 
      panel.Controls.Add(lblPreview);
      panel.Location = new System.Drawing.Point(12, 307);
      panel.Name = "panel1";
      panel.Size = new System.Drawing.Size(884, 57);
      panel.TabIndex = 19;
      // 
      // fbd1
      // 
      fbd1.RootFolder = System.Environment.SpecialFolder.DesktopDirectory;
      // 
      // btnReplace
      // 
      btnReplace.BackColor = System.Drawing.Color.PaleTurquoise;
      btnReplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      btnReplace.Location = new System.Drawing.Point(519, 370);
      btnReplace.Name = "btnReplace";
      btnReplace.Size = new System.Drawing.Size(90, 40);
      btnReplace.TabIndex = 16;
      btnReplace.Text = "Replace";
      btnReplace.UseVisualStyleBackColor = false;
      btnReplace.Click += new System.EventHandler(Renamer.Renamer.BtnReplace_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1133, 605);
      this.Controls.Add(this.tc);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "MainForm";
      this.Text = "Multi Tool";
      this.tc.ResumeLayout(false);
      this.imgCompressor.ResumeLayout(false);
      this.imgCompressor.PerformLayout();
      tlpMain.ResumeLayout(false);
      panelSource.ResumeLayout(false);
      panelListImages.ResumeLayout(false);
      panelSelectedFiles.ResumeLayout(false);
      panelSelectedFiles.PerformLayout();
      panelSourceBrowse.ResumeLayout(false);
      panelSourceBrowse.PerformLayout();
      tlpOutput.ResumeLayout(false);
      tlpOutput.PerformLayout();
      flowLayoutPanel1.ResumeLayout(false);
      flowLayoutPanel1.PerformLayout();
      tlpInputFileList.ResumeLayout(false);
      tlpInputFileList.PerformLayout();
      pntControl.ResumeLayout(false);
      tlpControls.ResumeLayout(false);
      tlpControls.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(pbPreview)).EndInit();
      tableLayoutPanel4.ResumeLayout(false);
      tableLayoutPanel4.PerformLayout();
      panel1.ResumeLayout(false);
      panel1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(tbQuality)).EndInit();
      mainLayout.ResumeLayout(false);
      mainLayout.PerformLayout();
      pnlDataRecordInput.ResumeLayout(false);
      pnlDataRecordInput.PerformLayout();
      pnlTestReportInput.ResumeLayout(false);
      pnlTestReportInput.PerformLayout();
      panelControls.ResumeLayout(false);
      panelControls.PerformLayout();
      groupBox1.ResumeLayout(false);
      groupBox1.PerformLayout();
      pnlCopy.ResumeLayout(false);
      pnlCopy.PerformLayout();
      panel.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion
  }
}
