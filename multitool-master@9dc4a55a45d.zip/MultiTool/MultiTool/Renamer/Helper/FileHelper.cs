﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace RenamerTool.Helper
{
    public static class FileHelper
    {
        /// <summary>
        /// Check if filename is a valid
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool IsValidFileName(string fileName)
        {
            var invalidFileChars = Path.GetInvalidFileNameChars();

            foreach (var ch in invalidFileChars)
            {
                if (fileName.Contains(ch)) { return false; }
            }

            return true;
        }

        /// <summary>
        /// Return New File Path 
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="destinationUrl"></param>
        /// <param name="sourceUrl"></param>
        /// <returns></returns>
        public static string GetNewPath(FileInfo fileInfo, string destinationUrl, string sourceUrl)
        {
            if (!string.IsNullOrEmpty(destinationUrl))
            {
                var newFilePath = destinationUrl + fileInfo.DirectoryName
                                    .Substring(sourceUrl.Length) + "\\";
                Directory.CreateDirectory(newFilePath);

                return newFilePath;
            }
            else
            {
                return fileInfo.DirectoryName + "\\";
            }
        }

        /// <summary>
        /// Return all files in the directory including the sub directories
        /// </summary>
        /// <param name="directory"></param>
        /// <returns></returns>
        public static List<string> GetAllFiles(string directory)
        {
            return Directory.GetFiles(directory, "*.*", SearchOption.AllDirectories).ToList();
        }

        /// <summary>
        /// Returns the file name of the first file inside the directory if exists
        /// </summary>
        /// <param name="directory"></param>
        /// <returns></returns>
        public static string GetFirstFileNameIfAny(string directory)
        {
            string fileName = string.Empty;
            if (!string.IsNullOrEmpty(directory))
            {
                string file = GetAllFiles(directory).FirstOrDefault();
                fileName = new FileInfo(file).Name;
            }
            return fileName;
        }

        /// <summary>
        /// Returns the New File Path
        /// </summary>
        /// <param name="fileNameHashTable"> Used to keep count of the file name and add
        /// the count if more than one exists in any sub directories</param>
        /// <param name="seperator"></param>
        /// <param name="fileInfo"></param>
        /// <param name="directory"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static string GetNewFilePath(Hashtable fileNameHashTable, string seperator,
            FileInfo fileInfo, string directory, string fileName)
        {
            //Check if FileName exists
            if (fileNameHashTable.ContainsKey(fileName))
            {
                fileNameHashTable[fileName] = (int)fileNameHashTable[fileName] + 1;
            }
            else
            {
                fileNameHashTable.Add(fileName, 0);
            }

            if ((int)fileNameHashTable[fileName] > 0)
            {
                fileName += seperator + fileNameHashTable[fileName];
            }

            fileName += Path.GetExtension(fileInfo.FullName);

            return directory + fileName;
        }
    }
}
