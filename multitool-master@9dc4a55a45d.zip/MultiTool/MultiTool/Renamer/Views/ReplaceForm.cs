﻿using RenamerTool.Helper;
using RenamerTool.Service;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace RenamerTool.Views
{
    public partial class ReplaceForm : Form
    {
        #region Properties and Constructors
        private string _selectedDir;

        public ReplaceForm()
        {
            InitializeComponent();
        }

        public ReplaceForm(string selectedDir) : this()
        {
            _selectedDir = selectedDir;
            tbSelectedDir.Text = selectedDir;
        }
        #endregion Properties and Constructors

        #region UI Elements
        private void BtnChangeDir_Click(object sender, EventArgs e)
        {
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                tbSelectedDir.Text = fbd.SelectedPath;
                UpdatePreviewText(sender, e);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnClearAll_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void BtnReplace_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbSelectedDir.Text))
            {
                ReplaceFiles();
            }
            else
            {
                MessageBox.Show("Please Select a Directory to fetch files!");
            }
        }
        #endregion UI Elements

        private void ReplaceFiles()
        {
            try
            {
                var files = FileHelper.GetAllFiles(tbSelectedDir.Text);

                var dialogResult = new MyMessageBox(files,
                    string.Format("Are you sure you want to change the following {0} files?",
                        files.Count), "Confirm?")
                    .ShowDialog();

                if (dialogResult == DialogResult.OK)
                {
                    var service = new ReplaceService(_selectedDir);

                    var fileList = service.ReplaceFiles(files, tbTextToReplace.Text,
                                                        tbTextRepalceWith.Text);
                    ShowSuccessMessage(fileList);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Reset();
            }
        }

        private void UpdatePreviewText(object sender, EventArgs e)
        {
            lblPreview.Text = FileHelper.GetFirstFileNameIfAny(tbSelectedDir.Text);

            try
            {
                var fileName = lblPreview.Text.Replace(tbTextToReplace.Text, tbTextRepalceWith.Text);

                if (FileHelper.IsValidFileName(fileName))
                {
                    lblPreview.ForeColor = System.Drawing.Color.DodgerBlue;
                    lblPreview.Text = fileName;
                    btnReplace.Enabled = true;
                }
                else
                {
                    lblPreview.Text = "A filename cannot contain any of the following " +
                                 "characters:\n  \\, /, :, *, ?, \", <, >, |";
                    lblPreview.ForeColor = System.Drawing.Color.Red;
                    btnReplace.Enabled = false;
                }
            }
            catch (Exception) { }
        }

        private void ShowSuccessMessage(Tuple<List<string>, List<string>> fileList)
        {
            var successfulFiles = fileList.Item1;
            var unSuccessfulFiles = fileList.Item2;

            if (successfulFiles.Count > 0)
            {
                new MyMessageBox(successfulFiles,
                    "Successful! Following " + successfulFiles.Count + " files were affected...",
                    "Success Report!").ShowDialog();
            }

            if (unSuccessfulFiles.Count > 0)
            {
                new MyMessageBox(unSuccessfulFiles,
                    "Unsuccessful !!! Following " + unSuccessfulFiles.Count +
                    " files were NOT affected.", "Failure Report!").ShowDialog();
            }
        }

        private void Reset()
        {
            tbSelectedDir.Text = string.Empty;
            tbTextToReplace.Text = string.Empty;
            tbTextRepalceWith.Text = string.Empty;
        }
    }
}
