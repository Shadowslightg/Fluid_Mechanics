﻿namespace RenamerTool.Views
{
    partial class ReplaceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.panel1 = new System.Windows.Forms.Panel();
      this.lblPreview = new System.Windows.Forms.Label();
      this.btnClearAll = new System.Windows.Forms.Button();
      this.btnChangeDir = new System.Windows.Forms.Button();
      this.label5 = new System.Windows.Forms.Label();
      this.fbd = new System.Windows.Forms.FolderBrowserDialog();
      this.btnCancel = new System.Windows.Forms.Button();
      this.tbSelectedDir = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.tbTextToReplace = new System.Windows.Forms.TextBox();
      this.tbTextRepalceWith = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.btnReplace = new System.Windows.Forms.Button();
      this.panel1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.lblPreview);
      this.panel1.Location = new System.Drawing.Point(15, 193);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(884, 57);
      this.panel1.TabIndex = 27;
      // 
      // lblPreview
      // 
      this.lblPreview.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lblPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
      this.lblPreview.ForeColor = System.Drawing.Color.DodgerBlue;
      this.lblPreview.Location = new System.Drawing.Point(0, 0);
      this.lblPreview.Name = "lblPreview";
      this.lblPreview.Size = new System.Drawing.Size(884, 57);
      this.lblPreview.TabIndex = 18;
      this.lblPreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // btnClearAll
      // 
      this.btnClearAll.BackColor = System.Drawing.SystemColors.InactiveBorder;
      this.btnClearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
      this.btnClearAll.Location = new System.Drawing.Point(407, 256);
      this.btnClearAll.Name = "btnClearAll";
      this.btnClearAll.Size = new System.Drawing.Size(90, 40);
      this.btnClearAll.TabIndex = 25;
      this.btnClearAll.Text = "Clear All";
      this.btnClearAll.UseVisualStyleBackColor = false;
      this.btnClearAll.Click += new System.EventHandler(this.BtnClearAll_Click);
      // 
      // btnChangeDir
      // 
      this.btnChangeDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      this.btnChangeDir.Location = new System.Drawing.Point(778, 46);
      this.btnChangeDir.Name = "btnChangeDir";
      this.btnChangeDir.Size = new System.Drawing.Size(80, 26);
      this.btnChangeDir.TabIndex = 15;
      this.btnChangeDir.Text = "Change";
      this.btnChangeDir.UseVisualStyleBackColor = true;
      this.btnChangeDir.Click += new System.EventHandler(this.BtnChangeDir_Click);
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(38, 49);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(139, 20);
      this.label5.TabIndex = 14;
      this.label5.Text = "Selected Directory";
      // 
      // btnCancel
      // 
      this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
      this.btnCancel.Location = new System.Drawing.Point(19, 256);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(90, 40);
      this.btnCancel.TabIndex = 22;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.UseVisualStyleBackColor = false;
      this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
      // 
      // tbSelectedDir
      // 
      this.tbSelectedDir.Location = new System.Drawing.Point(195, 46);
      this.tbSelectedDir.Name = "tbSelectedDir";
      this.tbSelectedDir.ReadOnly = true;
      this.tbSelectedDir.Size = new System.Drawing.Size(557, 26);
      this.tbSelectedDir.TabIndex = 11;
      this.tbSelectedDir.TextChanged += new System.EventHandler(this.UpdatePreviewText);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(39, 93);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(120, 20);
      this.label2.TabIndex = 2;
      this.label2.Text = "Text to Replace";
      // 
      // tbTextToReplace
      // 
      this.tbTextToReplace.Location = new System.Drawing.Point(195, 93);
      this.tbTextToReplace.Name = "tbTextToReplace";
      this.tbTextToReplace.Size = new System.Drawing.Size(557, 26);
      this.tbTextToReplace.TabIndex = 3;
      this.tbTextToReplace.TextChanged += new System.EventHandler(this.UpdatePreviewText);
      // 
      // tbTextRepalceWith
      // 
      this.tbTextRepalceWith.Location = new System.Drawing.Point(194, 142);
      this.tbTextRepalceWith.Name = "tbTextRepalceWith";
      this.tbTextRepalceWith.Size = new System.Drawing.Size(557, 26);
      this.tbTextRepalceWith.TabIndex = 5;
      this.tbTextRepalceWith.TextChanged += new System.EventHandler(this.UpdatePreviewText);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(39, 142);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(138, 20);
      this.label3.TabIndex = 4;
      this.label3.Text = "Text Replace With";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.btnChangeDir);
      this.groupBox1.Controls.Add(this.label5);
      this.groupBox1.Controls.Add(this.tbSelectedDir);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.tbTextToReplace);
      this.groupBox1.Controls.Add(this.tbTextRepalceWith);
      this.groupBox1.Controls.Add(this.label3);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
      this.groupBox1.Location = new System.Drawing.Point(12, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(887, 175);
      this.groupBox1.TabIndex = 23;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Enter to Replace Text in Files";
      // 
      // btnReplace
      // 
      this.btnReplace.BackColor = System.Drawing.Color.PaleTurquoise;
      this.btnReplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
      this.btnReplace.Location = new System.Drawing.Point(809, 256);
      this.btnReplace.Name = "btnReplace";
      this.btnReplace.Size = new System.Drawing.Size(90, 40);
      this.btnReplace.TabIndex = 24;
      this.btnReplace.Text = "Replace";
      this.btnReplace.UseVisualStyleBackColor = false;
      this.btnReplace.Click += new System.EventHandler(this.BtnReplace_Click);
      // 
      // ReplaceForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(915, 313);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.btnReplace);
      this.Controls.Add(this.btnClearAll);
      this.Controls.Add(this.btnCancel);
      this.Controls.Add(this.groupBox1);
      this.Name = "ReplaceForm";
      this.Text = "ReplaceForm";
      this.Load += new System.EventHandler(this.UpdatePreviewText);
      this.panel1.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblPreview;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Button btnChangeDir;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.FolderBrowserDialog fbd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox tbSelectedDir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbTextToReplace;
        private System.Windows.Forms.TextBox tbTextRepalceWith;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReplace;
    }
}