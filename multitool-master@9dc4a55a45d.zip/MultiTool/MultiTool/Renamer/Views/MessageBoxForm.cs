﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace RenamerTool.Views
{
    public partial class MyMessageBox : Form
    {
        public MyMessageBox()
        {
            InitializeComponent();
        }

        public MyMessageBox(List<string> files, string caption, string title) : this()
        {
            Text = title;

            gbListFile.Text = caption;

            foreach (string file in files)
            {
                lbFiles.Items.Add(file);
            }

            lbFiles.Show();
        }
    }
}
