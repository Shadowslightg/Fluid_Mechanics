﻿using RenamerTool.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace RenamerTool.Service
{
    public class RenamerService
    {
        #region Properties and Constructor
        public string UniqueID { get; set; }
        public string Seperator { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string SourceUrl { get; set; }
        public string DestinationUrl { get; set; }
        public Hashtable Logger { get; set; }
        public List<string> SuccessfulFiles { get; set; }
        public List<string> UnSuccessfulFiles { get; set; }
        public Hashtable FileNameHash { get; set; }

        public bool SaveCopy { get; set; }

        public RenamerService()
        {
            Logger = new Hashtable();
            SuccessfulFiles = new List<string>();
            UnSuccessfulFiles = new List<string>();
            FileNameHash = new Hashtable();
        }

        public RenamerService(string uniqueId, string seperator, string prefix, string suffix,
            string sourceDirPath, string destinationDirPath, bool saveCopy) : this()
        {
            UniqueID = uniqueId;
            Seperator = seperator;
            Prefix = prefix;
            Suffix = suffix;
            SourceUrl = sourceDirPath;
            DestinationUrl = destinationDirPath;
            SaveCopy = saveCopy;
        }
        #endregion Properties and Constructor

        public Tuple<List<string>, List<string>> RenameFiles(List<string> files)
        {
            foreach (string file in files)
            {
                RenameFile(file);
            }
            return new Tuple<List<string>, List<string>>(SuccessfulFiles, UnSuccessfulFiles);
        }


        /// <summary>
        /// Rename Files and add to the appropriate list and hash table
        /// </summary>
        /// <param name="oldFilePath"></param>
        private void RenameFile(string oldFilePath)
        {
            var fileInfo = new FileInfo(oldFilePath);
            var directory = FileHelper.GetNewPath(fileInfo, DestinationUrl, SourceUrl);
            var fileName = GetFileName(fileInfo);

            var newFilePath = FileHelper.GetNewFilePath(FileNameHash, Seperator,
                fileInfo, directory, fileName);

            try
            {
                if (string.IsNullOrEmpty(DestinationUrl))
                {
                    File.Move(oldFilePath, newFilePath);

                    // Log old and new filenames for undo renaming
                    Logger.Add(oldFilePath, newFilePath);
                }
                else
                {
                    File.Copy(oldFilePath, newFilePath);
                }
                SuccessfulFiles.Add(newFilePath);
            }
            catch (Exception)
            {
                UnSuccessfulFiles.Add(oldFilePath);
            }
        }

        /// <summary>
        /// Returns the renamed filename
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <returns></returns>
        private string GetFileName(FileInfo fileInfo)
        {
            return UniqueID + Seperator + Prefix +
                Path.GetFileNameWithoutExtension(fileInfo.FullName) + Suffix;
        }
    }
}