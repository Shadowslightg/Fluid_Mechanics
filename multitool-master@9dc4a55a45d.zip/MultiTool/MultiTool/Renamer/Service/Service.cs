﻿using RenamerTool.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace RenamerTool.Service
{
    public class Service
    {
        #region Properties and Constructor
        public string UniqueID { get; set; }
        public string Seperator { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string TextToReplace { get; private set; }
        public string TextReplaceWith { get; private set; }
        public string SourceUrl { get; set; }
        public string DestinationUrl { get; set; }
        public Hashtable Logger { get; set; }
        public List<string> SuccessfulFiles { get; set; }
        public List<string> UnSuccessfulFiles { get; set; }
        public Hashtable FileNameHash { get; set; }

        public Service()
        {
            Logger = new Hashtable();
            SuccessfulFiles = new List<string>();
            UnSuccessfulFiles = new List<string>();
            FileNameHash = new Hashtable();
        }

        public Service(string selectedDir) : this()
        {
            SourceUrl = selectedDir;
        }

        public Service(string selectedDir, string textToReplace, string textReplaceWith) : this(selectedDir)
        {
            TextToReplace = textToReplace;
            TextReplaceWith = textReplaceWith;
        }

        public Service(string uniqueId, string seperator, string prefix, string suffix,
            string sourceDirPath, string destinationDirPath) : this()
        {
            UniqueID = uniqueId;
            Seperator = seperator;
            Prefix = prefix;
            Suffix = suffix;
            SourceUrl = sourceDirPath;
            DestinationUrl = destinationDirPath;
        }
        #endregion Properties and Constructor

        public List<string> GetAllFiles()
        {
            return FileHelper.GetAllFiles(SourceUrl);
        }

        public Tuple<List<string>, List<string>> RenameFiles(List<string> files)
        {
            foreach (string file in files)
            {
                RenameFile(file);
            }
            return new Tuple<List<string>, List<string>>(SuccessfulFiles, UnSuccessfulFiles);
        }

        private void RenameFile(string oldFilePath)
        {
            string newFilePath = GetNewFilePath(new FileInfo(oldFilePath));

            try
            {
                if (DestinationUrl.Equals(string.Empty))
                {
                    File.Move(oldFilePath, newFilePath);
                    Logger.Add(oldFilePath, newFilePath);
                }
                else
                {
                    File.Copy(oldFilePath, newFilePath);
                }
                SuccessfulFiles.Add(newFilePath);
            }
            catch (Exception)
            {
                UnSuccessfulFiles.Add(oldFilePath);
            }
        }

        private string GetNewFilePath(FileInfo fileInfo)
        {
            string fileName = GetFileName(fileInfo);

            //Check if FileName exists
            if (FileNameHash.ContainsKey(fileName))
            {
                FileNameHash[fileName] = (int)FileNameHash[fileName] + 1;
            }
            else
            {
                FileNameHash.Add(fileName, 0);
            }

            if ((int)FileNameHash[fileName] > 0)
            {
                fileName += Seperator + FileNameHash[fileName];
            }

            fileName += Path.GetExtension(fileInfo.FullName);

            return FileHelper.GetNewPath(fileInfo, DestinationUrl, SourceUrl) + fileName;
        }

        private string GetFileName(FileInfo fileInfo)
        {
            return UniqueID + Seperator + Prefix + Path.GetFileNameWithoutExtension(fileInfo.FullName) + Suffix;
        }
    }
}