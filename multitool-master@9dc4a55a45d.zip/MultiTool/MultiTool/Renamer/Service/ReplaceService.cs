﻿using RenamerTool.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace RenamerTool.Service
{
    class ReplaceService
    {
        #region Properties and Constructor
        public string SelectedDir { get; set; }
        public List<string> SuccessfulFiles { get; set; }
        public List<string> UnSuccessfulFiles { get; set; }
        public Hashtable FileNameHash { get; set; }

        public ReplaceService()
        {
            SuccessfulFiles = new List<string>();
            UnSuccessfulFiles = new List<string>();
            FileNameHash = new Hashtable();
        }

        public ReplaceService(string selectedDir) : this()
        {
            SelectedDir = selectedDir;
        }

        #endregion Properties and Constructor

        public Tuple<List<string>, List<string>> ReplaceFiles(List<string> files,
            string oldValue, string newValue)
        {
            foreach (string file in files)
            {
                ReplaceFile(file, oldValue, newValue);
            }
            return new Tuple<List<string>, List<string>>(SuccessfulFiles, UnSuccessfulFiles);
        }

        /// <summary>
        /// Replace specific string in filename with the given value
        /// </summary>
        /// <param name="oldFilePath"></param>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        private void ReplaceFile(string oldFilePath, string oldValue, string newValue)
        {
            var fileInfo = new FileInfo(oldFilePath);
            var directory = fileInfo.DirectoryName + "\\";
            var fileName = GetFileName(fileInfo, oldValue, newValue);

            var newFilePath = FileHelper.GetNewFilePath(FileNameHash, "", fileInfo, directory, fileName);

            try
            {
                File.Move(oldFilePath, newFilePath);
                SuccessfulFiles.Add(newFilePath);
            }
            catch (Exception)
            {
                UnSuccessfulFiles.Add(oldFilePath);
            }
        }

        /// <summary>
        /// Replace the string and return the filename
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        /// <returns></returns>
        private string GetFileName(FileInfo fileInfo, string oldValue, string newValue)
        {
            return Path.GetFileNameWithoutExtension(fileInfo.FullName)
                                  .Replace(oldValue, newValue);
        }
    }
}
