﻿using RenamerTool.Helper;
using RenamerTool.Service;
using RenamerTool.Views;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace MultiTool.Renamer
{
  class Renamer
  {
    public Renamer(MainForm mainForm)
    {
      mf = mainForm;
      MainForm.dpSeperator.SelectedIndex = 0;
      MainForm.drpResize.SelectedIndex = 10;
    }

    private static RenamerService _service;
    static MainForm mf;

    public static void BtnBrowseSourceDir_Click(object sender, EventArgs e)
    {
      if (MainForm.fbd.ShowDialog() == DialogResult.OK)
      {
        MainForm.tbSourceDir.Text = MainForm.fbd.SelectedPath;
        UpdatePreviewText(sender, e);
      }
    }

    public static void BtnBrowseDestinationDir_Click(object sender, EventArgs e)
    {
      if (MainForm.fbd.ShowDialog() == DialogResult.OK)
      {
        MainForm.tbDestinationDir.Text = MainForm.fbd.SelectedPath;
      }
    }

    public static void BtnRename_Click(object sender, EventArgs e)
    {
      if (!string.IsNullOrEmpty(MainForm.tbSourceDir.Text))
      {
        var saveCopy = false;

        if (MainForm.cbCopyFiles.Checked)
        {
          if (string.IsNullOrEmpty(MainForm.tbDestinationDir.Text))
          {
            MessageBox.Show("Please Select Destination Directory!");
            return;
          }
          else
          {
            saveCopy = true;
          }
        }
        RenameFiles(saveCopy);
      }
      else { MessageBox.Show("Please Select a Directory to fetch files!"); }

      MainForm.lblUndoLastRename.Visible = true;
    }

    public static void BtnReplace_Click(object sender, EventArgs e)
    {
      new ReplaceForm(MainForm.tbSourceDir.Text).ShowDialog();
    }

    public static void ClearAll(object sender, EventArgs e)
    {
      Reset();
    }

    public static void OpenHelp(object sender, EventArgs e)
    {
      System.Diagnostics.Process.Start("https://confluence.metro.ad.selinc.com/x/LQRkGQ");
    }

    public static void CloseApplication(object sender, EventArgs e)
    {
      mf.Close();
    }

    public static void CbCopyFiles_CheckedChanged(object sender, EventArgs e)
    {
      MainForm.pnlCopy.Visible = MainForm.cbCopyFiles.Checked;
    }

    public static void UndoLastRename(object sender, EventArgs e)
    {
      var log = _service.Logger;

      if (log.Count > 0)
      {
        var files = new List<string>();

        foreach (DictionaryEntry item in log)
        {
          files.Add(item.Key.ToString());
        }
        var dialogResult = new MyMessageBox(files, "Rollback " + log.Count +
                    " items to original file names?", "Undo Changes").ShowDialog();

        if (dialogResult == DialogResult.OK)
        {
          try
          {
            foreach (DictionaryEntry item in log)
            {
              File.Move(item.Value.ToString(), item.Key.ToString());
            }

            log.Clear();
            Reset();
          }
          catch (Exception ex)
          {
            MessageBox.Show(ex.Message);
          }
        }
      }
      else
      {
        MessageBox.Show("No Previous record found.", "Cannot Rollback!!!");
      }
    }

    public static void UpdatePreviewText(object sender, EventArgs e)
    {
      var fileNameWithoutExtension = "Example";
      var extension = ".doc";

      if (!string.IsNullOrEmpty(MainForm.tbSourceDir.Text))
      {
        var fullName = new FileInfo(FileHelper.GetFirstFileNameIfAny(MainForm.tbSourceDir.Text))
                                      .FullName;

        fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fullName);

        extension = Path.GetExtension(fullName);
      }

      var newFileName = MainForm.uniqueIdInput.Text + GetSeperatorString() + MainForm.prefixInput.Text +
                           fileNameWithoutExtension + MainForm.suffixInput.Text + extension;

      if (FileHelper.IsValidFileName(newFileName))
      {
        MainForm.lblPreview.ForeColor = System.Drawing.Color.DodgerBlue;
        MainForm.lblPreview.Text = newFileName;
        MainForm.btnRename.Enabled = true;
      }
      else
      {
        MainForm.lblPreview.Text = "A filename cannot contain any of the following characters " +
            ":\n  \\, /, :, *, ?, \", <, >, |";
        MainForm.lblPreview.ForeColor = System.Drawing.Color.Red;
        MainForm.btnRename.Enabled = false;
      }
    }

    private static void RenameFiles(bool saveCopy)
    {
      try
      {
        var files = FileHelper.GetAllFiles(MainForm.tbSourceDir.Text);

        var dialogResult = new MyMessageBox(files,
                "Are you sure you want to change the following "
                 + files.Count + " files?", "Confirm?").ShowDialog();

        if (dialogResult == DialogResult.OK)
        {
          _service = new RenamerService(MainForm.uniqueIdInput.Text, GetSeperatorString(),
              MainForm.prefixInput.Text, MainForm.suffixInput.Text, MainForm.tbSourceDir.Text,
              MainForm.tbDestinationDir.Text, saveCopy);

          var fileList = _service.RenameFiles(files);
          ShowSuccessMessage(fileList);
        }
      }
      catch (Exception ex) { MessageBox.Show(ex.Message); }
      finally { Reset(); }
    }

    private static void ShowSuccessMessage(Tuple<List<string>, List<string>> fileList)
    {
      var successfulFiles = fileList.Item1;
      var unSuccessfulFiles = fileList.Item2;

      if (successfulFiles.Count > 0)
      {
        new MyMessageBox(successfulFiles,
            "Successful! Following " + successfulFiles.Count + " files were affected...",
            "Success Report!").ShowDialog();
      }

      if (unSuccessfulFiles.Count > 0)
      {
        new MyMessageBox(unSuccessfulFiles,
            "Unsuccessful !!! Following " + unSuccessfulFiles.Count +
            " files were NOT affected.", "Failure Report!").ShowDialog();
      }
    }

    private static void Reset()
    {
      MainForm.uniqueIdInput.Text = string.Empty;
      MainForm.prefixInput.Text = string.Empty;
      MainForm.suffixInput.Text = string.Empty;
      MainForm.tbSourceDir.Text = string.Empty;
      MainForm.cbCopyFiles.Checked = false;
      MainForm.tbDestinationDir.Text = string.Empty;
      MainForm.lblPreview.Text = string.Empty;
    }

    private static string GetSeperatorString()
    {
      switch (MainForm.dpSeperator.SelectedIndex)
      {
        case 0: return "_";
        case 1: return "-";
        default: return " ";
      }
    }
  }
}
