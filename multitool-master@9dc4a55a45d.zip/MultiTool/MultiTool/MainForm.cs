﻿using IWshRuntimeLibrary;
using SEL.SoftwareComponents.Logic;
using System;
using System.ComponentModel;
using System.Deployment.Application;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace MultiTool
{
  public partial class MainForm : Form
  {
    public MainForm()
    {
      InitializeComponent();
      dpSeperator.SelectedIndex = 0;
      drpResize.SelectedIndex = 10;
      tc.SelectedIndexChanged += new EventHandler(Tabs_SelectedIndexChanged);
      CheckForUpdate();
    }

    public static void CreateShortcut(string shortcutName)
    {
      WshShell wsh = new WshShell();
      IWshShortcut shortcut = wsh.CreateShortcut(
      Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + shortcutName + ".lnk") as IWshShortcut;
      shortcut.Arguments = "";
      shortcut.TargetPath = "\\\\faraday.ad.selinc.com\\vol3\\Compliance Documents\\99-Other\\Software\\MultiTool\\setup.exe";
      shortcut.WindowStyle = 1;
      shortcut.Description = "Document Multi-Tool";
      shortcut.IconLocation = "\\\\faraday.ad.selinc.com\\vol3\\Compliance Documents\\99-Other\\Software\\MultiTool\\icon.ico";
      shortcut.Save();
    }

    public static void CrashReport(object sender, UnhandledExceptionEventArgs e)
    {
      EmailHandler.Send("ethan_simpson@selinc.com", "ethan_simpson@selinc.com", "Bug report", e.ExceptionObject.GetType().ToString() + "thrown in document multi-tool.\n\n" + e.ExceptionObject);
      MessageBox.Show("Something went wrong. A crash report has been sent to the developer.", "Fatal error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      Application.Exit();
    }

    public void Tabs_SelectedIndexChanged(object sender, EventArgs e)
    {
      Menu = new MainMenu();
      if (tc.SelectedTab == imgCompressor)
      {
        ImgCompressor.ImgCompressor imgCompressor = new ImgCompressor.ImgCompressor(this);
        Menu.Dispose();
        ClientSize = new Size(1133, 605);
      }
      else if (tc.SelectedTab == TDTR)
      {
        TDTR.TDTR tdtr = new TDTR.TDTR(this);
        Menu.Dispose();
        ClientSize = new Size(808, 264);
      }
      else if (tc.SelectedTab == renamer)
      {
        Renamer.Renamer renamer = new Renamer.Renamer(this);
        Menu.Dispose();
        ClientSize = new Size(913, 445);
      }
      else if (tc.SelectedTab == docSignAndDate)
      {
        DocSignAndDate.DocSignAndDate docSignAndDate = new DocSignAndDate.DocSignAndDate(this);
        MenuItem file = new MenuItem("File");
        Menu.MenuItems.Add(file);
        Menu.MenuItems.Add("Help", new EventHandler(DocSignAndDate.DocSignAndDate.Help_Click));
        file.MenuItems.Add("Sign", new EventHandler(DocSignAndDate.DocSignAndDate.Sign_Click));
        file.MenuItems.Add("Settings", new EventHandler(DocSignAndDate.DocSignAndDate.Settings_Click));
        file.MenuItems.Add("Exit", new EventHandler(DocSignAndDate.DocSignAndDate.Exit_Click));
        ClientSize = new Size(800, 335);
      }
      else
      {
        DocSearchTool.DocSearchTool docSearchTool = new DocSearchTool.DocSearchTool(this);
        Menu.Dispose();
        ClientSize = new Size(600, 345);
      }
    }

    #region UIElements
    public TabControl tc;
    public TabPage docSearchTool;
    public TabPage docSignAndDate;
    public TabPage TDTR;
    public TabPage renamer;
    public TabPage imgCompressor;

    // Image Compressor
    public static TableLayoutPanel tlpMain = new TableLayoutPanel();
    public static Panel panelSource = new Panel();
    public static Panel panelListImages = new Panel();
    public static Panel panelSourceBrowse = new Panel();
    public static Panel panelSelectedFiles = new Panel();
    public static Button btnBrowseImages = new Button();
    public static TextBox txtSourceImages = new TextBox();
    public static Label label1 = new Label();
    public static Button btnRemoveAll = new Button();
    public static Button btnRemove = new Button();
    public static Button btnAddAll = new Button();
    public static Button btnAdd = new Button();
    public static Label label2 = new Label();
    public static Button btnBrowseOutputFolder = new Button();
    public static OpenFileDialog ofd = new OpenFileDialog();
    public static ListView selectedFileListView = new ListView();
    public static ColumnHeader fileName = new ColumnHeader();
    public static ColumnHeader inputFileName = new ColumnHeader();
    public static FolderBrowserDialog fbd = new FolderBrowserDialog();
    public static Label lblFileSelectedInfo = new Label();
    public static ListView inputFileListView = new ListView();
    public static ComboBox drpResize = new ComboBox();
    public static TextBox tbOutputFolder = new TextBox();
    public static Label lblQuality = new Label();
    public static Label label4 = new Label();
    public static TrackBar tbQuality = new TrackBar();
    public static Button btnClear = new Button();
    public static TableLayoutPanel tlpOutput = new TableLayoutPanel();
    public static Button btnCompress = new Button();
    public static FlowLayoutPanel flowLayoutPanel1 = new FlowLayoutPanel();
    public static Label label3 = new Label();
    public static TableLayoutPanel tlpInputFileList = new TableLayoutPanel();
    public static FlowLayoutPanel pntControl = new FlowLayoutPanel();
    public static TableLayoutPanel tlpControls = new TableLayoutPanel();
    public static TableLayoutPanel tableLayoutPanel4 = new TableLayoutPanel();
    public static Panel panel1 = new Panel();
    public static PictureBox pbPreview = new PictureBox();
    public static LinkLabel linkLabel1 = new LinkLabel();

    // Test Data to Test Report
    public static TableLayoutPanel mainLayout = new TableLayoutPanel();
    public static Panel pnlDataRecordInput = new Panel();
    public static Button btnBrowseDataRecord = new Button();
    public static Label label5 = new Label();
    public static Panel pnlTestReportInput = new Panel();
    public static Button btnBrowseTestReport = new Button();
    public static Label label6 = new Label();
    public static OpenFileDialog ofd2 = new OpenFileDialog();
    public static BackgroundWorker bgWorker = new BackgroundWorker();
    public static TextBox tbDataRecord = new TextBox();
    public static TextBox tbTestReport = new TextBox();
    public static SaveFileDialog sfd = new SaveFileDialog();
    public static LinkLabel linkHelp = new LinkLabel();
    public static Panel panelControls = new Panel();
    public static Label lblProgress = new Label();
    public static ProgressBar progressBar = new ProgressBar();
    public static Button btnTransfer = new Button();
    public static CheckBox cbCopyTableNumber = new CheckBox();

    // Renamer
    public static Button btnRename = new Button();
    public static Label label7 = new Label();
    public static TextBox uniqueIdInput = new TextBox();
    public static Label label8 = new Label();
    public static TextBox prefixInput = new TextBox();
    public static Label label9 = new Label();
    public static TextBox suffixInput = new TextBox();
    public static TextBox tbSourceDir = new TextBox();
    public static Button cancelBtn = new Button();
    public static GroupBox groupBox1 = new GroupBox();
    public static Button btnClear1 = new Button();
    public static LinkLabel linkLabel = new LinkLabel();
    public static LinkLabel lblUndoLastRename = new LinkLabel();
    public static ComboBox dpSeperator = new ComboBox();
    public static Label label10 = new Label();
    public static Panel panel = new Panel();
    public static FolderBrowserDialog fbd1 = new FolderBrowserDialog();
    public static Label label11 = new Label();
    public static Button btnBrowseSourceDir = new Button();
    public static CheckBox cbCopyFiles = new CheckBox();
    public static Button btnBrowseDestinationDir = new Button();
    public static TextBox tbDestinationDir = new TextBox();
    public static Panel pnlCopy = new Panel();
    public static Label label12 = new Label();
    public static Label lblPreview = new Label();
    public static Button btnReplace = new Button();

    // Sign and Date Tool
    public static TextBox TDLoc = new TextBox();
    public static TextBox password = new TextBox();
    public static TextBox TRLoc = new TextBox();
    public static TextBox PicLoc = new TextBox();
    public static TextBox WatermarkLoc = new TextBox();
    public static TextBox PDFOutLoc = new TextBox();
    public static TextBox FullName = new TextBox();
    public static TextBox Title = new TextBox();
    public static Button BrowseTD = new Button();
    public static Button BrowseTR = new Button();
    public static Button BrowsePic = new Button();
    public static Button BrowseWatermark = new Button();
    public static Button BrowseOutput = new Button();
    public static Button Sign = new Button();
    public static Label TDLocLabel = new Label();
    public static Label passLabel = new Label();
    public static Label TRLocLabel = new Label();
    public static Label PicLocLabel = new Label();
    public static Label WatermarkLocLabel = new Label();
    public static Label PDFOutLocLabel = new Label();
    public static Label FullNameLabel = new Label();
    public static Label TitleLabel = new Label();
    public static OpenFileDialog TDBrowser = new OpenFileDialog();
    public static OpenFileDialog TRBrowser = new OpenFileDialog();
    public static OpenFileDialog PicBrowser = new OpenFileDialog();
    public static OpenFileDialog WatermarkBrowser = new OpenFileDialog();
    public static FolderBrowserDialog OutputBrowser = new FolderBrowserDialog();

    // Document Search Tool
    public static TextBox primarySearchParam = new TextBox();
    public static TextBox secondarySearchParam = new TextBox();
    public static TextBox directory = new TextBox();
    public static TextBox outDir = new TextBox();
    public static FolderBrowserDialog searchDirectory = new FolderBrowserDialog();
    public static FolderBrowserDialog outputDirectory = new FolderBrowserDialog();
    public static Button search = new Button();
    public static Button browse = new Button();
    public static Button browseOutput = new Button();
    public static Label progressLabel = new Label();
    public static Label primaryLabel = new Label();
    public static Label secondaryLabel = new Label();
    public static Label dirLabel = new Label();
    public static Label outDirLabel = new Label();
    public static Label deepSearchLabel = new Label();
    public static LinkLabel help = new LinkLabel();
    public static CheckBox deepSearch = new CheckBox();
    public static ProgressBar progress = new ProgressBar();
    #endregion

    private bool CheckForUpdate()
    {
      try
      {
        if (ApplicationDeployment.IsNetworkDeployed)
        {
          ApplicationDeployment ad = ApplicationDeployment.CurrentDeployment;
          ad.CheckForDetailedUpdate(false);
          if (ad.IsFirstRun)
          {
            CreateShortcut("Document Multi-Tool");
          }
          if (ad.CheckForUpdate())
          {
            if (MessageBox.Show("The current version is: " + ad.CurrentVersion + "." + Environment.NewLine + "A newer version is available. Do you want to update to the latest version?", "Update Available!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
              DoUpdate(ad);
            }
          }
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error checking for updates: " + ex.Message);
      }
      return false;
    }

    private void DoUpdate(ApplicationDeployment ad)
    {
      ad.Update();

      MessageBox.Show("Application updated successfully to " + ad.UpdatedVersion + Environment.NewLine + "The application will restart now.", "Success!");

      Application.Restart();
      Environment.Exit(0);
    }
  }
}
