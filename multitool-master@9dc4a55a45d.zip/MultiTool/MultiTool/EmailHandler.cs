﻿// Copyright © 2017 Schweitzer Engineering Laboratories, Inc.
// SEL Confidential
using System;
using System.Collections.Generic;
using System.Net.Mail;

namespace SEL.SoftwareComponents.Logic
{
    public static class EmailHandler
    {
        #region Properties

        public static bool IsDebugMode { get; set; }

        public static MailMessage DebugMessage { get; set; }

        #endregion

        #region SendMethods

        public static void Send(MailMessage email)
        {
            SmtpClient client = new SmtpClient();

            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = true;
            client.Host = "mail.ad.selinc.com";

            try
            {
                if(IsDebugMode)
                {
                    DebugMessage = email;
                }
                else
                {
                    client.Send(email);
                    email.Dispose();
                }
            }
            catch (SmtpException e)
            {
                Console.Write(e.InnerException.Message);
            }

            return;
        }

        public static void Send(SmtpClient client, MailMessage email)
        {
            try
            {
                if (IsDebugMode)
                {
                    DebugMessage = email;
                }
                else
                {
                    client.Send(email);
                    email.Dispose();
                }
            }
            catch (SmtpException e)
            {
                Console.Write(e.InnerException.Message);
            }

            return;
        }

        public static void Send(string recipient, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipient, from, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(string recipient, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipient, from, CC, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(string recipient, string attachment, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipient, attachment, from, CC, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(IEnumerable<string> recipients, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipients, from, CC, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(IEnumerable<string> recipients, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipients, from, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(IEnumerable<string> recipients, IEnumerable<string> attachments, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipients, attachments, from, CC, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(IEnumerable<string> recipients, IEnumerable<string> attachments, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipients, attachments, from, subject, body, isHtml);
            Send(email);

            return;
        }

        public static void Send(IEnumerable<string> recipients, IEnumerable<string> attachments, IEnumerable<string> CC, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = CreateEmail(recipients, attachments, CC, from, subject, body, isHtml);
            Send(email);

            return;
        }

        #endregion

        #region CreateMethods

        public static MailMessage CreateEmail(string recipient, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Subject = subject;
            email.Body = body;
            email.From = new MailAddress(from);
            email.To.Add(new MailAddress(recipient));

            email.IsBodyHtml = isHtml;

            return email;
        }

        public static MailMessage CreateEmail(string recipient, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Body = body;
            email.Subject = subject;
            email.IsBodyHtml = isHtml;

            email.From = new MailAddress(from);
            email.CC.Add(new MailAddress(CC));
            email.To.Add(new MailAddress(recipient));

            return email;
        }

        public static MailMessage CreateEmail(string recipient, string attachment, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Body = body;
            email.Subject = subject;
            email.IsBodyHtml = isHtml;

            email.From = new MailAddress(from);
            email.CC.Add(new MailAddress(CC));
            email.To.Add(new MailAddress(recipient));
            email.Attachments.Add(new Attachment(attachment));

            return email;
        }

        public static MailMessage CreateEmail(IEnumerable<string> recipients, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = isHtml;
            email.From = new MailAddress(from);

            foreach (string recipient in recipients)
            {
                email.To.Add(new MailAddress(recipient));
            }

            return email;
        }

        public static MailMessage CreateEmail(IEnumerable<string> recipients, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Body = body;
            email.Subject = subject;
            email.IsBodyHtml = isHtml;

            email.From = new MailAddress(from);
            email.CC.Add(new MailAddress(CC));

            foreach (string recipient in recipients)
            {
                email.To.Add(new MailAddress(recipient));
            }

            return email;
        }

        public static MailMessage CreateEmail(IEnumerable<string> recipients, IEnumerable<string> attachments, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = isHtml;
            email.From = new MailAddress(from);

            foreach (string recipient in recipients)
            {
                email.To.Add(new MailAddress(recipient));
            }

            foreach (string attachment in attachments)
            {
                email.Attachments.Add(new Attachment(attachment));
            }

            return email;
        }

        public static MailMessage CreateEmail(IEnumerable<string> recipients, IEnumerable<string> attachments, string from, string CC, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Body = body;
            email.Subject = subject;
            email.IsBodyHtml = isHtml;

            email.From = new MailAddress(from);
            email.CC.Add(new MailAddress(CC));

            foreach (string recipient in recipients)
            {
                email.To.Add(new MailAddress(recipient));
            }

            foreach (string attachment in attachments)
            {
                email.Attachments.Add(new Attachment(attachment));
            }

            return email;
        }

        public static MailMessage CreateEmail(IEnumerable<string> recipients, IEnumerable<string> attachments, IEnumerable<string> CC, string from, string subject, string body, bool isHtml = false)
        {
            MailMessage email = new MailMessage();

            email.Body = body;
            email.Subject = subject;
            email.IsBodyHtml = isHtml;
            email.From = new MailAddress(from);

            foreach (string recipient in recipients)
            {
                email.To.Add(new MailAddress(recipient));
            }

            foreach (string attachment in attachments)
            {
                email.Attachments.Add(new Attachment(attachment));
            }

            foreach (string recipient in CC)
            {
                email.CC.Add(new MailAddress(recipient));
            }

            return email;
        }

        #endregion
    }
}
