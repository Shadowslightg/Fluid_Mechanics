﻿using ImageCompressor.Helper;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace ImageCompressor.Service
{
    public class ImageCompressorService
    {
        public long Quality { get; set; }
        public string OutputFolder { get; set; }
        public string ImageResolution { get; set; }

        public ImageCompressorService()
        {
        }

        public ImageCompressorService(long quality, string outputFilePath,
            string imageResolution) : this()
        {
            Quality = quality;
            OutputFolder = outputFilePath;
            ImageResolution = imageResolution;
        }

        /// <summary>
        /// Compresses the image defined by the fileinfo using the given quality
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="quality"></param>
        /// <returns>Path of the compressed image</returns>
        public string CompressImage(string fileName)
        {
            var fileInfo = new FileInfo(fileName);

            Image image = new Bitmap(fileInfo.FullName);

            if (!string.IsNullOrEmpty(ImageResolution) || !ImageResolution.ToLower().Equals("original"))
            {
                var resolution = ImageResolution.Split('(');

                resolution = resolution[0].Split('X');
                int height = Convert.ToInt32(resolution[1]);
                int width = Convert.ToInt32(resolution[0]);

                image = ImageHelper.ScaleImage(image, height, width);
            }


            using (var eps = new EncoderParameters(1))
            {
                eps.Param[0] = new EncoderParameter(Encoder.Quality, Quality);

                var ici = ImageHelper.GetEncoderInfo(fileInfo.Name);

                var outputFilepath = ImageHelper.GetOutputFilePath(OutputFolder, fileInfo);

                image.Save(outputFilepath, ici, eps);

                image.Dispose();

                return outputFilepath;
            }
        }
    }
}
