﻿using ImageCompressor.Helper;
using ImageCompressor.Views;
using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace MultiTool.ImgCompressor
{
  class ImgCompressor : IDisposable
  {
    private readonly DataTable _dataTable;
    private static string _selectedImagePath;
    private static ListViewItem _focusedItem;
    private static Image _previewImage;
    static MainForm mf;

    public ImgCompressor(MainForm mainForm)
    {
      mf = mainForm;
      _dataTable = new DataTable();
      _selectedImagePath = string.Empty;
    }

    enum ByteSize { bytes, kb, mb, gb, tb };

    public static void SelectedFileListView_SelectedIndexChanged_usingItems(object sender, EventArgs e)
    {
      ListView.SelectedListViewItemCollection selectedItems = MainForm.selectedFileListView.SelectedItems;
      double fileSize = 0;
      double fileCount = 0;
      foreach (ListViewItem item in selectedItems)
      {
        fileCount++;
        FileInfo info = new FileInfo(item.Text);
        fileSize += info.Length;
      }
      ByteSize size = ByteSize.bytes;
      while (fileSize > 1024)
      {
        fileSize /= 1024;
        size++;
      }
      if(fileCount == 0)
      {
        MainForm.label1.Text = "Files selected: 0   File size: 0.0 bytes";
        MainForm.label1.Refresh();
        return;
      }
      MainForm.label1.Text = "Files selected: " + fileCount + "   File size: " + fileSize.ToString("0.0") + " " + size;
      MainForm.label1.Refresh();
    }

    public static void BrowseInputFiles(object sender, EventArgs e)
    {
      if (MainForm.ofd.ShowDialog() == DialogResult.OK)
      {
        var items = MainForm.ofd.FileNames;

        foreach (var item in items)
        {
          MainForm.selectedFileListView.Items.Add(
              new ListViewItem(new[] { item }));
        }
      }
      MainForm.ofd.Dispose();
    }

    public static void AddFileToInput(object sender, EventArgs e)
    {
      foreach (ListViewItem item in MainForm.selectedFileListView.SelectedItems)
      {
        MainForm.selectedFileListView.Items.Remove(item);
        MainForm.inputFileListView.Items.Add(item);
        item.Selected = false;
      }
    }

    public static void AddAllFilesToInput(object sender, EventArgs e)
    {
      foreach (ListViewItem item in MainForm.selectedFileListView.Items)
      {
        MainForm.selectedFileListView.Items.Remove(item);
        MainForm.inputFileListView.Items.Add(item);
        item.Selected = false;
      }
    }

    public static void RemoveFileFromInput(object sender, EventArgs e)
    {
      foreach (ListViewItem item in MainForm.inputFileListView.SelectedItems)
      {
        MainForm.inputFileListView.Items.Remove(item);
        MainForm.selectedFileListView.Items.Add(item);
        item.Selected = false;
      }
    }

    public static void RemoveAllFilesFromInput(object sender, EventArgs e)
    {
      foreach (ListViewItem item in MainForm.inputFileListView.Items)
      {
        MainForm.inputFileListView.Items.Remove(item);
        MainForm.selectedFileListView.Items.Add(item);
        item.Selected = false;
      }
    }

    public static void PreviewSelectedImage(object sender, EventArgs e)
    {
      _focusedItem = ((ListView)sender).FocusedItem;
      if (_focusedItem != null)
      {
        _selectedImagePath = ((ListView)sender).FocusedItem.Text;
        PreviewImage();
      }
    }

    public static void BrowseOutputFolder(object sender, EventArgs e)
    {
      if (MainForm.fbd.ShowDialog() == DialogResult.OK)
      {
        MainForm.tbOutputFolder.Text = MainForm.fbd.SelectedPath;
      }
      MainForm.fbd.Dispose();
    }

    public static void CompressAllImages(object sender, EventArgs e)
    {
      if (!string.IsNullOrEmpty(MainForm.tbOutputFolder.Text))
      {
        var dialogResult = new ProcessingFormDialog(MainForm.tbQuality.Value,
                MainForm.inputFileListView, MainForm.tbOutputFolder.Text, MainForm.drpResize.Text)
            .ShowDialog();
      }
      else
      {
        MessageBox.Show("Please select Output folder!");
        MainForm.tbOutputFolder.Focus();
      }
    }

    public static void ClearFileList(object sender, EventArgs e)
    {
      MainForm.selectedFileListView.Items.Clear();
      MainForm.label1.Text = "Files selected: 0   File size: 0.0 bytes";
      MainForm.label1.Refresh();
    }

    public static void CropImage(object sender, EventArgs e)
    {
      if (MainForm.selectedFileListView.SelectedItems.Count == 1)
      {
        var cropImage = new CropImage(MainForm.selectedFileListView.SelectedItems[0].Text);
        cropImage.Show();
      }

    }

    public static void TbQuality_ValueChanged(object sender, EventArgs e)
    {
      MainForm.lblQuality.Text = MainForm.tbQuality.Value + " %";

      if (_focusedItem != null)
      {
        MainForm.pbPreview.Image = null;
        if (_previewImage != null)
        {
          _previewImage.Dispose();
        }
        PreviewImage();
      }
    }

    public static void ShowHelp(object sender, LinkLabelLinkClickedEventArgs e)
    {
      System.Diagnostics.Process.Start("https://confluence.metro.ad.selinc.com/x/1IDIGQ");
    }

    private static void PreviewImage()
    {
      var fileInfo = new FileInfo(_selectedImagePath);
      var eps = new EncoderParameters(1);
      eps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, MainForm.tbQuality.Value);

      var ici = ImageHelper.GetEncoderInfo(fileInfo.Name);

      string temp = fileInfo.DirectoryName + "\\preview" + fileInfo.Extension;

      System.Drawing.Image tempImage = new Bitmap(_selectedImagePath);

      tempImage = ImageHelper.ScaleImage(tempImage, MainForm.pbPreview.Height, MainForm.pbPreview.Width);
      tempImage = tempImage.GetThumbnailImage(tempImage.Width, tempImage.Height,
          () => false, IntPtr.Zero);
      tempImage.Save(temp, ici, eps);

      using (var bmpTemp = new Bitmap(temp))
      {
        _previewImage = new Bitmap(bmpTemp);
        MainForm.pbPreview.Image = _previewImage;
      }

      tempImage.Dispose();
      eps.Dispose();
      File.Delete(temp);
      GC.Collect();
    }

    #region IDisposable Support
    private bool disposedValue = false; // To detect redundant calls

    protected virtual void Dispose(bool disposing)
    {
      if (!disposedValue)
      {
        if (disposing)
        {
          _dataTable.Dispose();
          // TODO: dispose managed state (managed objects).
        }

        // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
        // TODO: set large fields to null.

        disposedValue = true;
      }
    }

    // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
    // ~ImgCompressor() {
    //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
    //   Dispose(false);
    // }

    // This code added to correctly implement the disposable pattern.
    public void Dispose()
    {
      // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
      Dispose(true);
      // TODO: uncomment the following line if the finalizer is overridden above.
      // GC.SuppressFinalize(this);
    }
    #endregion
  }
}
