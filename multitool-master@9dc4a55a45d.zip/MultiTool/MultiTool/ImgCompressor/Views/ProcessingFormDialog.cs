﻿using ImageCompressor.Helper;
using ImageCompressor.Service;
using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ImageCompressor.Views
{
    public partial class ProcessingFormDialog : Form
    {
        private int _quality;
        private ListView _inputFileListView;
        private string _outputFolder;
        private string _imageResolution;
        private DataTable _dataTable;

        public ProcessingFormDialog()
        {
            InitializeComponent();
        }

        public ProcessingFormDialog(int quality, ListView inputFileListView, string outputFolder,
            string imageResolution) : this()
        {
            _quality = quality;
            _inputFileListView = inputFileListView;
            _outputFolder = outputFolder;
            _imageResolution = imageResolution;
        }

        private void ProcessingFormDialog_Load(object sender, EventArgs e)
        {
            _dataTable = new DataTable();

            _dataTable.Columns.Add("S.N.", typeof(int));
            _dataTable.Columns.Add("Input FileName", typeof(string));
            _dataTable.Columns.Add("Output FileName", typeof(string));
            _dataTable.Columns.Add("Information", typeof(string));
            _dataTable.Columns.Add("Old Size", typeof(string));
            _dataTable.Columns.Add("New Size", typeof(string));

            imageProcessingView.DataSource = _dataTable;
        }

        private void ProcessingFormDialog_Shown(object sender, EventArgs e)
        {
            CompressAllImages(_dataTable, imageProcessingView);

            btnClose.Enabled = true;
        }

        private void CompressAllImages(DataTable table, DataGridView ipv)
        {
            var service = new ImageCompressorService(_quality, _outputFolder, _imageResolution);

            table.Rows.Clear();

            foreach (ListViewItem item in _inputFileListView.Items)
            {
                ipv.Refresh();
                ipv.FirstDisplayedScrollingRowIndex = ipv.RowCount - 1;

                var status = "Completed";

                try
                {
                    var compressedImage = service.CompressImage(item.Text);

                    var oldSize = new FileInfo(item.Text).Length / 1024;

                    var fileInfo = new FileInfo(compressedImage);
                    var newSize = Convert.ToInt32(fileInfo.Length / 1024);

                    if (newSize >= oldSize)
                    {
                        File.Copy(item.Text, compressedImage, true);
                        status = "No Compression";
                    }
                    table.Rows.Add(item.Index + 1, fileInfo.Name, compressedImage,
                                          status, oldSize + " Kb", newSize + " Kb");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Close(object sender, EventArgs e)
        {
            Close();
        }

        private void ShowImage(object sender, DataGridViewCellEventArgs e)
        {
            if (imageProcessingView.SelectedRows.Count != 0)
            {
                var row = imageProcessingView.SelectedRows[0];
                var filePath = row.Cells["Output FileName"].Value.ToString();
                Process.Start(filePath);
            }
        }
    }
}
