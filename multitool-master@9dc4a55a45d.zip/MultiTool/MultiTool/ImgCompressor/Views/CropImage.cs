﻿using ImageCompressor.Helper;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace ImageCompressor.Views
{
    public partial class CropImage : Form
    {
        #region Properties and Constructors
        private Bitmap _originalImage;
        private string _originalPath;

        private Point _rectStartPoint;
        private Point _tempEndPoint;
        private Rectangle _rectangle;
        private Pen _selectionPen;

        public CropImage()
        {
            InitializeComponent();
            _rectangle = new Rectangle();
            _selectionPen = new Pen(Color.Yellow, 4);
        }

        public CropImage(string originalPath) : this()
        {
            _originalPath = originalPath;
            _originalImage = new Bitmap(originalPath);

            pBCropImage.Image = ImageHelper.ScaleImage(_originalImage,
                pBCropImage.Height, pBCropImage.Width);
        }

        #endregion Properties and Constructors

        #region UI Elements
        private void PBCropImage_MouseDown(object sender, MouseEventArgs e)
        {
            _rectStartPoint = e.Location;
            Invalidate();
        }

        private void PBCropImage_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
                return;
            _tempEndPoint = e.Location;
            _rectangle.Location = new Point(
                Math.Min(_rectStartPoint.X, _tempEndPoint.X),
                Math.Min(_rectStartPoint.Y, _tempEndPoint.Y));
            _rectangle.Size = new Size(
                Math.Abs(_rectStartPoint.X - _tempEndPoint.X),
                Math.Abs(_rectStartPoint.Y - _tempEndPoint.Y));
            pBCropImage.Invalidate();
        }

        private void PBCropImage_MouseUp(object sender, MouseEventArgs e)
        {
            var dialogResult = MessageBox.Show("Do you want to save the cropped Image?",
                "Confirm", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                SaveImage(_originalImage);
            }
        }

        private void PBCropImage_Paint(object sender, PaintEventArgs e)
        {
            if (pBCropImage.Image != null)
            {
                if (_rectangle != null && _rectangle.Width > 0 && _rectangle.Height > 0)
                {
                    e.Graphics.DrawRectangle(_selectionPen, _rectangle);
                    lbtSelection.Text = " Width: " + _rectangle.Size.Width +
                                        " Height: " + _rectangle.Size.Height;
                }
            }
        }

        #endregion UI Elements

        #region Private Methods

        public void SaveImage(Bitmap originalImage)
        {
            var section = GetSelectedRectangle();

            using (var bmp = new Bitmap(section.Width, section.Height, originalImage.PixelFormat))
            {
                bmp.SetResolution(originalImage.HorizontalResolution, originalImage.VerticalResolution);

                DrawImage(bmp, originalImage, section);

                // Save Image
                var fileInfo = new FileInfo(_originalPath);
                var path = fileInfo.Directory + "\\CroppedImages\\";
                Directory.CreateDirectory(path);
                sfd.FileName = path + fileInfo.Name;
                sfd.Filter = "Images|*.jpg";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    bmp.Save(sfd.FileName, ImageFormat.Jpeg);
                }
            }
        }

        private void DrawImage(Bitmap bmp, Bitmap originalImage, Rectangle section)
        {
            using (var graphics = Graphics.FromImage(bmp))
            {
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;

                graphics.DrawImage(originalImage, 0, 0, section, GraphicsUnit.Pixel);
            }
        }

        private Rectangle GetSelectedRectangle()
        {
            var startX = _originalImage.Width / (double)pBCropImage.Image.Width * _rectangle.Location.X;
            var startY = _originalImage.Height / (double)pBCropImage.Image.Height * _rectangle.Location.Y;

            var width = _originalImage.Width / (double)pBCropImage.Image.Width * _rectangle.Size.Width;
            var height = _originalImage.Height / (double)pBCropImage.Image.Height * _rectangle.Size.Height;

            return new Rectangle((int)startX, (int)startY, (int)width, (int)height);

        }
        #endregion Private Methods
    }
}
