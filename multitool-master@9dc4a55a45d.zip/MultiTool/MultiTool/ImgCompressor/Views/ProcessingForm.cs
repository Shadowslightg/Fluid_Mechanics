﻿using MultiTool;
using System;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;

namespace ImageCompressor
{
    public partial class ProcessingFormDialog : Form
    {
        internal DataTable table = null;
        internal MainForm mainForm;

        public ProcessingFormDialog()
        {
            InitializeComponent();
        }

        public ProcessingFormDialog(DataTable table, MainForm mainForm) : this()
        {
            this.table = table;
            this.mainForm = mainForm;
            imageProcessingView.DataSource = GetDataSource();
        }

        private DataTable GetDataSource()
        {
            if (table.Columns.Count == 0)
            {
                AddColumnHeader(table);
            }
            return table;
        }

        private void AddColumnHeader(DataTable table)
        {
            table.Columns.Add("S.N.", typeof(int));
            table.Columns.Add("Input FileName", typeof(string));
            table.Columns.Add("Output FileName", typeof(string));
            table.Columns.Add("Information", typeof(string));
            table.Columns.Add("Old Size", typeof(string));
            table.Columns.Add("New Size", typeof(string));
        }

        private void Close(object sender, EventArgs e)
        {
            table.Clear();
            this.Close();
            mainForm.Enabled = true;
        }

        private void ShowImage(object sender, DataGridViewCellEventArgs e)
        {
            if (imageProcessingView.SelectedRows.Count != 0)
            {
                DataGridViewRow row = imageProcessingView.SelectedRows[0];
                string filePath = row.Cells["Output FileName"].Value.ToString();
                Process.Start(filePath);
            }
        }

        private void EnableMainForm(object sender, FormClosedEventArgs e)
        {
            mainForm.Enabled = true;
        }
    }
}
