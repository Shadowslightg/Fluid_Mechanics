﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace ImageCompressor.Helper
{
    static class ImageHelper
    {
        public static ImageCodecInfo GetEncoderInfo(string fileName)
        {
            var mimeType = GetMimeType(fileName);

            var encoders = ImageCodecInfo.GetImageEncoders();

            for (int j = 0; j < encoders.Length; ++j)
            {
                if (encoders[j].MimeType == mimeType)
                    return encoders[j];
            }
            return null;
        }

        // Scale Image Maintaining Aspect Ratio
        public static Bitmap ScaleImage(Image image, int height, int width)
        {
            var size = GetImageSize(image, height, width);

            var newImage = new Bitmap(image, size.Width, size.Height);

            return newImage;
        }

        private static string GetMimeType(string fileName)
        {
            var mimeType = "application/unknown";
            var ext = Path.GetExtension(fileName).ToLower();

            var regKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(ext);

            if (regKey != null && regKey.GetValue("Content Type") != null)
            {
                mimeType = regKey.GetValue("Content Type").ToString();
            }
            return mimeType;
        }

        private static Size GetImageSize(Image oldImage, int newHeight, int newWidth)
        {
            var size = new Size();
            double resizeFactor = 1;

            if (oldImage.Width > newWidth || oldImage.Height > newHeight)
            {
                double widthFactor = Convert.ToDouble(oldImage.Width) / newWidth;
                double heightFactor = Convert.ToDouble(oldImage.Height) / newHeight;
                resizeFactor = Math.Max(widthFactor, heightFactor);
            }

            size.Width = Convert.ToInt32(oldImage.Width / resizeFactor);
            size.Height = Convert.ToInt32(oldImage.Height / resizeFactor);

            return size;
        }

        public static string GetOutputFilePath(string outputFolder, FileInfo fileInfo)
        {
            var outputFilepath = outputFolder + "\\" + fileInfo.Name;

            if (fileInfo.FullName.Equals(outputFilepath))
            {
                string outputDir = fileInfo.DirectoryName + "\\Compressed\\";
                if (!Directory.Exists(outputDir))
                {
                    Directory.CreateDirectory(outputDir);
                }
                outputFilepath = outputDir + fileInfo.Name;
            }

            return outputFilepath;
        }
    }
}
