﻿namespace SignAndDate
{
  partial class SettingsForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsForm));
      this.OK = new System.Windows.Forms.Button();
      this.cancel = new System.Windows.Forms.Button();
      this.signatureSizeLabel = new System.Windows.Forms.Label();
      this.nameTitleFormatLabel = new System.Windows.Forms.Label();
      this.signatureSize = new System.Windows.Forms.TrackBar();
      this.nameTitleFormat = new System.Windows.Forms.CheckBox();
      this.pb = new System.Windows.Forms.PictureBox();
      ((System.ComponentModel.ISupportInitialize)(this.signatureSize)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
      this.SuspendLayout();
      // 
      // OK
      // 
      this.OK.Location = new System.Drawing.Point(279, 203);
      this.OK.Name = "OK";
      this.OK.Size = new System.Drawing.Size(75, 23);
      this.OK.TabIndex = 4;
      this.OK.Text = "Save";
      this.OK.Click += new System.EventHandler(this.Save_Click);
      // 
      // cancel
      // 
      this.cancel.Location = new System.Drawing.Point(360, 203);
      this.cancel.Name = "cancel";
      this.cancel.Size = new System.Drawing.Size(75, 23);
      this.cancel.TabIndex = 0;
      this.cancel.Text = "Cancel";
      this.cancel.Click += new System.EventHandler(this.Cancel_Click);
      // 
      // signatureSizeLabel
      // 
      this.signatureSizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.signatureSizeLabel.Location = new System.Drawing.Point(39, 21);
      this.signatureSizeLabel.Name = "signatureSizeLabel";
      this.signatureSizeLabel.Size = new System.Drawing.Size(115, 21);
      this.signatureSizeLabel.TabIndex = 1;
      this.signatureSizeLabel.Text = "Signature size";
      // 
      // nameTitleFormatLabel
      // 
      this.nameTitleFormatLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nameTitleFormatLabel.Location = new System.Drawing.Point(39, 206);
      this.nameTitleFormatLabel.Name = "nameTitleFormatLabel";
      this.nameTitleFormatLabel.Size = new System.Drawing.Size(171, 23);
      this.nameTitleFormatLabel.TabIndex = 3;
      this.nameTitleFormatLabel.Text = "Single row name and title";
      // 
      // signatureSize
      // 
      this.signatureSize.LargeChange = 1;
      this.signatureSize.Location = new System.Drawing.Point(35, 45);
      this.signatureSize.Name = "signatureSize";
      this.signatureSize.Size = new System.Drawing.Size(372, 45);
      this.signatureSize.TabIndex = 0;
      this.signatureSize.Value = 5;
      this.signatureSize.ValueChanged += new System.EventHandler(this.ImgSlider_Scroll);
      // 
      // nameTitleFormat
      // 
      this.nameTitleFormat.Location = new System.Drawing.Point(216, 206);
      this.nameTitleFormat.Name = "nameTitleFormat";
      this.nameTitleFormat.Size = new System.Drawing.Size(26, 24);
      this.nameTitleFormat.TabIndex = 2;
      // 
      // pb
      // 
      this.pb.Image = ((System.Drawing.Image)(resources.GetObject("pb.Image")));
      this.pb.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb.InitialImage")));
      this.pb.Location = new System.Drawing.Point(85, 103);
      this.pb.Name = "pb";
      this.pb.Size = new System.Drawing.Size(270, 65);
      this.pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.pb.TabIndex = 5;
      this.pb.TabStop = false;
      // 
      // SettingsForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(456, 244);
      this.Controls.Add(this.signatureSize);
      this.Controls.Add(this.signatureSizeLabel);
      this.Controls.Add(this.nameTitleFormat);
      this.Controls.Add(this.nameTitleFormatLabel);
      this.Controls.Add(this.OK);
      this.Controls.Add(this.cancel);
      this.Controls.Add(this.pb);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "SettingsForm";
      this.Text = "Settings";
      ((System.ComponentModel.ISupportInitialize)(this.signatureSize)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
  }
}