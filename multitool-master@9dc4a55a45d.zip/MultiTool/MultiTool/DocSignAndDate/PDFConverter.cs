﻿using Microsoft.Office.Core;
using Microsoft.Office.Interop.Word;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using System;
using System.IO;

namespace SignAndDate
{
  class PDFConverter
  {
    public PDFConverter() {;}
    private static Random random = new Random();

    /// <summary>
    /// Exports to pdf
    /// </summary>
    /// <param name="path">Path to word document</param>
    /// <param name="exportDir">Output directory</param>
    /// <returns></returns>
    public void CreatePDF(string path, string exportDir, string pass)
    {
      Application app = new Application()
      {
        DisplayAlerts = WdAlertLevel.wdAlertsNone,
        Visible = true
      };

      var objPresSet = app.Documents;
      var objPres = objPresSet.Open(path, MsoTriState.msoTrue, MsoTriState.msoFalse, MsoTriState.msoFalse);
      var baseFileName = Path.GetFileNameWithoutExtension(path);
      var pdfFileName = baseFileName + ".pdf";
      var pdfPath = Path.Combine(exportDir, pdfFileName);

      try
      {
        objPres.ExportAsFixedFormat(
          pdfPath,
          WdExportFormat.wdExportFormatPDF,
          false,
          WdExportOptimizeFor.wdExportOptimizeForPrint,
          WdExportRange.wdExportAllDocument,
          UseISO19005_1: true
        );
      }
      catch
      {
        pdfPath = null;
      }
      finally
      {
        objPres.Close();
        app.Quit();
        app = null;
        objPres = null;
        GC.Collect();
      }
      PdfDocument document = PdfReader.Open(pdfPath);

      if (!String.IsNullOrWhiteSpace(pass))
      {
        document.SecuritySettings.OwnerPassword = pass;
      }
      document.SecuritySettings.PermitModifyDocument = false;
      document.SecuritySettings.PermitAnnotations = false;
      document.SecuritySettings.PermitExtractContent = false;
      document.SecuritySettings.PermitAccessibilityExtractContent = false;
      document.SecuritySettings.PermitAssembleDocument = false;
      document.SecuritySettings.PermitFullQualityPrint = true;
      document.Save(pdfPath);
      document.Close();
    }
  }
}
