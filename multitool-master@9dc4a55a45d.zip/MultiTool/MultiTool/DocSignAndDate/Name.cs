﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using MultiTool;
using MultiTool.DocSignAndDate;

namespace SignAndDate
{
  class Name : IModule
  {
    private static string FullName;

    public Name(string name)
    {
      FullName = name;
    }

    private void SetName(string name)
    {
      FullName = name;
    }

    private string GetName()
    {
      return FullName;
    }

    /// <summary>
    /// Locates and replaces placeholder content
    /// </summary>
    /// <param name="doc">The document to be modified</param>
    public void ProcessDoc(WordprocessingDocument doc)
    {
      List<Table> tables = doc.MainDocumentPart.Document.Descendants<Table>().ToList();
      foreach (Table table in tables)
      {
        if (!table.InnerText.Contains("Compliance Name / Title") && !table.InnerText.Contains("Compliance Review By:"))
        {
          continue;
        }
        List<TableRow> rows = table.Descendants<TableRow>().ToList();
        foreach (TableRow row in rows)
        {
          List<TableCell> cells = row.Descendants<TableCell>().ToList();
          foreach (TableCell cell in cells)
          {
            if (cell.InnerText == "Print" || cell.InnerText == "Compliance nameTitle")
            {
              if (!String.IsNullOrWhiteSpace(DocSignAndDate.personName))
              {
                cell.RemoveAllChildren<Paragraph>();
                cell.Append(new Paragraph(new Run(new Text(GetName()))));
              }
            }
          }
        }
      }
    }
  }
}
