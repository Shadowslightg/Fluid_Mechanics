﻿using DocumentFormat.OpenXml.Packaging;

namespace SignAndDate
{
  interface IModule
  {
    void ProcessDoc(WordprocessingDocument doc);
  }
}
