﻿using DocumentFormat.OpenXml.Packaging;
using SignAndDate;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace MultiTool.DocSignAndDate
{
  class DocSignAndDate
  {
    private static string TDFolderLocation;
    private static string TRFolderLocation;
    private static string PicFolderLocation;
    private static string WatermarkFolderLocation;
    private static string OutputFolderLocation;
    public static string PDFPassword;
    public static string personName;
    static MainForm mf;

    public DocSignAndDate(MainForm mainForm)
    {
      mf = mainForm;
    }

    /// <summary>
    /// Opens the settings menu
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void Settings_Click(object sender, EventArgs e)
    {
      SettingsForm settings = new SettingsForm();
      settings.Show();
    }

    public static void Exit_Click(object sender, EventArgs e)
    {
      mf.Close();
    }

    public static void Help_Click(object sender, EventArgs e)
    {
      try
      {
        Process.Start("https://confluence.metro.ad.selinc.com/display/ALMW/Document+Sign+and+Date+Tool+Help");
      }
      catch
      {
        MessageBox.Show("Unable to open link.");
      }
    }

    /// <summary>
    /// Signs the specified documents
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void Sign_Click(object sender, EventArgs e)
    {
      personName = MainForm.FullName.Text;
      OutputFolderLocation = MainForm.PDFOutLoc.Text ?? Environment.SpecialFolder.Desktop.ToString();
      PDFPassword = MainForm.password.Text;
      IModule signature = new Signature(PicFolderLocation);
      IModule date = new Date();
      IModule title = new Title(MainForm.Title.Text);
      IModule watermark = new Watermark(WatermarkFolderLocation);
      IModule name = new Name(personName);
      List<IModule> moduleList = new List<IModule>() { watermark, date, name, signature, title };
      MainForm.Sign.Enabled = false;
      MainForm.Sign.Refresh();

      if (IsMissingParams())
      {
        MainForm.Sign.Enabled = true;
        MainForm.Sign.Refresh();
        return;
      }

      foreach (IModule module in moduleList)
      {
        if (!string.IsNullOrWhiteSpace(TDFolderLocation))
        {
          try
          {
            using (WordprocessingDocument doc = WordprocessingDocument.Open(TDFolderLocation, true))
            {
              if (module != watermark)
              {
                module.ProcessDoc(doc);
              }
            }
          }
          catch (IOException)
          {
            MessageBox.Show("TD file is currently in use. Operation canceled.", "File in use", MessageBoxButtons.OK);
            MainForm.Sign.Enabled = true;
            MainForm.Sign.Refresh();
            return;
          }
        }
        if (!string.IsNullOrWhiteSpace(TRFolderLocation))
        {
          try
          {
            using (WordprocessingDocument doc = WordprocessingDocument.Open(TRFolderLocation, true))
            {
              module.ProcessDoc(doc);
            }
          }
          catch (IOException)
          {
            MessageBox.Show("TR file is currently in use. Operation canceled.", "File in use", MessageBoxButtons.OK);
            MainForm.Sign.Enabled = true;
            MainForm.Sign.Refresh();
            return;
          }
        }
      }
      PDFConverter converter = new PDFConverter();
      converter.CreatePDF(TRFolderLocation, OutputFolderLocation, PDFPassword);
      MainForm.Sign.Enabled = true;
      MainForm.Sign.Refresh();
    }

    /// <summary>
    /// Browse for TD file
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void BrowseTD_Click(object sender, EventArgs e)
    {
      if (MainForm.TDBrowser.ShowDialog() == DialogResult.OK)
      {
        MainForm.TDLoc.Text = MainForm.TDBrowser.FileName;
        TDFolderLocation = MainForm.TDBrowser.FileName;
      }
    }

    /// <summary>
    /// Browse for TR file
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void BrowseTR_Click(object sender, EventArgs e)
    {
      if (MainForm.TRBrowser.ShowDialog() == DialogResult.OK)
      {
        MainForm.TRLoc.Text = MainForm.TRBrowser.FileName;
        TRFolderLocation = MainForm.TRBrowser.FileName;
      }
    }

    /// <summary>
    /// Browse for signature file
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void BrowsePic_Click(object sender, EventArgs e)
    {
      if (MainForm.PicBrowser.ShowDialog() == DialogResult.OK)
      {
        MainForm.PicLoc.Text = MainForm.PicBrowser.FileName;
        PicFolderLocation = MainForm.PicBrowser.FileName;
      }
    }

    /// <summary>
    /// Browse for accreditation mark file
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void BrowseWatermark_Click(object sender, EventArgs e)
    {
      if (MainForm.WatermarkBrowser.ShowDialog() == DialogResult.OK)
      {
        MainForm.WatermarkLoc.Text = MainForm.WatermarkBrowser.FileName;
        WatermarkFolderLocation = MainForm.WatermarkBrowser.FileName;
      }
    }

    /// <summary>
    /// Browse for output directory
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public static void BrowseOutput_Click(object sender, EventArgs e)
    {
      if (MainForm.OutputBrowser.ShowDialog() == DialogResult.OK)
      {
        MainForm.PDFOutLoc.Text = MainForm.OutputBrowser.SelectedPath;
        OutputFolderLocation = MainForm.OutputBrowser.SelectedPath;
      }
    }

    /// <summary>
    /// Checks to see if user is missing parameters before signing documents
    /// </summary>
    /// <returns>Returns false if all parameters are accounted for</returns>
    private static bool IsMissingParams()
    {
      if (String.IsNullOrWhiteSpace(MainForm.FullName.Text))
      {
        MessageBox.Show("Please enter your name.", "Missing Parameters", MessageBoxButtons.OK);
        return true;
      }

      if (String.IsNullOrWhiteSpace(MainForm.Title.Text))
      {
        MessageBox.Show("Please enter your job title.", "Missing Parameters", MessageBoxButtons.OK);
        return true;
      }

      if (String.IsNullOrWhiteSpace(WatermarkFolderLocation))
      {
        MessageBox.Show("Please select an accreditation mark.", "Missing Parameters", MessageBoxButtons.OK);
        return true;
      }

      if (String.IsNullOrWhiteSpace(PicFolderLocation))
      {
        MessageBox.Show("Please select a signature file.", "Missing Parameters", MessageBoxButtons.OK);
        return true;
      }

      if (String.IsNullOrWhiteSpace(TDFolderLocation) && String.IsNullOrWhiteSpace(TRFolderLocation))
      {
        MessageBox.Show("Please select a TD and/or TR file.", "Missing Parameters", MessageBoxButtons.OK);
        return true;
      }
      if(String.IsNullOrWhiteSpace(PDFPassword))
      {
        if(MessageBox.Show("No password specified. Are you sure?", "Missing Parameters", MessageBoxButtons.YesNo) == DialogResult.No)
        {
          return true;
        }
      }
      return false;
    }
  }
}
