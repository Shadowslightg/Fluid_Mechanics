﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Drawing.Wordprocessing;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System.IO;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;

namespace SignAndDate
{
  class Watermark : IModule
  {
    private static string ImageLocation;

    public Watermark(string imageLoc)
    {
      SetImageLocation(imageLoc);
    }
    private void SetImageLocation(string imageLoc)
    {
      ImageLocation = imageLoc;
    }

    private string GetImageLocation()
    {
      return ImageLocation;
    }

    /// <summary>
    /// Inserts image
    /// </summary>
    /// <param name="doc">Document to be modified</param>
    /// <param name="relationshipId"></param>
    private static void AddImageToBody(WordprocessingDocument doc, string relationshipId)
    {
      Anchor myAnchor = new Anchor();
      myAnchor.Append(new DW.SimplePosition() { X = 5577840L, Y = 8833104L });
      PositionOffset horizontalOffset = new PositionOffset
      {
        Text = "0"
      };
      PositionOffset verticalOffset = new PositionOffset
      {
        Text = "0"
      };
      myAnchor.Append(
        new DW.HorizontalPosition(
        )
        { RelativeFrom = DW.HorizontalRelativePositionValues.Page, PositionOffset = horizontalOffset }
      );
      myAnchor.Append(
        new DW.VerticalPosition(
        )
        { RelativeFrom = DW.VerticalRelativePositionValues.Page, PositionOffset = verticalOffset }
      );
      myAnchor.Append(
        new DW.Extent()
        {
          Cx = 1828800L,
          Cy = 621792L
        }
      );
      myAnchor.Append(
        new DW.EffectExtent()
        {
          LeftEdge = 0L,
          TopEdge = 0L,
          RightEdge = 0L,
          BottomEdge = 0L
        }
      );
      myAnchor.Append(new WrapNone());
      myAnchor.Append(
        new DocProperties()
        {
          Id = (UInt32Value)166U,
          Name = "Accreditation Mark"
        }
      );
      myAnchor.Append(
        new A.Graphic(
          new A.GraphicData(
            new PIC.Picture(
              new PIC.NonVisualPictureProperties(
                new PIC.NonVisualDrawingProperties()
                {
                  Id = (UInt32Value)126U,
                  Name = "AccredMark.jpg"
                },
                new PIC.NonVisualPictureDrawingProperties()),
                new PIC.BlipFill(
                  new A.Blip(
                    new A.BlipExtensionList(
                      new A.BlipExtension()
                      {
                        Uri = "{28A0092B-C50C-407E-A947-70E740481C1C}"
                      })
                  )
                  {
                    Embed = relationshipId,
                    CompressionState = A.BlipCompressionValues.Print
                  },
                  new A.Stretch(
                    new A.FillRectangle())),
              new PIC.ShapeProperties(
                new A.Transform2D(
                  new A.Offset() { X = 0L, Y = 0L },
                  new A.Extents()
                  {
                    Cx = 1828800L,
                    Cy = 621792L
                  }),
                new A.PresetGeometry(
                  new A.AdjustValueList()
                )
                { Preset = A.ShapeTypeValues.Rectangle }
              )
            )
          )
        { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
      );
      myAnchor.DistanceFromBottom = 0U;
      myAnchor.DistanceFromLeft = 0U;
      myAnchor.DistanceFromRight = 0U;
      myAnchor.DistanceFromTop = 0U;
      myAnchor.SimplePos = true;
      myAnchor.BehindDoc = false;
      myAnchor.AllowOverlap = true;
      myAnchor.LayoutInCell = false;
      myAnchor.Locked = false;
      myAnchor.RelativeHeight = 251658240;

      var element = new Drawing();
      element.Append(myAnchor);
      doc.MainDocumentPart.Document.Body.PrependChild(new Paragraph(new Run(element)));
      CompatibilitySetting compatSetting = new CompatibilitySetting();
      

      foreach (var paragraph in doc.MainDocumentPart.RootElement.Descendants<Paragraph>())
      {
        if(paragraph.InnerText == "Add ILAC and A2LA logos as appropriate.")
        {
          paragraph.RemoveAllChildren();
        }
      }
    }

    /// <summary>
    /// Locates and replaces placeholder content
    /// </summary>
    /// <param name="doc">The document to be modified</param>
    public void ProcessDoc(WordprocessingDocument doc)
    {
      MainDocumentPart mainPart = doc.MainDocumentPart;
      ImagePart imagePart = mainPart.AddImagePart(ImagePartType.Jpeg);
      using (FileStream stream = new FileStream(GetImageLocation(), FileMode.Open))
      {
        imagePart.FeedData(stream);
      }
      AddImageToBody(doc, mainPart.GetIdOfPart(imagePart));
    }
  }
}
