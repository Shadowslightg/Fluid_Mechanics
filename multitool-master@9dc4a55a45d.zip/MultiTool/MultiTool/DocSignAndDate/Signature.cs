﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;

namespace SignAndDate
{
  class Signature : IModule
  {
    private static string ImageLocation;

    public Signature(string imageLoc)
    {
      SetImageLocation(imageLoc);
    }

    private void SetImageLocation(string imageLoc)
    {
      ImageLocation = imageLoc;
    }

    private string GetImageLocation()
    {
      return ImageLocation;
    }

    /// <summary>
    /// Insert image
    /// </summary>
    /// <param name="p">Paragraph to insert image into</param>
    /// <param name="doc">The document to be modified</param>
    /// <param name="relationshipId"></param>
    /// <param name="width"></param>
    /// <param name="height"></param>
    private static void AddImageToBody(Paragraph p, WordprocessingDocument doc, string relationshipId, double width, double height)
    {
      var element =
        new Drawing(
         new DW.Inline(
           new DW.Extent() { Cx = (Int64Value)width, Cy = (Int64Value)height },
             new DW.EffectExtent()
             {
               LeftEdge = 0L,
               TopEdge = 0L,
               RightEdge = 0L,
               BottomEdge = 0L
             },
             new DW.DocProperties()
             {
               Id = 34U,
               Name = "Signature"
             },
             new DW.NonVisualGraphicFrameDrawingProperties(
               new A.GraphicFrameLocks() { NoChangeAspect = true }),
             new A.Graphic(
               new A.GraphicData(
                 new PIC.Picture(
                    new PIC.NonVisualPictureProperties(
                      new PIC.NonVisualDrawingProperties()
                      {
                        Id = 33U,
                        Name = "Signature.jpg"
                      },
                      new PIC.NonVisualPictureDrawingProperties()),
                        new PIC.BlipFill(
                          new A.Blip(
                            new A.BlipExtensionList(
                              new A.BlipExtension()
                              {
                                Uri = "{28A0092B-C50C-407E-A947-70E740481C1C}"
                              })
                              )
                              {
                              Embed = relationshipId,
                              CompressionState =
                              A.BlipCompressionValues.Print
                              },
                              new A.Stretch(
                                new A.FillRectangle())),
                             new PIC.ShapeProperties(
                                 new A.Transform2D(
                                     new A.Offset() { X = 0L, Y = 0L },
                                     new A.Extents() { Cx = (Int64Value)width, Cy = (Int64Value)height }),
                                 new A.PresetGeometry(
                                     new A.AdjustValueList()
                                 )
                                 { Preset = A.ShapeTypeValues.Rectangle }))
                     )
                     { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
             )
             {
               DistanceFromTop = 0U,
               DistanceFromBottom = 0U,
               DistanceFromLeft = 0U,
               DistanceFromRight = 0U,
               EditId = "50D07946"
             });

      p.AppendChild(new Run(element));
    }

    /// <summary>
    /// Locates and replaces placeholder content
    /// </summary>
    /// <param name="doc">The document to be modified</param>
    public void ProcessDoc(WordprocessingDocument doc)
    {
      List<Table> tables = doc.MainDocumentPart.Document.Descendants<Table>().ToList();
      foreach (Table table in tables)
      {
        if(!table.InnerText.Contains("Compliance Name / Title") && !table.InnerText.Contains("Compliance Review By:"))
        {
          continue;
        }
        List<TableRow> rows = table.Descendants<TableRow>().ToList();
        foreach (TableRow row in rows)
        {
          List<TableCell> cells = row.Descendants<TableCell>().ToList();
          string previous = "";
          foreach (TableCell cell in cells)
          {
            if (cell.InnerText == "Electronic Signature" || (cell.InnerText == "Signature" && previous == "Signature:"))
            {
              Paragraph p = cell.Descendants<Paragraph>().FirstOrDefault();
              p.RemoveAllChildren();
              MainDocumentPart mainPart = doc.MainDocumentPart;
              ImagePart imagePart = mainPart.AddImagePart(ImagePartType.Jpeg);
              using (FileStream stream = new FileStream(GetImageLocation(), FileMode.Open))
              {
                imagePart.FeedData(stream);
              }
              double imgWidth = 0;
              double imgHeight = 0;
              using (System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(GetImageLocation()))
              {
                imgWidth = bmp.Width;
                imgHeight = bmp.Height;
              }
              imgWidth = (double)Math.Round((decimal)imgWidth * 9525);
              imgHeight = (double)Math.Round((decimal)imgHeight * 9525);
              bool IsTR = false;
              foreach (Paragraph para in doc.MainDocumentPart.Document.Descendants<Paragraph>())
              {
                if (para.InnerText.Contains("This document is the test report"))
                {
                  IsTR = true;
                  break;
                }
              }
              if(IsTR)
              {
                double scale = 1.0 + (((5.0 * MultiTool.Properties.Settings.Default.PictureSizeTR) + 1.0) / 100.0);
                double width = imgWidth * scale;
                double height = imgHeight * scale;
                AddImageToBody(p, doc, mainPart.GetIdOfPart(imagePart), width, height);
              }
              else
              {
                double scale = 1.0 + (((5.0 * MultiTool.Properties.Settings.Default.PictureSizeTD) + 1.0) / 100.0);
                double width = imgWidth * scale;
                double height = imgHeight * scale;
                AddImageToBody(p, doc, mainPart.GetIdOfPart(imagePart), width, height);
              }
              break;
            }
            previous = cell.InnerText;
          }
        }
      }
    }
  }
}