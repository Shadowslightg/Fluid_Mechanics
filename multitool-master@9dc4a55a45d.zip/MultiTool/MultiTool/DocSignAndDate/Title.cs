﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Windows.Forms;
using DocumentFormat.OpenXml;
using MultiTool;
using MultiTool.DocSignAndDate;

namespace SignAndDate
{
  class Title : IModule
  {
    private static string PersonTitle;

    public Title(string title)
    {
      SetTitle(title);
    }

    private void SetTitle(string title)
    {
      PersonTitle = title;
    }

    private string GetTitle()
    {
      return PersonTitle;
    }

    /// <summary>
    /// Locates and replaces placeholder content
    /// </summary>
    /// <param name="doc">The document to be modified</param>
    public void ProcessDoc(WordprocessingDocument doc)
    {
      List<Table> tables = doc.MainDocumentPart.Document.Descendants<Table>().ToList();
      foreach (Table table in tables)
      {
        if (!table.InnerText.Contains("Compliance Name / Title") && !table.InnerText.Contains("Compliance Review By:"))
        {
          continue;
        }
        List<TableRow> rows = table.Descendants<TableRow>().ToList();
        foreach (TableRow row in rows)
        {
          List<TableCell> cells = row.Descendants<TableCell>().ToList();
          foreach (TableCell cell in cells)
          {
            if (cell.InnerText == DocSignAndDate.personName && !String.IsNullOrWhiteSpace(DocSignAndDate.personName))
            {
              bool IsTR = false;
              foreach(Paragraph para in doc.MainDocumentPart.Document.Descendants<Paragraph>())
              {
                if(para.InnerText.Contains("This document is the test report"))
                {
                  IsTR = true;
                  break;
                }
              }
              if(IsTR)
              {
                if(MultiTool.Properties.Settings.Default.OneLineSignTR)
                {
                  Text t = new Text
                  {
                    Text = " / " + GetTitle(),
                    Space = SpaceProcessingModeValues.Preserve
                  };
                  Paragraph p = cell.Descendants<Paragraph>().FirstOrDefault();
                  p.Append(new Run(t));
                }
                else
                {
                  Text t = new Text
                  {
                    Text = GetTitle()
                  };
                  cell.Append(new Paragraph(new Run(t)));
                }
              }
              else
              {
                if (MultiTool.Properties.Settings.Default.OneLineSignTD)
                {
                  Text t = new Text
                  {
                    Text = " / " + GetTitle(),
                    Space = SpaceProcessingModeValues.Preserve
                  };
                  Paragraph p = cell.Descendants<Paragraph>().FirstOrDefault();
                  p.Append(new Run(t));
                }
                else
                {
                  Text t = new Text
                  {
                    Text = GetTitle()
                  };
                  cell.Append(new Paragraph(new Run(t)));
                }
              }
            }
          }
        }
      }
    }
  }
}