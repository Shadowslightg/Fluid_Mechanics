﻿using System;
using System.Windows.Forms;

namespace SignAndDate
{
  public partial class SettingsForm : Form
  {
    public SettingsForm()
    {
      InitializeComponent();
      signatureSize.Value = MultiTool.Properties.Settings.Default.PictureSizeTD;
      SigSizeTD = MultiTool.Properties.Settings.Default.PictureSizeTD;
      SigSizeTR = MultiTool.Properties.Settings.Default.PictureSizeTR;
      if(MultiTool.Properties.Settings.Default.OneLineSignTD)
      {
        nameTitleFormat.Checked = true;
      }
      Menu = new MainMenu();
      MenuItem TD = new MenuItem("TD Settings");
      Menu.MenuItems.Add("TD Settings", new EventHandler(TD_Click));
      Menu.MenuItems.Add("TR Settings", new EventHandler(TR_Click));
    }

    #region UIElements
    public Label signatureSizeLabel;
    public Label nameTitleFormatLabel;
    public CheckBox nameTitleFormat;
    public TrackBar signatureSize;
    public Button OK;
    public Button cancel;
    public PictureBox pb;
    #endregion

    #region member variables
    public static bool OneLineSignTD;
    public static int SigSizeTD;
    public static bool OneLineSignTR;
    public static int SigSizeTR;
    public string settingsType = "TD";
    const int PBWIDTH = 270;
    const int PBHEIGHT = 65;
    #endregion

    /// <summary>
    /// Switches to TD document settings
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TD_Click(object sender, EventArgs e)
    {
      if(settingsType == "TR")
      {
        MultiTool.Properties.Settings.Default.PictureSizeTR = signatureSize.Value;
        SigSizeTR = signatureSize.Value;
        if (nameTitleFormat.Checked)
        {
          MultiTool.Properties.Settings.Default.OneLineSignTR = true;
          OneLineSignTR = true;
        }
        else
        {
          MultiTool.Properties.Settings.Default.OneLineSignTR = false;
          OneLineSignTR = false;
        }
        MultiTool.Properties.Settings.Default.Save();
      }
      signatureSize.Value = MultiTool.Properties.Settings.Default.PictureSizeTD;
      if(MultiTool.Properties.Settings.Default.OneLineSignTD)
      {
        nameTitleFormat.Checked = true;
      }
      else
      {
        nameTitleFormat.Checked = false;
      }
      settingsType = "TD";
    }

    /// <summary>
    /// Resizes and repositions the sample signature image
    /// </summary>
    /// <param name="pb">Sample signature</param>
    /// <param name="scale">Size multiplier</param>
    private void Reposition(PictureBox pb, double scale)
    {
      pb.Width = PBWIDTH;
      pb.Height = PBHEIGHT;
      pb.Height = (int)(pb.Height * scale);
      pb.Width = (int)(pb.Width * scale);
      pb.Left = (ClientSize.Width - pb.Width) / 2;
    }

    /// <summary>
    /// Used to visualize signature size
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void ImgSlider_Scroll(object sender, EventArgs e)
    {
      switch(signatureSize.Value)
      {
        case 0:
          Reposition(pb, .8);
          break;
        case 1:
          Reposition(pb, .85);
          break;
        case 2:
          Reposition(pb, .9);
          break;
        case 3:
          Reposition(pb, .95);
          break;
        case 4:
          Reposition(pb, 1);
          break;
        case 5:
          Reposition(pb, 1.05);
          break;
        case 6:
          Reposition(pb, 1.1);
          break;
        case 7:
          Reposition(pb, 1.15);
          break;
        case 8:
          Reposition(pb, 1.2);
          break;
        case 9:
          Reposition(pb, 1.25);
          break;
        case 10:
          Reposition(pb, 1.3);
          break;
        default:
          break;
      }
    }

    /// <summary>
    /// Switches to TR document settings
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TR_Click(object sender, EventArgs e)
    {
      if (settingsType == "TD")
      {
        MultiTool.Properties.Settings.Default.PictureSizeTD = signatureSize.Value;
        SigSizeTD = signatureSize.Value;
        if (nameTitleFormat.Checked)
        {
          MultiTool.Properties.Settings.Default.OneLineSignTD = true;
          OneLineSignTD = true;
        }
        else
        {
          MultiTool.Properties.Settings.Default.OneLineSignTD = false;
          OneLineSignTD = false;
        }
        MultiTool.Properties.Settings.Default.Save();
      }
      signatureSize.Value = MultiTool.Properties.Settings.Default.PictureSizeTR;
      if (MultiTool.Properties.Settings.Default.OneLineSignTR)
      {
        nameTitleFormat.Checked = true;
      }
      else
      {
        nameTitleFormat.Checked = false;
      }
      settingsType = "TR";
    }

    /// <summary>
    /// Save settings
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void Save_Click(object sender, EventArgs e)
    {
      if (settingsType == "TD")
      {
        MultiTool.Properties.Settings.Default.PictureSizeTD = signatureSize.Value;
        SigSizeTD = signatureSize.Value;
        if (nameTitleFormat.Checked)
        {
          MultiTool.Properties.Settings.Default.OneLineSignTD = true;
          OneLineSignTD = true;
        }
        else
        {
          MultiTool.Properties.Settings.Default.OneLineSignTD = false;
          OneLineSignTD = false;
        }
      }
      else
      {
        MultiTool.Properties.Settings.Default.PictureSizeTR = signatureSize.Value;
        SigSizeTR = signatureSize.Value;
        if (nameTitleFormat.Checked)
        {
          MultiTool.Properties.Settings.Default.OneLineSignTR = true;
          OneLineSignTR = true;
        }
        else
        {
          MultiTool.Properties.Settings.Default.OneLineSignTR = false;
          OneLineSignTR = false;
        }
      }
      MultiTool.Properties.Settings.Default.Save();
      Close();
    }

    private void Cancel_Click(object sender, EventArgs e)
    {
      Close();
    }
  }
}
