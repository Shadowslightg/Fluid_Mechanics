﻿using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignAndDate
{
  class Date : IModule
  {
    private static string CurrentDate;

    public Date()
    {
      SetDate();
    }

    /// <summary>
    /// Uses SEL date format. For example; 08 AUG 2018
    /// </summary>
    private void SetDate()
    {
      string day, mon, year;
      CurrentDate = DateTime.Now.ToString("dd MMMM yyyy");
      day = CurrentDate.Substring(0, 3);
      mon = CurrentDate.Substring(3, 3).ToUpper();
      year = CurrentDate.Substring(CurrentDate.Length - 5, 5);
      CurrentDate = day + mon + year;
    }

    private string GetDate()
    {
      return CurrentDate;
    }

    /// <summary>
    /// Locates and replaces placeholder content
    /// </summary>
    /// <param name="doc">The document to be modified</param>
    public void ProcessDoc(WordprocessingDocument doc)
    {
      List<Table> tables = doc.MainDocumentPart.Document.Descendants<Table>().ToList();
      foreach(Table table in tables)
      {
        if (!table.InnerText.Contains("Compliance Name / Title") && !table.InnerText.Contains("Compliance Review By:"))
        {
          continue;
        }
        List<TableRow> rows = table.Descendants<TableRow>().ToList();
        foreach(TableRow row in rows)
        {
          List<TableCell> cells = row.Descendants<TableCell>().ToList();
          string previous = "";
          foreach(TableCell cell in cells)
          {
            if((cell.InnerText == "DD MMM YYYY" && previous == "Print") || (cell.InnerText == "DD MMM YYYY" && previous == ""))
            {
              cell.RemoveAllChildren<Paragraph>();
              cell.Append(new Paragraph(new Run(new Text(GetDate()))));
            }
            previous = cell.InnerText;
          }
        }
      }
    }
  }
}
