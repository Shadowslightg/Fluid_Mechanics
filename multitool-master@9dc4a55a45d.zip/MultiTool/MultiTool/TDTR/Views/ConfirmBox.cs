﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace TestDataRecordToTestReport
{
    public partial class ConfirmBox : Form
    {
        public ConfirmBox()
        {
            InitializeComponent();
        }

        public ConfirmBox(List<string> copiedTableList) : this()
        {
            listBox.DataSource = copiedTableList;
        }
    }
}
