﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Blip = DocumentFormat.OpenXml.Drawing.Blip;
using ImageData = DocumentFormat.OpenXml.Vml.ImageData;
using OleObject = DocumentFormat.OpenXml.Vml.Office.OleObject;
using OpenXmlElement = DocumentFormat.OpenXml.OpenXmlElement;

namespace TestDataRecordToTestReport.Helper
{
    class ImageHelper
    {
        internal static void CopyImages(OpenXmlElement oldTable, OpenXmlElement newTable,
            WordprocessingDocument testData, WordprocessingDocument testReport)
        {
            List<Blip> sourceBlips = DocumentHelper.GetAllBlips(oldTable);
            List<Blip> targetBlips = DocumentHelper.GetAllBlips(newTable);

            foreach (Blip sourceBlip in sourceBlips)
            {
                foreach (Blip targetBlip in targetBlips)
                {
                    if (targetBlip.Embed.Value == sourceBlip.Embed.Value)
                    {
                        if (testData.MainDocumentPart.GetPartById(sourceBlip.Embed.Value) is ImagePart imagePart)
                        {
                            ImagePart newImagePart = testReport.MainDocumentPart.AddPart(imagePart);
                            
                            targetBlip.Embed.Value = testReport.MainDocumentPart.GetIdOfPart(newImagePart);
                            break;
                        }
                    }
                }
            }
        }

        internal static void CopyEmbeddedVisioImages(OpenXmlElement oldTable, OpenXmlElement newTable,
            WordprocessingDocument testData, WordprocessingDocument testReport)
        {
            List<EmbeddedObject> sourceObjects = oldTable.Descendants<EmbeddedObject>().ToList();
            List<EmbeddedObject> targetObjects = newTable.Descendants<EmbeddedObject>().ToList();

            foreach (EmbeddedObject targetobj in targetObjects)
            {
                foreach (EmbeddedObject sourceObj in sourceObjects)
                {
                    if (testData.MainDocumentPart.GetPartById(sourceObj.Descendants<ImageData>()
                                    .FirstOrDefault().RelationshipId) is ImagePart oldImagePart)
                    {
                        ImagePart newImagePart = testReport.MainDocumentPart.AddPart(oldImagePart);
                        
                        targetobj.Descendants<ImageData>().FirstOrDefault().RelationshipId = testReport.MainDocumentPart.GetIdOfPart(newImagePart);
                    }


                    if (testData.MainDocumentPart.GetPartById(sourceObj.Descendants<OleObject>()
                                    .FirstOrDefault().Id) is OpenXmlPart openXmlPart)
                    {
                        EmbeddedObjectPart newEmbeddedObj = (EmbeddedObjectPart)testReport.MainDocumentPart.AddPart(openXmlPart);

                        targetobj.Descendants<OleObject>().FirstOrDefault().Id =
                                    testReport.MainDocumentPart.GetIdOfPart(newEmbeddedObj);
                    }
                }
            }
        }
    }
}
