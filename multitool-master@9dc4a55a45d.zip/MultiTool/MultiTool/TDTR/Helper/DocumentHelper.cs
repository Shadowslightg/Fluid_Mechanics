﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Blip = DocumentFormat.OpenXml.Drawing.Blip;

namespace TestDataRecordToTestReport.Helper
{
    static class DocumentHelper
    {
        internal static string GetTextInsideDoubleQuote(string str)
        {
            int startIndex = str.IndexOf('\u201c') + 1;
            int length = str.IndexOf('\u201d') - startIndex;

            if (startIndex > 0 && length > 0)
            {
                str = str.Substring(startIndex, length);
            }

            return str;
        }

        internal static Tuple<string, string> GetSectionAndSubSection(string str)
        {
            string subSection = string.Empty;
            string section = string.Empty;

            // SubSection Title
            int startIndex = str.IndexOf('\u201c') + 1;
            int length = str.IndexOf('\u201d') - startIndex;

            if (startIndex > 0 && length > 0)
            {
                subSection = str.Substring(startIndex, length);
                str = str.Remove(startIndex - 1, length + 2);
            }

            // Section Title
            startIndex = str.IndexOf('\u201c') + 1;
            length = str.IndexOf('\u201d') - startIndex;

            if (startIndex > 0 && length > 0)
            {
                section = str.Substring(startIndex, length);
                str = str.Remove(startIndex - 1, length + 1);
            }
            return new Tuple<string, string>(section, subSection);
        }

        internal static bool IsUniqueInList(string title, List<KeyValuePair<string, Table>> listOfTables)
        {
            foreach (KeyValuePair<string, Table> item in listOfTables)
            {
                if (item.Key.Equals(title))
                {
                    return false;
                }
            }

            return true;
        }

        internal static bool IsCopyStatement(string statement)
        {
            if (statement.Contains("copy") && ((statement.Contains("table")) ||
                                               (statement.Contains("appendix")) ||
                                               (statement.Contains("section")) ||
                                               (statement.Contains("photograph"))
                                              )
               )
            {
                return true;
            }
            return false;
        }

        internal static int GetHeadingLevel(Paragraph paragraph)
        {
            ParagraphProperties paragraphProperties = paragraph.ParagraphProperties;
            if (paragraphProperties != null)
            {
                ParagraphStyleId paragraphStyleId = paragraphProperties.ParagraphStyleId;
                if (paragraphStyleId != null)
                {
                    if (paragraphStyleId.Val.ToString().ToLower().Contains("heading"))
                    {
                        return int.Parse(Regex.Match(paragraphStyleId.Val, @"\d+").Value);
                    }
                }
            }
            return 10;
        }

        internal static string GetTableTitle(OpenXmlElement element)
        {
            string title = string.Empty;

            while (!Regex.IsMatch(title, @"(Table.*\d|Photograph|Appendix.*\d)", RegexOptions.IgnoreCase))
            {
                element = element.PreviousSibling();
                if (element != null)
                {
                    title = element.InnerText;
                }
                else
                {
                    break;
                }
            }

            return title;
        }

        internal static List<string> GetListOfCopiedItems(List<string> tables, List<string> sections,
            List<string> subSections)
        {
            List<string> result = new List<string>();

            if (tables.Count > 0)
            {
                result.Add("================================  Tables  ================================");
                result.Add(string.Empty);
                result.AddRange(tables);
                result.Add(string.Empty);
            }

            if (sections.Count > 0)
            {
                result.Add(string.Empty);
                result.Add("================================  Sections  ================================");
                result.Add(string.Empty);
                result.AddRange(sections);
                result.Add(string.Empty);
            }

            if (subSections.Count > 0)
            {
                result.Add(string.Empty);
                result.Add("================================  Sub Sections  ================================");
                result.Add(string.Empty);
                result.AddRange(subSections);
                result.Add(string.Empty);
            }

            return result;
        }

        internal static List<Blip> GetAllBlips(OpenXmlElement table)
        {
            List<Blip> blips = new List<Blip>();
            foreach (Drawing drawing in table.Descendants<Drawing>())     // Only returns 24 blips...?
            {
                blips.AddRange(drawing.Descendants<Blip>());
            }

            return blips;
        }

        internal static List<Paragraph> GetParagraphsWithCopyStatement(WordprocessingDocument doc)
        {
            List<Paragraph> result = new List<Paragraph>();
            List<Paragraph> paragraphs = doc.MainDocumentPart.Document.Descendants<Paragraph>().ToList();

            foreach (Paragraph paragraph in paragraphs)
            {
                if (IsCopyStatement(paragraph.InnerText.ToLower()))
                {
                    result.Add(paragraph);
                }
            }
            return result;
        }

        internal static bool IsEndOfSection(OpenXmlElement nextElement, Paragraph sectionToCopy)
        {
            if (nextElement is Paragraph)
            {
                int h1 = GetHeadingLevel(sectionToCopy);
                int h2 = GetHeadingLevel((Paragraph)nextElement);
                if(nextElement.InnerText.Contains("End of Document"))
                {
                  return true;
                }
                if (h1 >= h2)
                {
                    return true;
                }
            }
            return false;
        }

        internal static int GetPreviousHeadingLevel(Paragraph target)
        {
            Paragraph previousParagraph = target.PreviousSibling<Paragraph>();

            while (previousParagraph != null)
            {
                int h = GetHeadingLevel(previousParagraph);
                if (h < 10)
                {
                    return h;
                }
                previousParagraph = previousParagraph.PreviousSibling<Paragraph>();
            }
            return 10;
        }

        internal static void SetHeadingLevel(Paragraph paragraph, int headingLevel)
        {
            ParagraphProperties paragraphProperties = paragraph.ParagraphProperties;
            if (paragraphProperties != null)
            {
                ParagraphStyleId paragraphStyleId = paragraphProperties.ParagraphStyleId;
                if (paragraphStyleId != null)
                {
                    if (paragraphStyleId.Val.ToString().ToLower().Contains("heading"))
                    {
                        paragraphStyleId.Val = "Heading" + headingLevel;
                    }
                }
            }
        }
    }
}
