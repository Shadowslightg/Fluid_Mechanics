﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.IO;

namespace TestDataRecordToTestReport.Helper
{
    class FileHelper
    {
        internal static string GetTemporaryFile(string oldFile)
        {
            string temp = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\tmptd2tr.docx";

            File.Copy(oldFile, temp, true);

            return temp;
        }

        internal static void CloseResources(WordprocessingDocument testData, WordprocessingDocument testReport, string temporyFile)
        {
            try
            {
                if (testReport != null)
                {
                    testReport.Close();
                }
                if (testData != null)
                {
                    testData.Close();
                }
                if (File.Exists(temporyFile))
                {
                    File.Delete(temporyFile);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                GC.Collect();
            }
        }

        internal static void SaveFile(WordprocessingDocument testReport, string path)
        {
            try
            {
                testReport.SaveAs(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
