﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using TestDataRecordToTestReport;

namespace MultiTool.TDTR
{
  class TDTR
  {
    public TDTR(MainForm mainForm)
    {
      mf = mainForm;
      tdtr = mf.TDTR;
      service = new TestDataRecordToTestReport.Service.DocumentService(mf);
    }

    private static List<string> copiedTableList = new List<string>();
    private static TestDataRecordToTestReport.Service.DocumentService service;
    static MainForm mf;
    static TabPage tdtr;

    public static void BrowseDataRecord(object sender, EventArgs e)
    {
      if(MainForm.ofd2.ShowDialog() == DialogResult.OK)
      {
        MainForm.tbDataRecord.Text = MainForm.ofd2.FileName;
      }
    }

    public static void BrowseTestReport(object sender, EventArgs e)
    {
      if(MainForm.ofd2.ShowDialog() == DialogResult.OK)
      {
        MainForm.tbTestReport.Text = MainForm.ofd2.FileName;
      }
    }

  public static void TransferData(object sender, EventArgs e)
    {

      if (string.IsNullOrEmpty(MainForm.tbDataRecord.Text) || string.IsNullOrEmpty(MainForm.tbTestReport.Text))
      {
        MessageBox.Show("Please, Select Data Record and Test Report", "Warning");
      }
      else
      {
        MainForm.bgWorker.RunWorkerAsync();
        ToggleControls();
      }
    }

    public static void SaveReport(object sender, CancelEventArgs e)
    {
      service.SaveReport(MainForm.sfd.FileName);
    }

    public static void OpenHelp(object sender, LinkLabelLinkClickedEventArgs e)
    {
      System.Diagnostics.Process.Start("https://confluence.metro.ad.selinc.com/x/EYKWGg");
    }

    public static void BGWorker_DoWork(object sender, DoWorkEventArgs e)
    {
      try
      {
        copiedTableList = service.PopulateTestReport();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message, "Failed!!!");
        e.Cancel = true;
      }
    }

    public static void BGWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
    {
      MainForm.progressBar.Value = e.ProgressPercentage;
      MainForm.lblProgress.Text = e.ProgressPercentage.ToString() + " %";
    }

    public static void BGWorker_RunWorkerComplete(object sender, RunWorkerCompletedEventArgs e)
    {
      if (!e.Cancelled)
      {
        MainForm.lblProgress.Text = "Completed";

        ConfirmBox confirm = new ConfirmBox(copiedTableList);

        if (confirm.ShowDialog() == DialogResult.Yes)
        {
          MainForm.sfd.FileName = MainForm.tbTestReport.Text;

          FileInfo fileInfo = new FileInfo(MainForm.tbTestReport.Text);
          MainForm.sfd.InitialDirectory = fileInfo.Directory.FullName;
          MainForm.sfd.FileName = fileInfo.Name;
          MainForm.sfd.ShowDialog();
          System.Diagnostics.Process.Start(MainForm.sfd.FileName);
        }
      }
      RefreshControls();
    }

    private static void ToggleControls()
    {
      MainForm.progressBar.Visible = !MainForm.progressBar.Visible;
      MainForm.lblProgress.Visible = !MainForm.lblProgress.Visible;

      foreach (Control ctrl in tdtr.Controls)
      {
        ctrl.Enabled = !ctrl.Enabled;
        ctrl.Refresh();
      }

      MainForm.btnTransfer.BackColor = MainForm.btnTransfer.Enabled ? Color.MediumSeaGreen : Color.Gray;
    }

    private static void RefreshControls()
    {
      MainForm.tbDataRecord.Text = string.Empty;
      MainForm.tbTestReport.Text = string.Empty;

      ToggleControls();
    }
  }
}
