﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using MultiTool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using TestDataRecordToTestReport.Helper;
using Inline = DocumentFormat.OpenXml.Drawing.Wordprocessing.Inline;
using OpenXmlElement = DocumentFormat.OpenXml.OpenXmlElement;

namespace TestDataRecordToTestReport.Service
{
    class DocumentService
    {
        #region Class field and Constructors
        string _temporyFile;
        private static MainForm _mainForm;
        private WordprocessingDocument _testData;
        private WordprocessingDocument _testReport;
        private List<KeyValuePair<string, Table>> _listOfTables;

        public DocumentService(MainForm mainForm)
        {
            _mainForm = mainForm;
        }
        #endregion Properties and Constructors

        internal List<string> PopulateTestReport()
        {
            CloseResources();
            _temporyFile = FileHelper.GetTemporaryFile(MainForm.tbTestReport.Text);

            _testData = WordprocessingDocument.Open(MainForm.tbDataRecord.Text, false);
            _testReport = WordprocessingDocument.Open(_temporyFile, true);

            _listOfTables = GetListOfTables();

            return CopyAllComponents();
        }

        private List<string> CopyAllComponents()
        {
            #region local variables
            List<string> listOfCopiedTables = new List<string>();
            List<string> listOfCopiedSections = new List<string>();
            List<string> listOfCopiedSubSections = new List<string>();
            List<Paragraph> listOfParagraphs = DocumentHelper.GetParagraphsWithCopyStatement(_testReport);

            double index = 0;
            #endregion local variables

            foreach (Paragraph paragraph in listOfParagraphs)
            {

                try
                {
                    if (paragraph.InnerText.ToLower().Contains("subsection"))
                    {
                        string copiedSubSection = CopySubSection(paragraph);
                        if (!string.IsNullOrEmpty(copiedSubSection))
                        {
                            listOfCopiedSubSections.Add(listOfCopiedSubSections.Count + 1 + ".  " + copiedSubSection);
                        }
                    }
                    else if (paragraph.InnerText.ToLower().Contains("section") || paragraph.InnerText.ToLower().Contains("appendix"))
                    {
                        string copiedSection = CopySection(paragraph);
                        if (!string.IsNullOrEmpty(copiedSection))
                        {
                            listOfCopiedSections.Add(listOfCopiedSections.Count + 1 + ".  " + copiedSection);
                        }
                    }
                    else
                    {
                        string copiedTable = CopyTable(paragraph);
                        if (!string.IsNullOrEmpty(copiedTable))
                        {
                            listOfCopiedTables.Add(listOfCopiedTables.Count + 1 + ".  " + copiedTable);
                        }
                    }
                    // Copy ReportNumber
                    if (paragraph.InnerText.ToLower().Contains("report no"))
                    {
                        SearchAndReplaceReportNumber(paragraph);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                index++;
                double i = (75.0 * index) / listOfParagraphs.Count;
                MainForm.bgWorker.ReportProgress((int)i + 25);
            }
            foreach(Paragraph p in _testReport.MainDocumentPart.Document.Body.Descendants<Paragraph>())
            {
              if(p.InnerText.ToLower().Contains("report no"))
              {
                SearchAndReplaceReportNumber(p);
              }
            }
            // Copy ReportNumber
            ReplaceReportNumberInFooter();
            _testReport.Save();

            return DocumentHelper.GetListOfCopiedItems(listOfCopiedTables, listOfCopiedSections,
                listOfCopiedSubSections); ;
        }

        private string CopyTable(Paragraph paragraph)
        {
            string tableName = DocumentHelper.GetTextInsideDoubleQuote(paragraph.InnerText);

            foreach (KeyValuePair<string, Table> table in _listOfTables)
            {
                Table oldTable = table.Value;
                if (table.Key.Contains(tableName))
                {
                    if (paragraph.NextSibling() is Table)
                    {
                        paragraph.NextSibling().Remove();
                    }

                    Table newTable = (Table)oldTable.CloneNode(true);
                    Paragraph tableTitle = (Paragraph)oldTable.PreviousSibling<Paragraph>().CloneNode(true);

                    if (tableTitle != null)
                    {
                        var innerText = tableTitle.InnerText.ToLower();

                        if (innerText.StartsWith("table") || innerText.Contains("seq table \\* arabic"))
                        {
                            StripTableName(tableTitle);
                            paragraph.InsertBeforeSelf(tableTitle);
                        }
                    }


                    CopyImagesIfAny(oldTable, newTable);

                    paragraph.InsertAfterSelf((newTable));
                    // Remove Blue Line
                    paragraph.Remove();
                    return tableName;
                }
            }
            return string.Empty;
        }

        private string CopySection(Paragraph target)
        {
            OpenXmlElement nextElement, copiedElement;

            int previousHeadingLevel = DocumentHelper.GetPreviousHeadingLevel(target);

            string sectionTitle = DocumentHelper.GetTextInsideDoubleQuote(target.InnerText);
            try
            {
                Paragraph sectionToCopy = GetSectionHeading(sectionTitle);

                if (sectionToCopy != null)
                {
                    nextElement = sectionToCopy.NextSibling();
                    while (nextElement != null)
                    {
                        if (DocumentHelper.IsEndOfSection(nextElement, sectionToCopy))
                        {
                            break;
                        }

                        copiedElement = nextElement.CloneNode(true);

                        if (copiedElement is Paragraph)
                        {
                            int headingLevel = DocumentHelper.GetHeadingLevel((Paragraph)copiedElement);

                            if (headingLevel < 10 && (headingLevel - previousHeadingLevel) > 1)
                            {
                                DocumentHelper.SetHeadingLevel((Paragraph)copiedElement, previousHeadingLevel + 1);
                            }
                            previousHeadingLevel = previousHeadingLevel + 1;
                        }

                        CopyImagesIfAny(nextElement, copiedElement);

                        var innerText = copiedElement.InnerText.ToLower();

                        if (innerText.StartsWith("table") &&
                            (nextElement.NextSibling() is Table || innerText.Contains("seq table \\* arabic")))
                        {
                            StripTableName(copiedElement);
                        }

                        target.InsertBeforeSelf((copiedElement));

                    nextElement = nextElement.NextSibling();
                    }
                    // Remove Blue Text
                    target.Remove();

                    return sectionTitle;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return string.Empty;
        }

        private string CopySubSection(Paragraph target)
        {
            OpenXmlElement nextElement, copiedElement;

            int previousHeadingLevel = DocumentHelper.GetPreviousHeadingLevel(target);

            Tuple<string, string> sectionAndSubSectiontitle = DocumentHelper.GetSectionAndSubSection(target.InnerText);
            try
            {
                Paragraph sectionToCopy = GetSubSectionHeading(sectionAndSubSectiontitle);

                if (sectionToCopy != null)
                {
                    nextElement = sectionToCopy.NextSibling();
                    while (nextElement != null)
                    {
                        if (DocumentHelper.IsEndOfSection(nextElement, sectionToCopy))
                        {
                            break;
                        }

                        copiedElement = nextElement.CloneNode(true);

                        if (copiedElement is Paragraph)
                        {
                            int headingLevel = DocumentHelper.GetHeadingLevel((Paragraph)copiedElement);

                            if (headingLevel < 10 && (headingLevel - previousHeadingLevel) > 1)
                            {
                                DocumentHelper.SetHeadingLevel((Paragraph)copiedElement, previousHeadingLevel + 1);
                            }
                            previousHeadingLevel = previousHeadingLevel + 1;
                        }

                        CopyImagesIfAny(nextElement, copiedElement);

                        var innerText = copiedElement.InnerText.ToLower();

                        if (innerText.StartsWith("table") &&
                            (nextElement.NextSibling() is Table || innerText.Contains("seq table \\* arabic")))
                        {
                            StripTableName(copiedElement);
                        }

                        target.InsertBeforeSelf((copiedElement));

                        nextElement = nextElement.NextSibling();
                    }
                    // Remove Blue Text
                    target.Remove();
                    return sectionAndSubSectiontitle.Item2;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return string.Empty;
        }

        private List<KeyValuePair<string, Table>> GetListOfTables()
        {
            List<KeyValuePair<string, Table>> listOfTables = new List<KeyValuePair<string, Table>>();

            double index = 0;
            List<Table> listOftables = _testData.MainDocumentPart.Document.Body.OfType<Table>().ToList();
            foreach (Table table in listOftables)
            {
                string title = DocumentHelper.GetTableTitle(table);

                if (title != string.Empty && DocumentHelper.IsUniqueInList(title, listOfTables))
                {
                    listOfTables.Add(new KeyValuePair<string, Table>(title, table));
                }
                double i = (25.0 * ++index) / listOftables.Count;
                MainForm.bgWorker.ReportProgress((int)i);
            }
            return listOfTables;
        }

        internal void SaveReport(string path)
        {
            FileHelper.SaveFile(_testReport, path);

            CloseResources();
        }

        private void CloseResources()
        {
            FileHelper.CloseResources(_testData, _testReport, _temporyFile);
        }

        private void CopyImagesIfAny(OpenXmlElement oldTable, OpenXmlElement newTable)
        {
            if (oldTable.Descendants<Inline>().ToList().Count > 0 || oldTable.Descendants<DocumentFormat.OpenXml.Drawing.Wordprocessing.Anchor>().ToList().Count > 0)
            {
                ImageHelper.CopyImages(oldTable, newTable, _testData, _testReport);
            }

            if (oldTable.Descendants<EmbeddedObject>().ToList().Count > 0)
            {
                ImageHelper.CopyEmbeddedVisioImages(oldTable, newTable, _testData, _testReport);
            }
        }

        private string GetReportNumber()
        {
            foreach (FooterPart footerPart in _testData.MainDocumentPart.FooterParts)
            {
                foreach (Paragraph paragraph in footerPart.Footer.Descendants<Paragraph>().ToList())
                {
                    string paraText = paragraph.InnerText;
                    if(Regex.IsMatch(paraText, @"SEL .*Report No\. .*"))
                    {
                        paraText = Regex.Replace(paraText, @"SEL .*Report No\. ", "");
                        return paraText;
                    }
                }

            }
            return string.Empty;
        }

        private void SearchAndReplaceReportNumber(Paragraph paragraph)
        {
            Run run = paragraph.Descendants<Run>().First();

            while (run != null)
            {
                if (run.InnerText.ToLower().Contains("report no"))
                {
                    run.Descendants<Text>().First().Text += GetReportNumber();
                    run = run.NextSibling<Run>();
                    while (run != null && run.InnerText != string.Empty)
                    {
                        run.Descendants<Text>().First().Text = string.Empty;
                        run = run.NextSibling<Run>();
                    }
                    break;
                }
                else
                {
                    run = run.NextSibling<Run>();
                }
            }
        }

        private void ReplaceReportNumberInFooter()
        {
            foreach (FooterPart footerPart in _testReport.MainDocumentPart.FooterParts)
            {
                foreach (Paragraph paragraph in footerPart.Footer.Descendants<Paragraph>().ToList())
                {
                    if (paragraph.InnerText.ToLower().IndexOf("report no") >= 0)
                    {
                        SearchAndReplaceReportNumber(paragraph);
                    }
                }
            }
        }

        private void StripTableName(OpenXmlElement copiedElement)
        {
            if (!MainForm.cbCopyTableNumber.Checked)
            {
                var text = copiedElement.InnerText;

                int index = text.IndexOf(":");
                int length = text.Length - index;

                if (copiedElement.Descendants<SimpleField>().FirstOrDefault() != null)
                {
                    copiedElement.Descendants<SimpleField>().FirstOrDefault().Remove();
                }

                List<Run> runs = copiedElement.Descendants<Run>().ToList();
                foreach (var run in runs)
                {
                    run.Remove();
                }

                copiedElement.AppendChild(new Run(new Text(text.Substring(index + 1, length - 1).Trim())));
            }
        }

        private Paragraph GetSubSectionHeading(Tuple<string, string> sectionAndSubSectiontitle)
        {
            string sectionTitle = sectionAndSubSectiontitle.Item1.Trim();
            string subSectionTitle = sectionAndSubSectiontitle.Item2.Trim();
            try
            {
                var sections = _testData.MainDocumentPart.Document.Body
                               .OfType<Paragraph>()
                               .Where(p => p.ParagraphProperties != null &&
                                           p.ParagraphProperties.ParagraphStyleId != null &&
                                           p.ParagraphProperties.ParagraphStyleId.Val.ToString().ToLower().Contains("heading") &&
                                           p.InnerText.Trim().Equals(sectionTitle))
                                .ToList();

                foreach (Paragraph section in sections)
                {
                    int h = (DocumentHelper.GetHeadingLevel(section));

                    Paragraph nextElement = section.NextSibling<Paragraph>();
                    while (DocumentHelper.GetHeadingLevel(nextElement) > h)
                    {
                        if (nextElement.InnerText.Equals(subSectionTitle))
                        {
                            return nextElement;
                        }
                        nextElement = nextElement.NextSibling<Paragraph>();
                    }
                }
                return null;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        private Paragraph GetSectionHeading(string title)
        {
            try
            {
                return _testData.MainDocumentPart.Document.Body
                               .OfType<Paragraph>()
                               .Where(p => p.ParagraphProperties != null &&
                                           p.ParagraphProperties.ParagraphStyleId != null &&
                                           p.ParagraphProperties.ParagraphStyleId.Val.ToString().ToLower().Contains("heading") &&
                                           p.InnerText.Equals(title))
                                .FirstOrDefault();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
    }
}